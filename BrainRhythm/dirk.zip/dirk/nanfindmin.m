function idx = nanfindmin(X)

[~,idx] = nanmin(X);
