function h = linerel(X,Y,varargin)

% plot lines relative to axes ranges (0 to 1)
x = X*range(xlim)+min(xlim);
y = Y*range(ylim)+min(ylim);
h = line(x,y,varargin{:});


