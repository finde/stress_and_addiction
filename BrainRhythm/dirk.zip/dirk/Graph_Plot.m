function Graph_Plot(G)

% plot a circular graph with connections

N=size(G,1);
if N~=size(G,2)
    error('Graph is a symmetric matrix');
end

t = linspace(0,2*pi,N+1);
x = cos(t(1:end-1));
y = sin(t(1:end-1));
for row=1:N-1
    for col=row+1:N
        if G(row,col)
            set(line(x([row col]),y([row col])),'linewidth',G(row,col)*2)
        end
    end
end
circle(x,y,.1)

return


function circle(x,y,r)
%x and y are the coordinates of the center of the circle
%r is the radius of the circle
%0.01 is the angle step, bigger values will draw the circle faster but
%you might notice imperfections (not very smooth)
ang=0:0.01:2*pi; 
xp=r*cos(ang);
yp=r*sin(ang);
hold on
for c=1:length(x)
    plot(x(c)+xp,y(c)+yp,'k-');
    set(text(x(c),y(c),sprintf('%d',c)),'hor','center','ver','middle')
end
