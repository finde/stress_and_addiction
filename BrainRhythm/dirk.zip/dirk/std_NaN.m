function y = var_NaN(x,dim,missing)
%   var_NaN: calculates standard deviation along dimension dim, excluding
%   NaN values (or missings, if specified)

error('functie schijnt niet helemaal te werken..., gebruik var_NaN')

y=sqrt(var_NaN(x),dim,missing); 

