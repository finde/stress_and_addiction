function Res = geewrap(Y, X ,ClusterId,varargin)

% wrapper for the gee function (GEEQBOX) that has awkward data entry. Use
% 'corstr'={'ind','exch'} as varargin for independent and exchangeable
% working correlation matrices.
% defaults: 
% - independent working matrix
% - normal distribution
% - 


corstr = 'ind'; % independent working correlation matrix
family = 'gaussian';
varstr = {};
R = 0.0;
if length(varargin)>0
    for v=1:2:length(varargin)
        if strcmpi(varargin{v},'corstr')
            corstr = varargin{v+1}(1:3);
        elseif strcmpi(varargin{v},'family')
            family = varargin{v+1};
        elseif strcmpi(varargin{v},'varnames')
            varstr = varargin{v+1};
        elseif strcmpi(varargin{v},'r')
            R = varargin{v+1};
        else
            error('unknown option')
        end
    end
end

if strncmpi(corstr,'ind',3)
    cornum = 6;
elseif strncmpi(corstr,'exc',3) || strcmpi(corstr,'equ')
    cornum = 3;
else
    error('unknown corstr option')
end

switch (family)
    case {'gaussian','normal'}
        familynum = 1;
    case {'bernoulli','binomial'}
        familynum = 2;
    case {'poisson'}
        familynum = 3;
    otherwise
        error('unknown family option')
end

% start here
valid = ~isnan(Y) & ~isnan(sum(X,2)) & ~isnan(ClusterId);
ClusterId = ClusterId(valid);
Y = Y(valid);
X = X(valid,:);

if isempty(Y)
    warning('No data.')
    Res = [];
    return
end


if ~issorted(ClusterId)
    warning('Sorting the data')
    [ClusterId,ndx] = sort(ClusterId);
    Y = Y(ndx,:);
    X = X(ndx,:);
end

if sum(nanstd(X(:,:))==0)==0
    warning('Adding column of ones to X')
    X=[ones(size(X,1),1) X];
    if ~isempty(varstr)
        varstr = [{'intercept'} varstr];
    end
end

% determine the "repeated" variable (t in gee.m) that determines who is the
% repeat within the cluster.
RepeatId = [];
UniqueClustID = unique(ClusterId);
for clust=1:length(UniqueClustID)
    RepeatId = [RepeatId ; [1:sum(ClusterId==UniqueClustID(clust))]'];
end    

if isempty(varstr)
    [~,~,Res, workingR] = gee(ClusterId, Y, RepeatId, X, familynum, cornum, [], [], [], R);
else
    [~,~,Res, workingR] = gee(ClusterId, Y, RepeatId, X, familynum, cornum, varstr, [], [], R);
end
Res.workingR = workingR;
