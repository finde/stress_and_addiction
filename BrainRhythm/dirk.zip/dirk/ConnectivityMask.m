function [Mask] = ConnectivityMask(Leads)

if isstruct(Leads) & isfield(EEG,'chanlocs')
    L = {EEG.chanlocs.labels};
elseif iscell(Leads)
    L = Leads;
end
% L now holds the cell array of strings with lead names

N = length(L);

Mask = struct;
Mask.Homologue = false(N);
Mask.IntraL    = false(N);
Mask.IntraR    = false(N);
Mask.Cross     = false(N);

% fill the homologues, same prefix (e.g. F,C,P or O), number differs by 1
for row=1:N-1
    for col=row+1:N
        if strcmp(L{row}(1:end-1),L{col}(1:end-1)) && abs(str2num(L{row}(end))-str2num(L{col}(end)))==1
            Mask.Homologue(row,col) = true;
        end
    end
end

% fill the intraL: both uneven numbered
for row=1:N-1
    for col=row+1:N
        if mod(str2num(L{row}(end)),2)==1 && mod(str2num(L{col}(end)),2)==1
            Mask.IntraL(row,col) = true;
        end
    end
end

% fill the intraR: both uneven numbered
for row=1:N-1
    for col=row+1:N
        if mod(str2num(L{row}(end)),2)==0 && mod(str2num(L{col}(end)),2)==0
            Mask.IntraR(row,col) = true;
        end
    end
end

% remainder is cross-hemispheric connectivity, but remove the diagonal
Mask.Cross = ~logical(eye(N)) &~Mask.Homologue &~Mask.IntraL &~Mask.IntraR;

% make symmetric
Mask.Homologue = Mask.Homologue | Mask.Homologue';
Mask.IntraL    = Mask.IntraL | Mask.IntraL';
Mask.IntraR    = Mask.IntraR | Mask.IntraR';
Mask.Cross     = Mask.Cross | Mask.Cross';

            
