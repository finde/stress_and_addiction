function evtinfo = getevtinfo(EEG, epochnum)

% return the eventinfo for the "main" event in epoch, ignoring all other
% events

evtinfo = struct;
for num=1:length(EEG.epoch(epochnum).eventlatency)
    if EEG.epoch(epochnum).eventlatency{num}==0
        for str=fieldnames(EEG.epoch)'
            if iscell(eval(sprintf('EEG.epoch(epochnum).%s(%d)',str{:},num)))
                eval(sprintf('evtinfo.%s = EEG.epoch(epochnum).%s{%d};',str{:},str{:},num));
            else
                eval(sprintf('evtinfo.%s = EEG.epoch(epochnum).%s(%d);',str{:},str{:},num));
            end
        end
    end
end

