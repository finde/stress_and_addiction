function stats = PermutationTest_Function(n,X,Y,func,iterate)

% permute any function. Use a function that will allow multiple Y values
% and successively output a single separate statistic for each of the Y
% columns. corr is an example of such a function.
stats = struct;

stats.statistic = func(X,Y);

% use the shuffle mex function for speed. shuffle y, not x
permute = Shuffle(repmat((1:length(Y))', 1, n));
if ~iterate
    stats.list = func(X,permute);
else
    parfor perm=1:size(permute,2)
        stats(perm).list = func(X, permute(:,perm));
    end
end
stats.median = median(stats.list);
stats.P975 = prctile(stats.list, 97.5);
stats.P025 = prctile(stats.list, 2.5);




