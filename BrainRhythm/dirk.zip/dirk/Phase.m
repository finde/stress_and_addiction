function ph = Phase(X,varargin)
% function ph = Phase(X,varargin)
%
% calculates the pahse difference betweeen all possible pairs of columns in matrix X
%
% varargin:
%  - 'correct': (0,1) attempt to make phase continuous (default 0)

if nargin==0
    help Phase
    return
end

skip=0;
if size(X,2)>size(X,1)
    warning('Are the data in columns?')
end

correct = 0;
for v=1:2:length(varargin)
    switch varargin{v}
        case 'correct'
            correct = varargin{v+1};
        otherwise
            error('unknown key');
    end
end

% use hilbert to get instantaneous phase
ph = angle(hilbert(X));

if correct
    for col=1:size(X,2)
        % smoothen the phase signal (remove the sawtooth pattern)
        ndx=(~(diff(ph(:,col))>-pi/2 & diff(ph(:,col))<=pi/2) .* diff(ph(:,col))<0);
        offset = ([0 ; cumsum(ndx)]);
        phcorr(:,col) = ph(:,col) + offset.*pi;
    end
    ph = phcorr;
end
   
            
    
    
    