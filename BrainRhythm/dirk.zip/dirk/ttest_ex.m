function [t] = ttest_ex(x,varargin)
%TTEST  One-sample and paired-sample t-test.
%   Returns t statistic rather than H

[H P CI STATS] = ttest(x,varargin{:});
t=STATS.tstat;
