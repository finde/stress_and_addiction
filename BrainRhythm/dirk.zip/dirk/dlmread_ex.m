function [data header] = dlmread_ex(filename, del, hasheader, multiple)
% dlmread_ex: read rectangular data from file
%   filename : string with file name
%   del      : delimiter
%   hasheader: (1 or 0) read first line as header. Default 0.
%   multiple : (1 or 0) take multiple delimiters as 1. Default 0.

if nargin < 4
    multiple=0;
end
if nargin < 3
    hasheader=0;
end

fid = fopen(filename,'r');
if fid<1
    error(sprintf('Could not open this file (%d).',fid));
end

lc=0;
if hasheader
    temp = fgetl(fid);
    lc=1;
    header = textscan(temp,'%s','delimiter',del);
    header=header{1};
end
fclose(fid);

if multiple==0
    if hasheader
        data=dlmread(filename,del,1,0);
    else
        data=dlmread(filename,del);
    end
else
    fid=fopen(filename);
    if hasheader
        fgetl(fid);
    end
    count=0;
    while isempty(ferror(fid))
        count=count+1;
        line=fgetl(fid);
        temp = textscan(line,'%f','Delimiter',del,'MultipleDelimsAsOne',1);
        data(count,:) = temp{1};
    end
end

