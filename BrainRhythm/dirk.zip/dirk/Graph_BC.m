function BC = Graph_BC(Adj)

error('Not yet working')

% Compute betweenness centrality in adjacency matrix Adj. Only for logical
% matrices (but weighted matrices will be accepted)
A = logical(Adj);
N=size(A,1);
if size(A,2)~=N
    error('Adj must be square');
end

A(logical(eye(N))) = 0;
KList = sum(A);

% make a directional graph, so "activity" is not propagated back.
A=sdiag(sdiag(A));
LeafNList = sum(A)==0 & sum(A')==1;

% set up the loop
seed = single(LeafNList);
done = single(LeafNList);
accu = zeros(1,N);
for loop=1:N
    seed = (seed * A);
    if sum(seed)==0
        BC = accu;
        break
    end

    accu = accu + seed;
end

BC = BC .* ~LeafNList;

%{
BC = zeros(1,N);
for vertex=find(LeafNList)
    seed = zeros(1,N);
    seed(vertex) = 1;
    done = LeafNList;
    accu = zeros(1,N);
    for loop=1:N+1
        seed = single(logical((seed * A)) & ~done);
        if sum(seed)==0
            BC = BC + accu;
            break
        end
        done(logical(seed)) = 1;
        % saveaccu = accu; % save into BC without the last step!
        accu = accu + seed.*loop;
    end
end
%}

BC = BC;


        
        
    


