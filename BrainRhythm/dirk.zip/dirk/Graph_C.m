function [C CDist] = Graph_C(Graph)

if size(Graph,1)~=size(Graph,2)
    error('Graph_C: Graph must be square');
end
if max(max(Graph))>1.0 || min(min(Graph))<0.0
    error('Graph_C: designed for 0, 1 graphs only.');
end

N=size(Graph,1);

C = 0;
CDist=zeros(1,N);

for i=1:N
    som1=0;
    som2=0;
    for a=1:N
        for b=1:N
            if ((i~=a)&&(i~=b)&&(a~=b))
                som1 = som1 + Graph(i,a)*Graph(i,b);
                som2 = som2 + Graph(i,a)*Graph(i,b)*Graph(a,b);
            end
        end
    end
    if som1 > 0 
        CDist(i) = (som2/som1);
    end
end

C = mean(CDist);
