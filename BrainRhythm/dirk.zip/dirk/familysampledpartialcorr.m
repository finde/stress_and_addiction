function [R] = familysampledpartialcorr(widedata, NCols, missing, type)

% widedata is a 2D matrix with all data in wide format. Each
% family is one row. Then columns follow grouped by subject. NCols holds
% the number of columns for the X, the Y, and optional Z variables. These
% are 
%
% Use this function to extend bootstrp to allow family based sampling
%
% NOTE: bootstrp and bootci only allow scalar output, so in using these
% functions the number of columns correlated (both X and Y) must be 1.
% NCols must therefore read [1 1 nz] where nz is the number of covariates.


if nargin<4
    type=1;
else
    if strcmpi(type,'pearson') || strcmpi(type,'pmcc')
        type=1;
    elseif strcmpi(type,'spearman') || strcmpi(type,'rcc')
        type=2;
    elseif strcmpi(type,'kendall') || strcmpi(type,'tau')
        type=3;
    end
    % if type is a number then already set to 1, 2, 3 (hopefully);
end

if nargin<3,
    missing=NaN;
end

if ~isnan(missing)
    widedata(find(widedata(:)==missing))=NaN;
end

% extract X, Y, and Z data
datax=widedata(:,1:sum(NCols):end);
datax=datax(:);
datay=widedata(:,1+NCols(1):sum(NCols):end);
datay=datay(:);
dataz=[];
if length(NCols)>2
    for c=1:NCols(3)
        temp = widedata(:,sum(NCols(1:2))+c:sum(NCols):end);
        dataz(:,c)=temp(:);
    end
end
   
if isempty(dataz)
    switch type
        case 1, R=corr(datax,datay,'rows','pairwise');
        case 2, R=corr(datax,datay,'rows','pairwise','type','spearman');
        case 3, R=corr(datax,datay,'rows','pairwise','type','kendall');
    end
else
    switch type
        case 1, R=partialcorr(datax,datay,dataz,'rows','pairwise');
        case 2, R=partialcorr(datax,dataz,'rows','pairwise','type','spearman');
        otherwise
            error('Invalid correlation type')
    end
end



