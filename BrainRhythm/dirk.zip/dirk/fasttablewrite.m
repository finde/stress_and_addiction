function T = fasttablewrite(Filename, T, varargin)

% writes a table or struct array to a file.
% 
% - Filename: <string> name of the file to be written
% - T: table variable
% 
% varargin options
%   - 'delimiter' : char (default '\t')
%   - 'gzip' : logical (default false)

cDelimiter = '\t';
cGzip = false;
for v=1:2:length(varargin)
    if strncmpi(varargin{v},'del',3)
        cDelimiter = sprintf(varargin{v+1});
    elseif strncmpi(varargin{v},'del',3)
        cGzip = varargin{v+1};
    else
        error('Unknown option %s',varargin{v})
    end
end

% determine header
header = T.Properties.VariableNames;
NCol = length(header);

% write files to be pasted later.
cmd = 'paste -d '' '' ';
for col=1:NCol    
    FN = sprintf('.paste%d.txt',col);
    fid = fopen(FN,'W');
    if fid<1
        error('Failed to open temp file.')
    end
    fprintf(fid,'%s\n',header{col});
    
    z=T{:,col};
    if iscell(z(1,1))
        fprintf(fid,'%s\n',z{:});
    elseif islogical(z(1,1)) || isinteger(z(1,1))
        fprintf(fid,'%d\n',z');
    elseif isnumeric(z(1,1)) 
        fprintf(fid,'%g\n',z');
    end
    fclose(fid);
    
    cmd = [cmd ' ' FN];
end

if cGzip
    cmd = [cmd sprintf(' | gzip -c --fast >"%s".gz',Filename)];
else
    cmd = [cmd sprintf(' >"%s"',Filename)];
end
system(cmd);
cmd = 'rm .paste*.txt';
system(cmd);
    






    


