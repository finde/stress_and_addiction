function Reduced = correctRank(X, tol)

% Correct the data in X (reduce number of variables so that it matches the
% rank of the data. All eigenvalues lower than tol will be discarded.

[evc, evl] = pcacov(corr(X,'rows','pairwise'));

ndx = abs(evl)>tol;
Reduced = X*evc(:,ndx);
