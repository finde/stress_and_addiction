function R=fisherinv(Z)

R=zeros(size(Z,1),size(Z,2));
for row=1:size(R,1)
    for col=1:size(R,2)
        R(row,col)=(exp(2*Z(row,col))-1)/(exp(2*Z(row,col))+1);
    end
end
