function [C L] = Graph_Rnd_CL(Connect, varargin)

% either calculates the C and L of a random graph, or retrieves it from a
% database. 
% varargin:
%   type: {'p-type'|'none'|'fixed'} randomization types. See Graph_Rnd.m.
%   Defualt=p-type;

if size(Connect,1)~=size(Connect,2)
    error('Matrix must be suqare')
end

typernd='p-type';
nboot=1000;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'type')
        typernd=varargin{v+1};
    elseif strcmpi(varargin{v},'nboot')
        nboot=varargin{v+1};
    end
end
            

global FullList FullListType

N=size(Connect,1);
K=mean(sum(Connect.*(1-eye(N))));

% do we have the correct data?
empty=0;
try
    if ~strcmpi(typernd,FullListType)
        empty=1;
    elseif size(FullList,1)<1
        empty=1;
    else
        switch typernd
            case 'none'
                if size(FullList,2)-2~=1
                    empty=1;
                end
            otherwise
                if size(FullList,2)-2~=size(Connect,1)
                    empty=1;
                end
        end
    end
catch
    empty=1;
end
   
if empty
    if exist(sprintf('FullList_deg%d_%s.mat',N,typernd))
        load(sprintf('FullList_deg%d_%s.mat',N,typernd))
    else
        FullList=[];
        FullListType=typernd;
    end
end

Connect=Connect.*(1-eye(N));
for i=1:size(FullList,1)
    hit=0;
    switch typernd
        case 'p-type'
            if sum(FullList(i,1:N)==sort(sum(Connect)))==N
                hit=1;
            end
        case 'none'
            if FullList(i,1)==N && FullList(i,2)==K
                hit=1;
            end
        case 'fixed'
            error('not implemented yet');
    end
    if hit
        % hit!
        C=FullList(i,end-1);
        L=FullList(i,end);
        return
    end
end

% not found, so do randomisation
switch typernd
    case 'none'
        FullList(end+1,1:4)=[N K 0 0];
    otherwise
        FullList(end+1,1:N+2) = [sort(sum(Connect)) 0 0];
end

Lrnd=zeros(1,nboot);
Crnd=zeros(1,nboot);
for boot=1:nboot
    X=Graph_Rnd(Connect,'type',typernd);
    Lrnd(boot)=Graph_L(X);
    Crnd(boot)=Graph_C(X);
end

L=1./mean(1./Lrnd);
C=mean(Crnd);
FullList(end,end-1)=C;
FullList(end,end)=L;

save(sprintf('FullList_deg%d_%s.mat',N,typernd),'FullList','FullListType')
