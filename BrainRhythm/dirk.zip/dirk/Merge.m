function [merged] = Merge(left, idleft, right, idright, varargin)
% Marge: merges two files or two data structures on the basis of one or
% more identifier columns.
%  left, right: 2-D data matrices or strings pointing to 
%
%  'hasheader': 1 or 0. ignores first line in datafile when 1. def=1
%  'delimiter': char. reads file with delimiter. def='\t'
%  'match'    : 'and','or','left','right'. Include cases as specified.

if nargin<4,
    error('must specify two data files or data structures and their id columns')
end

if mod(varargin,2)~=0
    error('All extra input must have key-value structure');
end

% default values
cDel = '\t';
cHeader = 1;

for v=1:2:length(varargin)
    if strcmpi(varargin{v},'del') || strcmpi(varargin{v},'delimiter')
        cDel = varargin{v+1};
    end
    if strcmpi(varargin{v},'hasheader')
        cHeader = varargin{v+1};
    end
end

if ischar(left) 
    if cHeader
        H1=ReadHeader(left);
        D1=dlmread(left,'\t',1,0);
    else
        H1=[];
        D1=dlmread(left,'\t',1,0);
    end
else
    D1=left;
end
    
if ischar(right) 
    if cHeader
        H2=ReadHeader(right);
        D2=dlmread(right,'\t',1,0);
    else
        H2=[];
        D2=dlmread(right,'\t',1,0);
    end
else
    D2=right;
end

% get Ids
for c=1:size(idleft)



end

return

%%
function [header]=ReadHeader(file)

fid=fopen(file);
line=fgetl(fid);
fclose(fid);

temp = textscan(line,'%s');
header=temp{1};

