function S = sum_NaN(D,varargin)

D(find(isnan(D(:))))=0;

S = sum(D,varargin{:});
