function Z=fisher(R)
% do fisher transform of input correlation(s). See also: finsherinv.m

Z=zeros(size(R,1),size(R,2));
for row=1:size(R,1)
    for col=1:size(R,2)
        Z(row,col)=0.5*log((1+R(row,col))/(1-R(row,col)));
    end
end
