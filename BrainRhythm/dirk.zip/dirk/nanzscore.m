function z = nanzscore(data)

z = (data-repmat(nanmean(data),size(data,1),1))./repmat(nanstd(data),size(data,1),1);

