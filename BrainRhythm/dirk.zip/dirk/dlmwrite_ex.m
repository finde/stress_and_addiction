function [] = dlmwrite_ex(name, data, del, fmt, header)
%function [] = dlmwrite_ex(name, data, del, fmt, header);
% 
% writes data matrix to a file like dlmwrite, but also writes a header
% line. Overwrites files without warning! Usage:
%   - name: file name (string)
%   - data: data matrix (numerical)
%   - delimmiter: e.g., ',' or '\t'
%   - fmt: 
%     - fprintf-style code, e.g. %d or %8.4f to be used for all columns
%     - a cell array of fprintf-style codes, to be used for each column
%     - a number holding decimal precision to be used for all columns
%     - a vector holding decimal precision to be used for each column
%   - header: cell array of strings

if nargin<5,
    header={};
end

fid = fopen(name, 'w');
if fid <= 0
    error(sprintf('Could not open file "%s"\n', name));
end

if ~isempty(header)
    fprintf(fid, header{1});
    for c=2:length(header)
        fprintf(fid, [del header{c}]);
    end
    fprintf(fid, '\n');
end

% check for format string
if iscell(fmt) || isnumeric(fmt)
    if length(fmt)~=1 && length(fmt)~=size(data,2)
        error('wrong number of format strings')
    end
end

dolong = 0;
if iscell(fmt)
    % create new format string from cell array and delimiter
    s = fmt;
    fmt = s{1};
    for c=2:length(s)
        fmt = [fmt del s{c}];
        dolong = 1;
    end
elseif isnumeric(fmt)
    % convert to format string
    s = fmt;
    fmt = sprintf('%%.%df',s(1));
    for c=2:length(s)
        fmt = [fmt del sprintf('%%.%df',s(c))];
        dolong = 1;
    end
end

% dolong means that the fmt string is in long format with one % marker per
% number. Otherwise, you need to expand the fmt string to full length for a
% row.
if ~dolong
    fprintf(fid,[fmt repmat([del fmt],1,size(data,2)-1) '\n'],data');
else
    fprintf(fid, fmt, data');
end
fclose(fid);