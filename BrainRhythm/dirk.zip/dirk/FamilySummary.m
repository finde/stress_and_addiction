function [Res Means] = FamilySummary(Data,FamCol,SibCol,DataCol,varargin)
% function [Res Means] = FamilySummary(Data,FamCol,SibCol,DataCol,varargin)
%
% create a summary of the familiy structure in data. twins can be coded
% 1-2, and sibs 3..20, but other coding schemes can be specified.
% FamCol holds familiy identifier
% SibCol holds sibling code 
% 
% 'missing': missing data value (def=NaN)
%
% 'twinset': 1,2 vactor with codes. E.g. whenever data in sibcol has these
% values data is assumed to represent data for twins. (def=[1 2])
%
% 'sibset': 1,2 vector of upper and lower limits for valid codes for
% siblings (def=[3 20]).
%
% 'sexcol': column number of sex variable. Will add extra output split by
% sex (M-M, F-F, and M-F relationships). Output 'Res' will be a 1x4 cell
% array
%
% 'sexval': values for the sexes. Default [0 1]
%
% Output: Res: count results 
%         Means: mean values

Missing=NaN;
twinset=[1 2];
sibset=[3 20];
sexcol=[];
sexval=[0 1];
domeans=nargout>1;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'missing')
        Missing=varargin{v+1};
    elseif strcmpi(varargin{v},'twinset')
        twinset=varargin{v+1};
    elseif strcmpi(varargin{v},'sibset')
        sibset=varargin{v+1};
    elseif strcmpi(varargin{v},'sexcol')
        sexcol=varargin{v+1};
    elseif strcmpi(varargin{v},'sexval')
        sexval=varargin{v+1};
    end
end


TempData={};
TempData{1}=Data(:,[FamCol SibCol DataCol]);
if ~isempty(sexcol)
    for sex=1:2
        TempData{end+1}=Data(find(Data(:,sexcol)==sexval(sex)),[FamCol SibCol DataCol]);
    end
    % add a dummy family with enough members to force the correct number of
    % columns
    fam=max(Data(:,FamCol))+1;
    sibs=unique(Data(:,SibCol));
    for i=1:length(TempData)
        for sib=1:length(sibs)
            TempData{i}(end+1,:)=[fam sibs(sib) Missing];
        end
    end
end

% clear result and restructure data and get number of subjects
Res={};
for i=1:length(TempData)
    Res{i}=struct;
    if domeans
        Means{i}=struct;
    end
    if ~isnan(Missing)
        f=find(TempData{i}(:,3)==Missing);
        TempData{i}(f,3)=NaN;
    end
    
    % twins + sibs info
    valid=find(~isnan(TempData{i}(:,3)));
    Res{i}.NTotal=length(valid);
    if domeans
        Means{i}.Avg=mean(TempData{i}(valid,3));
        Means{i}.Std=std(TempData{i}(valid,3));
    end
    % twins info
    twinsvalid=intersect(valid,find(TempData{i}(:,2)>=twinset(1)&TempData{i}(:,2)<=twinset(2)));
    Res{i}.NTwin=length(twinsvalid);
    if domeans
        Means{i}.AvgTwin=mean(TempData{i}(twinsvalid,3));
        Means{i}.StdTwin=std(TempData{i}(twinsvalid,3));
    end
    sibsvalid=intersect(valid,find(TempData{i}(:,2)>=sibset(1)&TempData{i}(:,2)<=sibset(2)));
    Res{i}.NSib=length(sibsvalid);
    if domeans
        Means{i}.AvgSib=mean(TempData{i}(sibsvalid,3));
        Means{i}.StdSib=std(TempData{i}(sibsvalid,3));
    end

    TempWide{i}=Restructure(TempData{i},'id',1,'index',2,'missing',NaN);
end



% get number of complete twin pairs
for i=1:length(TempData)
    valid=1:size(TempWide{i},1);
    for c=2:3
        valid=intersect(valid,find(~isnan(TempWide{i}(:,c))));
    end
    Res{i}.NComplTwinPairs=length(valid);
end

% get number of sibling relations
for i=1:length(TempData)
    if size(TempWide{i},2)>3, % siblings available
        valid=zeros(size(TempWide{i},1),size(TempWide{i},2)-3);
        for c=2:size(TempWide{i},2)
            valid(:,c-1)=~isnan(TempWide{i}(:,c));
        end
        valid=sum(valid,2); % valid holds the number of family members
    
        accu=zeros(length(valid),1);
        for i2=1:length(valid)
            accu(i2)=sum(1:valid(i2)-1); % number of relations in this family
        end
    
        Res{i}.NSibTwinRelations = sum(accu);
        Res{i}.NSibRelations = sum(accu) - Res{i}.NComplTwinPairs;
    else
        Res{i}.NSibTwinRelations = Res{i}.NComplTwinPairs;
        Res{i}.NSibRelations = 0;
    end
end

if length(TempData)==3
    Res{4}.NTotal=Res{1}.NTotal-Res{2}.NTotal-Res{3}.NTotal;
    Res{4}.NTwin=Res{1}.NTwin-Res{2}.NTwin-Res{3}.NTwin;
    Res{4}.NSib=Res{1}.NSib-Res{2}.NSib-Res{3}.NSib;
    Res{4}.NComplTwinPairs = Res{1}.NComplTwinPairs-Res{2}.NComplTwinPairs-Res{3}.NComplTwinPairs;
    Res{4}.NSibTwinRelations = Res{1}.NSibTwinRelations-Res{2}.NSibTwinRelations-Res{3}.NSibTwinRelations;
    Res{4}.NSibRelations = Res{1}.NSibRelations-Res{2}.NSibRelations-Res{3}.NSibRelations;
elseif length(Res)==1
    Res=Res{1};
end

if domeans
    if length(Means)==1
        Means=Means{1};
    end
end
