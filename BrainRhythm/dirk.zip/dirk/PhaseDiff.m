function phdiff = PhaseDiff(X,varargin)
% function phdiff = PhaseDiff(X,varargin)
%
% calculates the pahse difference betweeen all possible pairs of columns in matrix X
%
% varargin:
%  - 'reference'    : pass a reference signal and calculate pahse
%                     difference for each column in X in stead of pairwise.
%  - 'differentiate': differentiate the resulting phase difference signals
%                     (default = 0)
%  - 'difftype'     :'diff' or 'savgolay' type of differentiation (default=diff)

if nargin==0
    help PhaseDiff
    return
end

skip=0;
vlist = varargin;
if size(X,2)>size(X,1)
    warning('Are the data in columns?')
end

differentiate = 0;
difftype = 'diff'; % alternatively: savgolay
reference = [];

for v=1:2:length(vlist)
    switch vlist{v}
        case 'differentiate'
            differentiate = vlist{v+1};
        case 'difftype'
            difftype = vlist{v+1}; %
        case 'reference'
            reference = vlist{v+1}; %
    end
end

% initialise
len = size(X,1);
N=size(X,2);
ph=zeros(len,N);
phcorr=ph;

% loop thru all signals (plus possible reference signal)
for col=1:N+~isempty(reference)
    if col<=N
        H = hilbert(X(:,col));
    else
        H = hilbert(reference);
    end
    ph(:,col)=atan(imag(H)./real(H));

    % smoothen the phase signal (remove the sawtooth pattern)
    d = [0 ; diff(ph(:,col))];
    offset = cumsum((d>=(pi/2-.1)) - (d<-(pi/2+.1)));
    phcorr(:,col) = ph(:,col)-offset*pi;
    
    % smooth (correct) the phase
    %ndx=(~(diff(ph)>-pi/2&diff(ph)<pi/2).*diff(ph)<0);
    %offset = ([[0 0];cumsum(ndx)]);
    %offset = [zeros(1,size(ndx,2)) ; cumsum(ndx)];
    %phcorr = ph + offset.*pi/2;
    
    %offset=0;
    %phcorr(1,col)=ph(1,col);
    %for s=2:length(ph(:,col))
    %    if ph(s,col)>ph(s-1,col)+pi-1
    %        offset=offset-pi;
    %    elseif ph(s,col)<ph(s-1,col)-pi+1
    %        offset=offset+pi;
    %    end
    %    phcorr(s,col)=ph(s,col)+offset;
    %end
end

if isempty(reference)
    phdiff = zeros(size(phcorr,1),N*(N-1)/2);
    count=0;
    for col1=1:N-1
        for col2=col1+1:N
            count=count+1;
            temp = phcorr(:,col1)-phcorr(:,col2);
            ndx=(~(diff(temp)>(-pi/2+.1) & diff(temp)<(pi/2-.1)) .* diff(temp)<0);
            offset = ([0;cumsum(ndx)]);
            phdiff(:,count) = temp + offset.*pi/2;
        end
    end
else
    % calculate phase difference against signal 'reference'
    phdiff = zeros(size(phcorr,1),1);
    for col=1:N
        temp = phcorr(:,col)-phcorr(:,end);
        ndx=(~(diff(temp)>(-pi/2+.1) & diff(temp)<(pi/2-.1)) .* diff(temp)<0);
        offset = ([0;cumsum(ndx)]);
        phdiff(:,col) = temp + offset.*pi/2;
    end
end

%for x=1:derive
%    phdiff=diff(phdiff);
%end

if differentiate
    switch difftype
        case 'diff'
            for lp=1:differentiate
                phdiff = diff(phdiff);
            end
        case 'savgolay'
            phdiff = savgolay_filt((1:len)',phdiff,2,5,1);
    end
    phdiff = mod(phdiff+pi,2*pi)-pi;
    % adjust for large jumps (+/- pi)
    %ndxup = [zeros(1,size(phdiff,2)) ; cumsum(diff(phdiff)>pi)];
    %ndxdown = [zeros(1,size(phdiff,2)) ; cumsum(diff(phdiff)<-pi)];
    %D = conv2(phdiff,ones(1,5)','same');
    %ndxup2 = [zeros(1,size(phdiff,2)) ; cumsum(localmin(-D)&D>2)];
    %ndxdown2 = [zeros(1,size(phdiff,2)) ; cumsum(localmin(D)&D<-2)]; 
    % phdiff = phdiff+(ndxdown-ndxup+ndxdown2-ndxup2)*pi;
end
   
  
%for rep=1:2
%    for col=1:size(phdiff,2)
%        d = [0 ; diff(phdiff(:,col))];
%        offset = cumsum((d>=(pi/2)) - (d<-(pi/2)));
%        phdiff(:,col) = phdiff(:,col)-offset*pi;
%    end
%end

    
    
    