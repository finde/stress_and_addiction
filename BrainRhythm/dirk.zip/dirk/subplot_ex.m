function h = subplot_ex(nrow,ncol,pos)

if nargin<3 || size(pos,2)~=2
    error('Position must have two columns specifying row and column number');
end

x = [];
for p=1:size(pos,1)
    x = [x (1 + (pos(p,1)-1)*ncol + mod(pos(2)-1,ncol))];
end

h = subplot(nrow,ncol,x);

