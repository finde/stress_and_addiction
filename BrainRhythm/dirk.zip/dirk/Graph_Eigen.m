function [eigval eigvec laplacian] = Graph_Eigen(Graph)

N=size(Graph,1);
if N<1 || N~=size(Graph,2)
    error('Graph must be non-empty and square');
end

Graph(logical(eye(N)))=0;

laplacian=-Graph;
laplacian(logical(eye(N))) = sum(Graph);

if nargout>1
    [eigvec eigval]= eig(laplacian);
    eigval=diag(eigval);
else
    eigval= eig(laplacian);
end
