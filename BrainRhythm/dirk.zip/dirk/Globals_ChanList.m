function Chans = Globals_ChanList(N,plabels)
% Creates channel list with N channels. N can be:
% - 10: overlap between OZ and Dutch studies
% - 12: Overlap between Dutch studies
% - 14: Channels for age groups 5, 7, 16, 18 (Nihon Koden Setup)
% - 17: 10/20 Channels without fp1, fp2 for Adult groups 25, 50. In
%       addition, F1 and F2 are removed.
% - 22: All available channels for adults with Neuroscan measurements
%       (about 100 measurements).
%
% set plabels to 1 to retrieve P7 P8 in stead of T5 T6.

if nargin<2
    plabels=0;
end

H={};
% Dutch + OZ
H{10} = {'F3','F4','F7','F8','C3','C4','P3','P4','O1','O2'};  
Hb{10} = {'F3','F4','F7','F8','C3','C4','P3','P4','O1','O2'};  
% Dutch
H{12} = {'F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','T5','T6'};
Hb{12} = {'F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','P7','P8'};
% 14 leads for 5, 7, 16 and 18
H{14} = {'Fp1','Fp2','F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','T5','T6'};
Hb{14} = {'Fp1','Fp2','F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','P7','P8'};
% 15 leads for OZ
H{15} = {'Fp1','Fp2','F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','Fz','Cz','Pz'}; % for OZ
Hb{15} = {'Fp1','Fp2','F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','Fz','Cz','Pz'}; % for OZ
% 17 leads for 25 and 50
H{17} = {'F7','F3','Fz','F4','F8','T7','C3','Cz','C4','T8','T5','P3','Pz','P4','T6','O1','O2'};
Hb{17} = {'F7','F3','Fz','F4','F8','T7','C3','Cz','C4','T8','P7','P3','Pz','P4','P8','O1','O2'};
% 22 full list for neuroscan
H{22} = {'Fp1','Fp2','F7','F3','F1','Fz','F2','F4','F8','T7','C3','Cz','C4','T8','T5','P3','Pz','P4','T6','O1','Oz','O2'};
H{22} = {'Fp1','Fp2','F7','F3','F1','Fz','F2','F4','F8','T7','C3','Cz','C4','T8','P7','P3','Pz','P4','P8','O1','Oz','O2'};

if plabels
    Chans = Hb{N};
else
    Chans = H{N};
end
if isempty(Chans)
    error('Invalid number of channels.')
end