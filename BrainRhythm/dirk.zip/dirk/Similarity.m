function K = Similarity(X, varargin)

% Calculate the euclidian distance of observations (rows) on variables
% (columns). Options
% - 'standardize': true/[false] first standardize X columnwise to zero mean
%   variance 1

cStan = false;
for v=1:2:length(varargin)
    if strncmpi(varargin{v},'stand',5)
        cStan = logical(varargin{v+1};
    end
end

if cStan
    X = (X - repmat(nanmean(X),size(X,1),1)) ./ repmat(nanstd(X),size(X,1),1);
end

K = pdist2(X,X);


