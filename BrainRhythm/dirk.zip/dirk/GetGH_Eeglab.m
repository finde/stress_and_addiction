function [G H] = GetGH_Eeglab(EEG, m)

% Calculate for the CSD toolbox the G and H matrices from the montage
% stored in EEG.chanlocs.

if nargin<2
    m = 4;
end
if m<2 || m>10
    error('Parameter m cannot exceed 10 or be lower than 2')
end

M = struct;
M.lab = {EEG.chanlocs.labels};
M.theta = [EEG.chanlocs.sph_theta];
M.phi = [EEG.chanlocs.sph_phi];

[G H] = GetGH(M, floor(m));

