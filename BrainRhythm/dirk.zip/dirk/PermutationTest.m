function stats = PermutationTest(n,X,Y,func)

% permute of a correlation coefficient. Returns the list of correlatins
% after permuting the X and Y. Keeps X and Y intact within themselves.
% NOTE: func is not a function handle, but a string.

if nargin<4
    func = 'max';
end

clear stats
stats=struct;

% use the shuffle mex function for speed
permute = Shuffle(repmat((1:length(Y))',1,n));

cmd = sprintf('%s(corr(X,Y,''rows'',''pairwise''))''',func);
stats.R = eval(cmd);

cmd = sprintf('%s(corr(X,permute,''rows'',''pairwise''))''',func);
stats.list = eval(cmd);
stats.median = median(stats.list);



