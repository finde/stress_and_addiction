function data = mvrnorm(N,R,varargin)
% function data = mvrnorm(N,R,varargin)
%   calculates a data matrix with N observations (rows) and a correlation
%   matrix of (about) square standardized matrix R. The number of variables
%   depends on the size of R.
%
%   - N: Scalar integer, number of rows (observations) in the data matrix.
%        Default 100.
%   - R: Defaults to [1 .5; .5 1]. Or specified as:
%      * symmatric correlation matrix of population correlations between
%        then columns of data (if 'empirical' option set to 1, then the
%        corr(data) will be exactly R.)
%      * scalar for a Nx2 data matrix with correlation R
%      * vector of subdiagonal elements of a correlation matrix (first
%        element becomes R(2,1), second R(3,1), third R(3,2), etc.)
% 
%   varargin:
%   - 'mu'   : vector length (size(R,1)) with means for the variables
%   - 'sigma': vector length (size(R,1)) with SDs for the variables
%   - 'empirical': (1/0) exactly recreate the correlation matrix R if true,
%      in stead of the expected (population) matrix. Default 0.


if nargin<1
    N=[];
end
if nargin<2
    R=[];
end
if isempty(N)
    N=100;
end
if isempty(R)
    R=[1,.5;.5,1];
end
if isvector(R) % either vector or scalar, will result in correct matrix
    R=sdiag(R);
    R=R+R';
    R(logical(eye(size(R,1))))=1;
end


P = size(R,1);
if size(R,1) ~= size(R,2)
    error('R must be (symmetric) correlation matrix')
end
if sum(R(logical(eye(P)))) ~= P
    error('R must be (symmetric) correlation matrix')
end
for row=1:P-1
    for col=row+1:P
        if R(row,col)~=R(col,row)
            error('R must be (symmetric) correlation matrix')
        end
    end
end

sd=ones(1,P);
mu=zeros(1,P);
empirical = false;
for v=1:2:length(varargin)
    switch lower(varargin{v})
        case 'mu'
            mu = varargin{v+1};
        case 'sigma'
            sd = varargin{v+1};
        case 'empirical'
            empirical = varargin{v+1};
    end
end

% create uncorrelated observations
X = randn(N, P);
if empirical
    X = X-repmat(mean(X),N,1);
    [~ , ~, V] = svd(X); 
    X = X * V;
    X = X ./ repmat(std(X),N,1);
end

% induce correlation with cholesky
Y = X*chol(R);

% transform with means and sd's, check
data = repmat(mu,N,1) + Y.*repmat(sd,N,1);

