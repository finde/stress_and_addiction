function [R N]=corrcoef_NaN(Data, Missing, varargin)

% function [R N]=corrcoef_NaN(Data, Missing, varargin)
%   calculate correlation matrix with missing data. Default=NaN
%
% input:
% - Data: 2D data matrix wiith data in columns
% - Missing: (def=NaN) missing data value
% - varargin:
%   - 'global': 0/1 calculate a global subset, correlation in calculated
%     for subjects with all data only. Otherwise, pairwaise sets are
%     determined. in that case, output N will have the same size as the
%     correlation matrix.
% 
% output:
% - R: (n x n)correlation matrix
% - N: number of valid subjects ('global'=1) or (n x n) matrix with the
%   number of subjects for the pairwaise calculation of the correlation

if nargin<2,
    Missing=NaN;
end
if size(Data,3)>1
    error('Only 2D matrices are valid data.')
end
if size(Data,2)<2
    R=[1];
    return
end

doglobalsubset=1;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'global')
        doglobalsubset=varargin{v+1};
    end
end

if doglobalsubset
    set=ones(size(Data,1),size(Data,2));
    for col=1:size(Data,2)
        if isnan(Missing)
            set(:,col)= ~isnan(Data(:,col));
        else
            set(:,col)= Data(:,col) ~= Missing;
        end
    end
    subset=find(sum(set,2)==size(Data,2));
    R=corrcoef(Data(subset,:));
    N=length(subset);
else
    for col1=1:size(Data,2)
        for col2=col1:size(Data,2)
            if col1==col2
                R(col1,col1)=1.0;
                if isnan(Missing)
                    N(col1,col1)=length(find(~isnan(Data(:,col1))));
                else
                    N(col1,col1)=length(find(Data(:,col1)~=Missing));
                end
            else
                if isnan(Missing)
                    ndx = find(~isnan(Data(:,col1))&~isnan(Data(:,col2)));
                    N(col1,col2)=length(ndx);
                    N(col2,col1)=length(ndx);
                else
                    ndx = find(Data(:,col1)~=Missing&Data(:,col2)~=Missing);
                    N(col1,col2)=length(ndx);
                    N(col2,col1)=length(ndx);
                end
                try
                    temp=corrcoef(Data(ndx,[col1 col2]));
                    R(col1,col2)=temp(2,1);
                    R(col2,col1)=temp(2,1);
                catch
                    R(col1,col2)=temp;
                    R(col2,col1)=temp;
                end                    
            end
        end
    end
end
    

    