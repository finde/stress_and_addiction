function idx = minindex(x)

[~,idx] = min(x);