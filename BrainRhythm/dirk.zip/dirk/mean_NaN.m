function y = mean(x,dim,missing)
%MEAN   Average or mean value.
%   For vectors, MEAN(X) is the mean value of the elements in X. For
%   matrices, MEAN(X) is a row vector containing the mean value of
%   each column.  
%
%   MEAN(X,DIM) takes the mean along the dimension DIM of X. 
%   MEAN(X,DIM,MISSING) takes MISSING as missing values, default: NaN


if nargin==1 || isempty(dim), 
  % Determine which dimension SUM will use
  dim = min(find(size(x)~=1));
  if isempty(dim), dim = 1; end
end

if nargin<3
    missing=NaN;
end

switch dim
    case 1,
        sm =zeros(1,size(x,2),size(x,3));
    case 2,
        sm =zeros(size(x,1),1,size(x,3));
    case 3,
        sm =zeros(size(x,1),size(x,2),1);
    case 4,
        sm =zeros(size(x,1),size(x,2),size(x,3),1);
end
cnt=sm;

try
    for d1=1:size(x,1)
        for d2=1:size(x,2)
            for d3=1:size(x,3)
                for d4=1:size(x,4)
                    v=x(d1,d2,d3,d4);
                    if isnan(missing)
                        hit = isnan(v);
                    else
                        hit=(v==missing);
                    end
                    if ~hit,
                        switch dim
                            case 1,
                                sm(1,d2,d3)=sm(1,d2,d3)+v;
                                cnt(1,d2,d3)=cnt(1,d2,d3)+1;
                            case 2,
                                sm(d1,1,d3)=sm(d1,1,d3)+v;
                                cnt(d1,1,d3)=cnt(d1,1,d3)+1;
                            case 3,
                                sm(d1,d2,1)=sm(d1,d2,1)+v;
                                cnt(d1,d2,1)=cnt(d1,d2,1)+1;
                            case 4,
                                sm(d1,d2,d3,1)=sm(d1,d2,d3,1)+v;
                                cnt(d1,d2,d3,1)=cnt(d1,d2,d3,1)+1;
                        end
                    end
                end
            end
        end
    end
catch
    disp('error');
end

y=sm./cnt;

if ~isnan(missing)
    for col=1:size(y,2)
        f=find(isnan(y(:,col)));
        if ~isempty(f)
            y(f,col)=missing;
        end
    end
end
 