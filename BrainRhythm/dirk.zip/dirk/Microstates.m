function [a b times] = Microstates(Data, k, Filt, Chanlocs)


if nargin<4
    Chanlocs = [];
end
if nargin<3 || isempty(Filt)
    cDoFilt=false;
else
    if length(Filt)~=3
        error('Filt must specify lp, hp, and rate');
    end
    cDoFilt = 1;
end
if nargin<2 || isempty(k)
    k=4;
end

if cDoFilt
    Data = filter_fir(Data',Filt(3), Filt(1), Filt(2), 3.0)';
end

[a b c] = kmeans(Data,k,'maxiter',200);

if ~isempty(Chanlocs)
    figure;
end

ncols = floor(sqrt(10)+.707);
nrows = ceil(sqrt(10)+.707);

for kk=1:k
    times{kk} = LifeTime(a==kk, 0);
    if ~isempty(Chanlocs)
        subplot(nrows,ncols,kk);
        topoplot(b(kk,:),Chanlocs);
    end
end

