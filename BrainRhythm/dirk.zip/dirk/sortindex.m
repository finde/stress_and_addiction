function idx = sortindex(X,order)

if nargin<2
    [~,idx] = sort(X);
else
    [~,idx] = sort(X,order);
end
