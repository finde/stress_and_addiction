function Res = gee(Y, X ,ClusterId,varargin)

% simple generalized estimation equation implementation for continuous data
% and normal distributions (no link functions can be specified),
% "independent" working correlation only (Now adding equi/exchageable)
%
% - Y: dependent data (univariate)
% - X: predictors. Fixed column will be added
% - ClusterId: vector with cluster IDs, such as family number

if nargin<4
    R=0;
end

if size(Y,2)~=1
    error('Dependent data Y must be a column vector')
end
if size(Y,1)~=size(X,1)
    error('Independent and dependent data X and Y must have the same number of rows')
end
valid = ~isnan(sum([X,Y],2));
X = X(valid,:);
Y = Y(valid,:);
ClusterId = ClusterId(valid);

% essential, first sort the data on cluster ID
if ~issorted(ClusterId)
    warning('Sorting the data')
    [ClusterId,ndx] = sort(ClusterId);
    Y = Y(ndx,:);
    X = X(ndx,:);
end

% X = [ones(size(X,1),1) X];
linmod = fitlm(X,Y,'linear');

% obtain residuals to start estimating robust SEs
rsd = linmod.Residuals.Raw;

% create a masking block matrix suitable for variable family/cluster sizes
N = size(Y,1);
ClustMask = zeros(N);
UniqueClustID = unique(ClusterId);
NFam = length(UniqueClustID);
AllOnes = {};
for clust=1:NFam
    AllOnes{clust} = ones(sum(ClusterId==UniqueClustID(clust)));
end    
ClustMask = blkdiag(AllOnes{:});
% ClustMask(logical(eye(N))) = 0;

Z = (rsd * rsd') .* ClustMask;


% add intercept column
X = [ones(size(X,1),1) X];
tX = X';
XXi = inv(tX * X);
XXitX = XXi * tX;
Cov = XXitX * Z * XXitX';
SE = sqrt(diag(Cov));



% accumulate results
Res = struct;
Res.Beta      = linmod.Coefficients.Estimate;
Res.SE        = linmod.Coefficients.SE;
Res.Pval      = linmod.Coefficients.pValue;
Res.T         = linmod.Coefficients.tStat;
Res.RobustSE  = SE;
Res.RobustZ   = Res.Beta ./ SE;
Res.RobustPval= 2*cdf('norm',-abs(Res.RobustZ),0,1);
Res.Resid       = (rsd*rsd');
Res.ResidMasked = Z;
Res.ResidCov    = Cov;

%{ 

original script by Camelia Minica (in R):

X=matrix(1,nfam*nsib,2) #b0
X[,2]=datav[,1] # b1
datav[,11]=datav[,2]-(datav[,1]*b1+b0)
Z=outer(datav[,11],datav[,11])*diag(nfam)%x%matrix(1,nsib,nsib) 
tX=t(X)
XXi=solve(tX%*%X)
XXitX=XXi%*%tX
covb7=XXitX%*%Z%*%t(XXitX)
sterrs7=sqrt(diag(covb7))
%}

