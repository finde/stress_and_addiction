function X = mvrnorm(N,R,varargin)
% function data = mvrnorm(N,R,varargin)
%   calculates a data matrix with N observations (rows) and a correlation
%   matrix of (about) square standardized matrix R. The number of variables
%   depends on the size of R.
%   varargin:
%   - 'mu'   : vector length (size(R,1)) with means for the variables
%   - 'sigma': vector length (size(R,1)) with SDs for the variables

if nargin<1
    N=[];
end
if nargin<2
    R=[];
end
if isempty(N)
    N=100;
end
if isempty(R)
    R=[1,.5;.5,1];
end
P = size(R,1);
if size(R,1) ~= size(R,2)
    error('R must be (symmetric) correlation matrix')
end
if sum(R(logical(eye(P)))) ~= P
    error('R must be (symmetric) correlation matrix')
end
for row=1:P-1
    for col=row+1:P
        if R(row,col)~=R(col,row)
            error('R must be (symmetric) correlation matrix')
        end
    end
end

sd=ones(1,P);
mu=zeros(1,P);
for v=1:2:length(varargin)
    switch lower(varargin{v})
        case 'mu'
            mu = varargin{v+1};
        case 'sigma'
            sd = varargin{v+1};
    end
end




[evec eval] = eig(R);
eval = diag(eval);
[~,ndx] = sort(eval,'descend');
eval = eval(ndx);
evec = evec(:,ndx);
 
% get zero correlated random values
X = randn(N,P);
X = X-repmat(mean(X),N,1);
[~ , ~, V] = svd(X); 
X = X * V;
X = X ./ repmat(std(X),N,1);
% create correlation
X = (evec * diag(repmat(sqrt(max(eval(:))),P,1)) * X')';
        
        
%{ 
BASED ON R CODE:
mvrnorm <-
    function(n = 1, mu, Sigma, tol=1e-6, empirical = FALSE, EISPACK = FALSE)

    p <- length(mu)
    if(!all(dim(Sigma) == c(p,p))) stop("incompatible arguments")
    if (missing(EISPACK)) EISPACK <- getOption("mvnorm_use_EISPACK", FALSE)
    eS <- eigen(Sigma, symmetric = TRUE, EISPACK = EISPACK)
    ev <- eS$values
    if(!all(ev >= -tol*abs(ev[1L]))) stop("'Sigma' is not positive definite")
    X <- matrix(rnorm(p * n), n)
    if(empirical) {
        X <- scale(X, TRUE, FALSE) # remove means
        X <- X %*% svd(X, nu = 0)$v # rotate to PCs
        X <- scale(X, FALSE, TRUE) # rescale PCs to unit variance
    }
    X <- drop(mu) + eS$vectors %*% diag(sqrt(pmax(ev, 0)), p) %*% t(X)
    nm <- names(mu)
    if(is.null(nm) && !is.null(dn <- dimnames(Sigma))) nm <- dn[[1L]]
    dimnames(X) <- list(nm, NULL)
    if(n == 1) drop(X) else t(X)
%}

