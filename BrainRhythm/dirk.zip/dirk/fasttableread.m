function T = fasttableread(Filename, fmt, varargin)

% Reads a file into a struct. Requires that the file is a rectangular file
% (i.e. the same number of words per line). fmt determins the data format
% to be read and should be in TEXTSCAN format (%d, %f, etc.).
% 
% - Filename: <string> name of the file
% - fmt     : <string> either full fscanf read format, e.g. '%s %d %f' to
%             read a string, an integer, and a double. Alternatively, a
%             string of characters e.g. 'ssdffd' to read two strings, an
%             int, two doubles, and another int.
% 
% varargin options
%   - 'missingstr': <string> will be interpreted as missing. issing strings
%                   result in nan or ''. 
%   - 'header': <string cell array> variable names to be assigned when no
%               header is to be read form file. Assumes first line are
%               data. (default read from file)
%   - 'del'   : <char> delimiter character (default \t)
%   - 'multipledelimsasone': passed to textscan (default 1)

cHeader = '';
cMissingStr = 'NA';
cDelimiter = '\t';
cMultipleDelimsAsOne = 1;
for v=1:2:length(varargin)
    if strncmpi(varargin{v},'miss',4)
        cMissingStr = varargin{v+1};
    elseif strncmpi(varargin{v},'head',4)
        cHeader = varargin{v+1};
    elseif strncmpi(varargin{v},'del',3)
        cDelimiter = varargin{v+1};
    elseif strncmpi(varargin{v},'mult',4)
        cMultipleDelimsAsOne = varargin{v+1};
    else
        error('Unknown option %s',varargin{v})
    end
end

if isempty(cHeader)
    cReadHeader = true;
else
    cReadHeader = false;
end

if isempty(strfind(fmt,'%'))
    % tmp = [repmat('%',1,length(fmt)); fmt; repmat(' ',1,length(fmt));];
    tmp = [repmat('%',1,length(fmt)); fmt];
    fmt = tmp(:)';
    % fmt = fmt(1:end-1);
end
    

% start reading file
fid = fopen(Filename,'r');
if fid<1
    error('Cannot open file %s',Filename)
end

if cReadHeader
    tmp = textscan(fgetl(fid),'%s','delimiter',cDelimiter);
    cHeader = tmp{1};
    for h=1:length(cHeader)
        cHeader{h} = cHeader{h}(isstrprop(cHeader{h},'alphanum'));
        if ~isstrprop(cHeader{h}(1),'alpha')
            cHeader{h} = ['x' cHeader{h}];
        end
    end
end

if cDelimiter==' '
    body = textscan(fid, fmt, 'multipledelimsasone', cMultipleDelimsAsOne, 'collectoutput', 0, 'treatasempty', cMissingStr); % will read as long as possible
else
    body = textscan(fid, fmt, 'whitespace', cDelimiter, 'multipledelimsasone', cMultipleDelimsAsOne, 'collectoutput', 0, 'treatasempty', cMissingStr); % will read as long as possible
end
if length(body) ~= length(cHeader)
    fprintf('Detected columns:\n')
    cellfun(@(x)fprintf(' %s',x),cHeader);
    fprintf('\n');
    error('header and data must have same number of columns (%d and %d resp.)', length(cHeader), length(body))
end
fclose(fid);

try
    T = table(body{:},'variablenames',cHeader);
catch E
    throw(E)
end
clear body






    


