function [List Dir]= Globals_List(Age, Root)
% returns the file list associated with this age group in the EEG
% experiments of Caroline van Baal (ages 5, 7), Toos van Beijsterveldt
% (ages 16 and 18), and Danielle Posthuma (ages 25 and 50, or 2550 for the
% whole group). REQUIRES THE FILES RegExt in the /Alle data/ directory
% 
% ChanList is the full channels list for this dataset (note, for ages 25
% and 50 this is the full list with Fp1 Fp2 Oz inlcuded, which was only
% available for the Neuroscan measured subjects.

if nargin<2
    Root = '/Volumes/Data 4TB/Alle data';
end
if ~exist(Root)
    error('No such directory');
end

clear List

List=struct;
addpath(Root)


% read data
if Age==2550
    % Danielle
    [RegExt25] = dlmread_ex('RegExt25.txt','\t',1);
    [RegExt50] = dlmread_ex('RegExt50.txt','\t',1);
    RegExt = [RegExt25;RegExt50];
else
    % Toos of Caroline of OZ of WUSTL
    [RegExt RegExtH] = dlmread_ex(sprintf('RegExt%02d.txt',Age),'\t',1);
end

% create file list
if Age>100 && Age<2550
    % warning('Still need to check whether sex:male=1 and female=0')
    % CHECKED! And a recode was needed.
    Subj = RegExt(:,1)*100+RegExt(:,2);
    [~,idx] = sort(Subj);
    RegExt = RegExt(idx,:);
    
    for pp=1:size(RegExt,1)
        List(pp).Fam = RegExt(pp,1);
        List(pp).Sib = RegExt(pp,2);
        List(pp).Reg = RegExt(pp,1);
        List(pp).Ext = RegExt(pp,2);
        List(pp).Wave = Age-100;
        List(pp).Subject = Subj(pp);
        List(pp).Unique = List(pp).Subject*100+(Age-100);
        List(pp).Zygosity = RegExt(pp,4);
        List(pp).Sex = RegExt(pp,5);
        List(pp).Age = RegExt(pp,8);
        List(pp).Filename = RegExt(pp,3);
    end

    % Correct zygosity to Zyg5
    done = false(size(RegExt,1),1);
    for pp=1:size(RegExt,1)
        if List(pp).Sib==1
            Sex1 = List(pp).Sex;
            if List(pp+1).Fam ~= List(pp).Fam
                warning(sprintf('Mistake in file. Other twin not found. Assume same sex (Filenum: %d)',List(pp).Filename));
                Sex2 = Sex1;
            else
                Sex2 = List(pp+1).Sex;
            end
        
            if List(pp).Zygosity==1     %MZ
                if Sex1==1 && Sex2==1     %MZM
                    Zyg5=1;
                elseif Sex1==0 && Sex2==0 %MZM
                    Zyg5=2;
                else
                    error('Can''t be');
                end
            elseif List(pp).Zygosity==2 %DZ
                if Sex1==1 && Sex2==1     %DZM
                    Zyg5=3;
                elseif Sex1==0 && Sex2==0 %DZM
                    Zyg5=4;
                else                      %OS
                    Zyg5=5;
                end
            else
                error('Can''t be');
            end
            
            % Change for all in the family!
            [List(find(RegExt(:,1)==RegExt(pp,1))).Zygosity] = deal(Zyg5);
            done(find(RegExt(:,1)==RegExt(pp,1))) = true;
        end
    end
    
    if sum(done) ~= size(RegExt,1)
        error('Zygosity recoding failed')
    end
    
else
    for pp=1:size(RegExt,1)
        List(pp).Fam = RegExt(pp,1);
        List(pp).Sib = RegExt(pp,2);
        List(pp).Reg = RegExt(pp,3);
        List(pp).Ext = RegExt(pp,4);
        List(pp).Wave = RegExt(pp,5);
        List(pp).Subject = RegExt(pp,6);
        List(pp).Unique = RegExt(pp,7);
        List(pp).Zygosity = RegExt(pp,8);
        List(pp).Sex = RegExt(pp,9);
        List(pp).Age = RegExt(pp,10);
    end
end


if Age<10
    for pp=1:length(List)
        if List(pp).Sib==1, code='a'; else code='b'; end
        if Age==5, occ=1; else occ=2; end
        List(pp).Filename = sprintf('%03d%c%1d', List(pp).Fam, code, occ);
    end
elseif Age == 17
    for pp=1:length(List)
        List(pp).Filename = sprintf('%03d%1d', List(pp).Fam, List(pp).Sib);
    end
elseif Age < 20
    for pp=1:length(List)
        if List(pp).Sib==1, code='a'; else code='b'; end
        if Age==16, occ=1; else occ=2; end
        List(pp).Filename = sprintf('%03d%c%1d', List(pp).Fam, code, occ);
    end
elseif Age==25 || Age==50 || Age==2550
    for pp=1:length(List)
        List(pp).Filename = sprintf('%03d%02d',List(pp).Fam,List(pp).Sib);
    end
elseif Age==112 || Age==114 ||Age==116 || Age==118
    
else
    error('Wrong age group')
end

if nargout>1
    switch Age
        case {5,7}
            temp = 'Caroline -- BackEEG';
        case {16,18}
            temp = 'Toos -- BackEEG';
        case {17}
            temp = 'OZ -- BackEEG';
        case {112,114,116,118}
            temp = 'Andrey -- BackEEG';
        otherwise
            temp = 'Danielle -- BackEEG';
    end
    Dir = sprintf('%s/%s',Root,temp);
end



