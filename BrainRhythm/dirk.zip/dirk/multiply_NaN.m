function [M] = multiply_NaN(A,B)

% Multiplies A and B matrices while ingoring NaNs

M=zeros(size(A,1),size(B,2));
for r=1:size(A,1)
    for c=1:size(B,2)
        list = A(r,:).*B(:,c)';
        M(r,c) = sum_NaN(list);
    end
end
