function [Res Head] = StandardMerge(agegroup,data,columns,header)

% function [Res] = StandardMerge(agegroup,data,columns,header)
% 
%   Merge zygosity age and sex data to 'data'
%
%   IMPORTANT! Assumes reg/ext or fam/sib in first two columns of data.
%   Will autodetect reg/ext vs fam/sib
% 
%   - 'age group' can be 5, 7, 16, 18, 25, 50, or 2550 
%               NOTE Added 112, 114, 116, 118 for the WUSTL groups!
%   - 'columns' can be:
%     o column numbers of the RegExt file to be added
%     o  the names of the columns in a cell array (e.g., {'age','sex'}) (will
%        be matched by pattern).
%     o 'all' for all columns
%     o 'simple' (default) for zyg, sex, age.
%     o 'iq' for zyg, sex, age, and IQ data (insofar available). Only
%        full-scale IQ atthe right age is added!!!!!!
%     o 'iqall' for zyg, sex, age, and IQ data (insofar available). All
%        available full-scale IQ scores are added!
% 
%     o 'fis' for zyg, sex, age. NOTE!!! reg ext and Fam Sib will be
%     replaced by 
%
%   - header holds the column namesr of 'data' as a cell array. If header is
%     included, Head will be outputed with the column names of the result
%     data matrix

if nargin<4
    header=[];
end
if nargout>1 && isempty(header)
    error('To output header information I need input header info')
end
if nargin<3
    columns = 'simple';
end

if agegroup==2550
    [RegExt1 RegExtH] = dlmread_ex('RegExt25.txt','\t',1);
    [RegExt2 RegExtH] = dlmread_ex('RegExt50.txt','\t',1);
    RegExt = [RegExt1;RegExt2];
else
    try
        [RegExt RegExtH] = dlmread_ex(sprintf('RegExt%02d.txt',agegroup),'\t',1);
    catch
        warning('Using a fixed reference to RaidTB!')
        [RegExt RegExtH] = dlmread_ex(sprintf('/Volumes/RaidTB/Alle data/RegExt%02d.txt',agegroup),'\t',1);
    end
end


%-------------------------------------------------------------------------
% DUTCH OR OZ DATA

if agegroup<100 || agegroup==2550
    
    if isempty(find(data(:,1)>999))
        % fam sib, not reg ext
        idcols = [1 2];
    else
        idcols = [3 4];
    end

    if isnumeric(columns)
        cols = columns;
    elseif iscell(columns)
        cols = FindSetNdx(RegExtH,columns,'match','pattern');
    else
        switch columns
            case 'all'
                cols = setdiff(1:length(RegExtH),[idcols]);
            case 'simple'
                cols = FindSetNdx(RegExtH,{'zyg*','sex*','age*'},'match','pattern');
            case {'iq','fis','iqall'}
                if idcols>2 % check if reg ext need to be added. 
                    cols = FindSetNdx(RegExtH,{'zyg*','sex*','age*'},'match','pattern');
                else % match is based on fam sib, so reg ext need to be added
                    cols = FindSetNdx(RegExtH,{'*reg','*ext','zyg*','sex*','age*'},'match','pattern');
                end
        end
    end

    % Add these columns
    if isempty(header) || nargout < 2
        Res = MergeById({RegExt(:,[idcols cols]),data},'mergetype','right');
    else
        [Res Head] = MergeById({RegExt(:,[idcols cols]),data},'mergetype','right','header',{RegExtH([idcols cols]),header});
    end

    % add iq data if asked for. This is based on reg ext.
    if strncmp(columns,'iq',2)
        switch agegroup
            case 5,  FN='Caro';
            case 7,  FN='Caro';
            case 16, FN='Toos';
            case 18, FN='Toos';
            case 25, FN='Danielle_New';
            case 50, FN='Danielle_New';
            case 2550, FN='Danielle_New';
            case 17, FN='OZ';
            otherwise
                error('Impossible agegroup value!')
        end
        [IQ IQH] = dlmread_ex(sprintf('IQ_%s.txt',FN),'\t',1);
        IQ(IQ(:)==-999)=NaN;

        iqidcol = FindSetNdx(IQH,{'*reg','*ext'},'match','pattern');
        if strcmp(columns,'iqall')
            iqcol = FindSetNdx(IQH,{'iq*','?iq*'},'match','pattern');
        else
            switch agegroup
                case 5, iqcol = FindSetNdx(IQH,'iq5');
                case 7, iqcol = FindSetNdx(IQH,'iq7');
                case 16, iqcol = FindSetNdx(IQH,'iq16_raven');
                case 18, iqcol = FindSetNdx(IQH,'iq18');
                case 25, iqcol = FindSetNdx(IQH,'iq_corr1');
                case 50, iqcol = FindSetNdx(IQH,'iq_corr1');
                case 2550, iqcol = FindSetNdx(IQH,'iq_corr1');
                case 17, iqcol = FindSetNdx(IQH,'iq');
            end
        end


        % force match on reg ext
        if idcols<3
            Res = Res(:,3:end);
            try
                Head = Head(3:end);
            catch
            end
        end

        % add iq data to data
        if isempty(header) || nargout < 2
            Res = MergeById({Res,IQ(:,[iqidcol iqcol])},'mergetype','left');
        else
            [Res Head] = MergeById({Res,IQ(:,[iqidcol iqcol])},'mergetype','left','header',{Head,{'reg','ext','iq'}});
        end

    % add fis registartion number
    elseif strncmp(columns,'fis',2)
        [FIS FISH] = dlmread_ex('FIS_Trapp.txt','\t',1);

        fisidcol = FindSetNdx(FISH,{'*reg','*ext'},'match','pattern');
        fiscol = FindSetNdx(FISH,{'fis'});

        % force match on reg ext
        if idcols<3
            Res = Res(:,3:end);
            try % will only work if header was requested, hence the try-catch
                Head = Head(3:end);
            catch
            end
        end

        if isempty(header) || nargout < 2
            Res = MergeById({Res,FIS(:,[fisidcol fiscol])},'mergetype','left');
        else
            [Res Head] = MergeById({Res,FIS(:,[fisidcol fiscol])},'mergetype','left','header',{Head,{'reg','ext','fis'}});
        end
    end

    
    
%-------------------------------------------------------------------------
% WUSTL DATA merges on filename, not fam/sib
    
else
    warning('Merge on lab number/filename!')
    
    idcols = 1;
    
    [List] = Globals_List(agegroup);
    
    RegExtH = {'Filename','Reg','Ext','Zyg','Sex','Age'};
    RegExt = [];
    RegExt(:,1) = [List.Filename];
    RegExt(:,2) = [List.Reg];
    RegExt(:,3) = [List.Ext];
    RegExt(:,4) = [List.Zygosity];
    RegExt(:,5) = [List.Sex];
    RegExt(:,6) = [List.Age];
    % RegExt = RegExt([RegExt.Age]>-999,:); % prune nonexisting for this age

    if isnumeric(columns)
        cols = columns;
    elseif iscell(columns)
        cols = FindSetNdx(RegExtH,columns,'match','pattern');
    else
        switch columns
            case 'all'
                error(sprintf('Not supported for this agegroup (%d)',agegroup));
            case 'simple'
                cols = FindSetNdx(RegExtH,{'reg','ext','zyg*','sex*','age*'},'match','pattern');
            case {'iq','fis','iqall'}
                error(sprintf('Not supported for this agegroup (%d)',agegroup));
        end
    end

    % Add these columns
    if isempty(header) || nargout < 2
        Res = MergeById({RegExt(:,[idcols cols]),data},'mergetype','right','idcolumns',{1,1});
    else
        [Res Head] = MergeById({RegExt(:,[idcols cols]),data},'idcolumns',{1,1},'mergetype','right','header',{RegExtH([idcols cols]),header});
        % Head = Head(2:end);
    end
    % Res = Res(:,2:end);
end

