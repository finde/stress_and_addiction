function [Out Skip] = Aggregate(Data, IdColumns, varargin)
% Aggregate: [out] = Aggregate(Data,IdColumns,varargin)
% 
% combine multiple data points by averaging into one. For each unique
% combination of values in Data(:,IdColumns) average all the available data
% in the other columns in Data.
% - Data: matrix with observations in rows and variables in columns
% - IdColumns: (1,k) vector with column numbers holding the identifiers
% - varargin:
%   - 'Missing': (int/double) missing value (default NaN)
%   - 'Random' : (int) randomly select an observations in stead of average over
%      observations. Uses the value of the parameter as seed! If no
%      initialization of the RNG is needed, pass -1. If simple means
%      aggragation is wanted, pass 0.

Missing = NaN;
RndSeed=0;
SelectCols=[];
for v=1:2:length(varargin)
    if strcmpi(lower(varargin{v}),'missing')
        Missing = varargin{v+1};
    elseif strcmpi(lower(varargin{v}),'random')
        RndSeed = varargin{v+1};
    elseif strcmpi(lower(varargin{v}),'selectcol')
        SelectCols = varargin{v+1};
    else
        error(sprintf('Unknown option: %s',varargin{v}));
    end
end

% inialize. Convert missings to nan.
Out = Data;
Skip = zeros(1,size(Data,1));
DataCols = setdiff(1:size(Data,2),IdColumns);
Data(Data(:)==Missing) = NaN;

% two types exist: take average of all available scores, or do random
% selection based on seed

if RndSeed~=0
    % seed the random number generator
    if RndSeed>0
        rng(RndSeed);
    end
    
    for row=1:size(Data,1)-1
        if Skip(row)
            continue
        end
        
        match = Data(row+1:end,IdColumns)==repmat(Data(row,IdColumns),size(Data,1)-row,1);
        ndx = find(sum(match,2)==length(IdColumns))+row;
        Skip(ndx) = 1; % these have been done
        ndx = [row ndx'];
        
        % now select from the list in ndx. If one is FULLY missing on the
        % data columns, then 
        if ~isempty(SelectCols)
            valid = ~(sum(isnan(Data(ndx,SelectCols)),2)==length(SelectCols));
        else
            valid = ones(length(ndx),1);
        end
        if sum(valid)>0
            ndx2 = find(valid);
            try
                Out(row,DataCols) = Data(ndx(ndx2(randi(sum(valid)))),DataCols);
            catch 
                error('Error in assignment. Unknown error.')
            end
        end
    end
else
    for row=1:size(Data,1)
        if Skip(row)
            continue
        end

        sums=Data(row,DataCols);
        count=zeros(1,length(DataCols));
        count(~isnan(sums))=1;
        sums(isnan(sums))=0;

        for row2=row+1:size(Data,1)
            if sum(Data(row,IdColumns)==Data(row2,IdColumns))==length(IdColumns)
                Skip(row2)=1;
                subset = ~isnan(Data(row2,DataCols));
                count(subset)=count(subset)+1; % for each data column, add only for nonmissing data
                sums(subset)=sums(subset)+Data(row2,DataCols(subset)); % same for sums: only nonmissing data
            end
        end

        subset = count>0;
        Out(row,DataCols(subset)) = sums(subset)./count(subset);
        Out(row,DataCols(~subset)) = Missing;
    end
end
Out = Out(~Skip,:);

    
            
            
            