function [data header] = dlmread_cell(filename, del, hasheader, columnformat)
% dlmread_cell: reads rectangular data from file including text, by testing
% the first line for the content. Data are written to a cell matrix.
% 
%   filename : string with file name
%   del      : delimiter
%   hasheader: (1 or 0) read first line as header. Default 0.
%   multiple : (1 or 0) take multiple delimiters as 1. Default 0.

fid = fopen(filename,'r');
if fid<1
    error(sprintf('Could not open this file (%d).',fid));
end

lc=0;
if hasheader
    temp = fgetl(fid);
    header = textscan(temp,'%s','delimiter',del);
    header=header{1};
end

data = textscan(fid,columnformat,'delimiter',del);

fclose(fid);

