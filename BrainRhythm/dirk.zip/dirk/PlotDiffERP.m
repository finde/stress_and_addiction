function [ERP, AllERP] = PlotDiffERP(EEG, types, chan, plotcomp)

% EEG=EEG struct
% types is cell array of type strings
if length(EEG.epoch) ~= size(EEG.data,3)
    error('Mismatch in EEG.data and EEG.epoch sizes');
end

if nargin<4
    plotcomp=false;
end

ev = [EEG.epoch(:).event];
hold on
colors = {'k-','r-','b-','k:'};
if plotcomp
    act = icaact(EEG.data, EEG.icaweights*EEG.icasphere);
    act = reshape(act,size(act,1),size(EEG.data,2),size(EEG.data,3));
end

if length(types)==size(EEG.data,3)
    % types is a (logical) vector to plot different conditions
    u = unique(types);
    for uc=1:length(u)
        ndx = types==u(uc);
        if plotcomp
            X = nanmean(act(chan,:,ndx),3)';
            if nargout>1
                X2 = nanmean(act(:,:,ndx),3)';
            end
        else
            X = nanmean(EEG.data(chan,:,ndx),3)';
            if nargout>1
                X2 = nanmean(EEG.data(:,:,ndx),3)';
            end
        end
        plot(linspace(EEG.xmin, EEG.xmax, size(EEG.data,2)), X,colors{uc});
        xlim([EEG.xmin,EEG.xmax])

        ERP(uc,:) = X;
        if nargout>1
            AllERP(:,:,uc) = X';
        end
    end        
else
    for t=1:length(types)
        evtype = [EEG.event(ev).type];
        ndx = evtype==types(t);
        if plotcomp
            X = nanmean(act(chan,:,ndx),3)';
            if nargout>1
                X2 = nanmean(act(:,:,ndx),3)';
            end
        else
            X = nanmean(EEG.data(chan,:,ndx),3)';
            if nargout>1
                X2 = nanmean(EEG.data(:,:,ndx),3)';
            end
        end
        plot(linspace(EEG.xmin, EEG.xmax, size(EEG.data,2)), X,colors{t});
        xlim([EEG.xmin,EEG.xmax])

        ERP(t,:) = X;
        if nargout>1
            AllERP(:,:,t) = X';
        end
    end
end

