function adjusted = padjust(pval,method)

if nargin<2
    method = 'BH';
end

if ~strcmpi(method,'BH')
    error('Only Benjamini-Hochberg available for now.');
end

if sum(isnan(pval))>0
    error('No misisng values allowed for now');
end

if size(pval,1)>1
    transposed = true;
    pval = pval';
end

idx = sortindex(pval);


adjusted(idx) = pval(idx).*length(pval)./(1:length(pval));
if adjusted(idx(end))>1
    adjusted(idx(end))=1;
end
for r=length(adjusted)-1:-1:1
    if adjusted(idx(r))>adjusted(idx(r+1))
        adjusted(idx(r))=adjusted(idx(r+1));
    end
end

if transposed
    adjusted = adjusted';
end



