function [SyncMat] = SyncLL(Data,varargin)

% function [SL] = SyncLL(Data,varargin)
% 
% Calculates synchronization likelihood between pairs of signals (in
% columns). See Montez et al, 2007
%
% varargin:
%   'pref': reference proportion: proportion of time2 data points that will be
%       considered "close" to the time1 signal state. (Default = .01)
%   'embed': embedding dimension 'n': the number of data points from time
%       points t1 and t2 that will selected to create the n-dimensional state
%       vector.
%   'lag': the time lag (in samples) between the state vector samples.
%   'W': [W1 W2]: boundaries for t2 where abs(t1-t2)>W1 and abs(t1-t2)<W2.
%   'reconstruct': [low high srate]: use filter settings to reconstruct the
%   settings embed, lag, W1 and W2. (Default = [8 13 250])
%   'speed': (integer 1:32): only analyze 1 in so many samples to speed up.
%   (default=16)

global IntegerData
global Settings
global NSamples
global NChans


error('not implemented yet')

% checks
if size(Data,1)<size(Data,2)
    Data=Data';
    warning('Changing data orientation (data in rows).')
end

% data size
NSamples = size(Data,1);
NChans = size(Data,2);

Settings = struct; %!!! IMPORTANT! This is used as a global variable!

DoReconstruct=0;
verbose=false;
% computaional (arbitrary) default settings
Settings.PRef=.01;
Settings.Speed=16;
% filter dependent settings (initially alpha band)
Filter=[8 13 250];
AutoReconstruct(Filter, NSamples); % 

% read settings
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'pref')
        Settings.PRef=varargin{v+1};
    elseif strcmpi(varargin{v},'embed')
        Settings.Embed=varargin{v+1};
    elseif strcmpi(varargin{v},'lag')
        Settings.Lag=varargin{v+1};
    elseif strcmpi(varargin{v},'w')
        Settings.W=varargin{v+1};
    elseif strcmpi(varargin{v},'reconstruct')
        Filter=varargin{v+1};
        DoReconstruct=1;
    elseif strcmpi(varargin{v},'speed')
        Settings.Speed=varargin{v+1};
    elseif strcmpi(varargin{v},'verbose')
        if isnumeric(varargin{v+1})
            verbose=logical(varargin{v+1});
        elseif ischar(varargin{v+1})
            if strcmpi(varargin{v+1},'on')
                verbose=true;
            end
        end
    end
end

if DoReconstruct,
    AutoReconstruct(Filter, NSamples); % 
end

if verbose
    fprintf('number of channels: %d\n',NChans);
    fprintf('number of data points: %d\n',NSamples);
    fprintf('pref: %.3f\n',Settings.PRef);
    fprintf('speed: %d\n',Settings.Speed);
    fprintf('embed: %d\n',Settings.Embed);
    fprintf('lag: %d\n',Settings.Lag);
    fprintf('W1, W2: [%d %d]\n',Settings.W);
end

% initialization
SyncMat=zeros(NChans,NChans,size(Data,3));

% loop thru epochs, change data type, and pass as global variable! Settings
% are passed as global too!
IntegerData=zeros(size(Data,1),size(Data,2));
for epoch=1:size(Data,3)
    for chan=1:size(Data,2)
        IntegerData(:,chan)=(Data(:,chan)-min(Data(:,chan)))/(max(Data(:,chan))-min(Data(:,chan)));
    end
    SyncMat(:,:,epoch) = Synchronization(verbose);
end



return


%% get cutoff value for a channel for a given pref

function [HitMatrix] = GetHitMatrix(T1)

% determine distance between state at I with all other states (looped in
% J). Select P closest. W holds W1 and W2.
global IntegerData
global Settings
global NSamples
global NChans

Range = NSamples - Settings.Lag * Settings.Embed;

Delay=abs((1:NSamples)-T1); % takes time points 
ndx=find(Delay>Settings.W(1)&Delay<=Settings.W(2)&(1:NSamples)<Range);

ExtractT1 = zeros(1,NChans,Settings.Embed);
ExtractT2 = zeros(length(ndx),NChans,Settings.Embed);
for lag=1:Settings.Embed
    ExtractT1(1,:,lag) = IntegerData(T1+lag*Settings.Lag,:);
    ExtractT2(:,:,lag) = IntegerData(ndx+lag*Settings.Lag,:)-repmat(ExtractT1(:,:,lag),length(ndx),1);
end
Distances = sqrt(sum(ExtractT2.^2,3));
Cutoff = percentile(Distances,Settings.PRef*100);
HitMatrix = logical(zeros(Settings.W(2)-Settings.W(1),NChans));
for chan=1:NChans
    HitMatrix(Distances(:,chan)<=Cutoff(:,chan),chan)=true;
end

return


%% main loop for synchronization

function [SyncMat] = Synchronization(verbose)
%

global Settings
global NSamples
global NChans

if nargin<1
    verbose=false;
end

SyncMat=eye(NChans);

Range = NSamples - Settings.Lag * Settings.Embed;

TotalHit=zeros(NChans,NChans);

if verbose
    tic
    fprintf('      ')
end
for T1=1:Settings.Speed:Range
    if verbose
        fprintf('\b\b\b\b\b\b%6d',T1);
    end
    HitMatrix = GetHitMatrix(T1);
    for chan1=1:NChans
        for chan2=chan1:NChans
            Cov=HitMatrix(:,chan1)&HitMatrix(:,chan2);
            TotalHit(chan1,chan2)=TotalHit(chan1,chan2)+sum(Cov);
        end
    end

    for chan1=1:NChans
        for chan2=chan1+1:NChans
            SyncMat(chan1,chan2) = (2*TotalHit(chan1,chan2))/(TotalHit(chan1,chan1)+TotalHit(chan2,chan2));
            SyncMat(chan2,chan1) = SyncMat(chan1,chan2);
        end
    end
end

if verbose
    fprintf('\n')
    toc
end

return



%% determine settings from filter setting
function AutoReconstruct(Filter, Len)
% filter holds [low_end high_end samplefrq] frequency settings

global Settings

Settings.Lag = round(Filter(3) / (4*Filter(2)));
if Settings.Lag < 1, Settings.Lag=1; end

Settings.Embed = 1 + round(Filter(3)/(Filter(1)*Settings.Lag));
if Settings.Embed < 1, Settings.Embed = 1; elseif Settings.Embed > 20, Settings.Embed = 20;end

Settings.W(1) = Settings.Lag * Settings.Embed;
Settings.W(2) = round(Settings.W(1) + 0.1 * Len);

return
