function T = LifeTime(X, V)

% create life times for binary vector X. Streaks of zeros and ones are
% counted and returned sequentially in T. If V is omitted, both streaks of
% ones and zeros are entered, otherwise specifify either 0 or 1 in V.

if nargin<2
    V=[];
end
Diff = abs(diff(X));

ndx = find(Diff==1);
T = diff([0 ndx length(X)]);
if xor(V, X(1)==0)
    T=T(1:2:end);
elseif xor(V, X(1)==0)==0
    T=T(2:2:end);
end
    
    
