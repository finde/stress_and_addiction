function h = FigureTitle(S)

% sets the figure title using annotation
h = annotation('textbox',[.2 .94 .6 .06],'string',S,...
    'hor','center','ver','middle', 'edgecolor','none');