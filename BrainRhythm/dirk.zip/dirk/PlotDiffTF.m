function PlotDiffTF(EEG,comp,channel,mask,varargin)

% plot the TF difference between two conditions. 
% - data: 3D data matrix (single row, etxracted from EEG.data or EEG.icaact)
% - mask is the logical mask separating the two conditions
% - varargin are parameters passed to 

if comp
    % extract signal, not component
    data = EEG.data(channel,:,:);
else
    % extract component
    if isempty(EEG.icaact)
        if isempty(EEG.icawinv)
            error('No ICA decomposition available')
        else
            EEG.icaact = icaact(EEG.data,EEG.icawinv*EEG.icasphere);
        end
    end
    data = EEG.icaact(channel,:,:);
end

figure;

subplot(3,1,1)
ersp1 = newtimef(data(:,:,mask), EEG.pnts, [EEG.xmin EEG.xmax], EEG.srate , [2 .5], ...
    'plotersp','on','plotitc','off',varargin{:});
subplot(3,1,2)
ersp2 = newtimef(data(:,:,~mask), EEG.pnts, [EEG.xmin EEG.xmax], EEG.srate , [2 .5], ...
    'plotersp','on','plotitc','off',varargin{:});

subplot(3,1,3)
imagesc(ersp2-ersp1);
set(gca,'ydir','normal')
colorbar

