function [cut badchans] = AutoReview(EEG, maxsecs)
% take a EEGLAB data struct (EEG) and perform an automated artifact
% rejection based on the detection of excessive high and low frequnecy
% power, offset against average values. First reject channels that have too
% many faulty epochs. Then seek a dB threshold that optimizes the data
% available. 
% - EEG: EEGLAB data struct
% - maxsecs: maximum number of seconds with artifacts
% 
% Returns: 
% - the periods where to cut
% - bad channel list

if nargin<2
    maxsecs = 60;
end

% create epoched data for rejection
N = floor(size(EEG.data,2)./EEG.srate);
Epochdata = epoch(EEG.data(:,1:N*EEG.srate),[1:N],[0 1],'srate',EEG.srate);

% calculate spectra for each 1 s epoch. Use (faster) fft.
specdata=[];
[specdata, Irej1, Erej1, freqs ] = spectrumthresh( Epochdata, specdata, 1:EEG.nbchan, EEG.srate,...
    -50, 14, 20, 45, 'fft');
[specdata, Irej2, Erej2, freqs ] = spectrumthresh( Epochdata, specdata, 1:EEG.nbchan, EEG.srate,...
    -50, 16, 1, 3, 'fft');

% determine bad channels
S = sum(Erej1,2);
x = S>maxsecs | abs(zscore(S))>3.5;
badchans = zeros(1,EEG.nbchan);
if sum(x)>0
    badchans = find(x);
    Epochdata = Epochdata(~x,:,:);
end

% loop for optimalisation of data to be selected. This will be
% done by increasing cutoff dB until enough data is available
count = 0;
tradeoff=[];
lowdB = 10;
highdB  = 29;
savecutndx = zeros(highdB-lowdB+1,size(Epochdata,3));
for dB=lowdB:highdB
    count=count+1;

    [specdata, Irej1, Erej1, freqs ] = spectrumthresh( Epochdata, specdata, 1:size(Epochdata,1), EEG.srate,...
        -50, dB, 20, 45, 'fft');
    [specdata, Irej2, Erej2, freqs ] = spectrumthresh( Epochdata, specdata, 1:size(Epochdata,1), EEG.srate,...
        -50, dB+2, 1, 3, 'fft');

    cutndx = union(Irej1,Irej2);
    cutndx = union(union(cutndx,cutndx+1),cutndx-1); % always add extra second. This works to get rid of unclear boundaries
    cutndx = setdiff(cutndx,[0 size(Epochdata,3)]);

    df = diff(cutndx);
    cutndx = union(cutndx,cutndx(find(df==2))+1);

    % calculate tradeoff by multiplying epoch length of data
    % left after rejection with dB necessary to achieve
    % rejection.
    tradeoff(count) = (EEG.xmax - length(cutndx)) / sqrt(dB);
    savecutndx(count,cutndx) = true;
end
tradeoff = conv(tradeoff,triang(3),'same');
tradeoff = detrend(tradeoff);

%plot(tradeoff);
%drawnow;

% determine tradeoff point
[~,ndxdb] = max(tradeoff);
ndxdb=ndxdb-1;
if ndxdb>size(savecutndx,1)
    ndxdb=ndxdb-1;
end
cutndx = find(savecutndx(ndxdb,:));

% determine the epochs to keep
keepndx = setdiff(1:size(Epochdata,3),cutndx);
df = diff(keepndx);

% determine cut periods
cut = [((cutndx-1)*EEG.srate+1)' (cutndx*EEG.srate)'];
for c=size(cut,1):-1:2
    if cut(c,1)==cut(c-1,2)+1
        cut(c-1,2)=cut(c,2);
        if c==size(cut,1)
            cut = cut(1:c-1,:);
        else
            cut = cut([1:c-1 c+1:end],:);
        end
    end
end
