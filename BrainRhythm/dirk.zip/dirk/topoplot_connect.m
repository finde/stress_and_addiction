function [handle,Zi,grid,Xi,Yi] = topoplot_connect(Values,loc_file,varargin)

% plots a topoplot using the EEGLAB topoplot function, but additionally
% plots lines of various strengths between each of the electrodes. Values
% holds holds an NxN matrix or a N*(N-1)/2 vector

Temp = [];
if size(Values,1)==1 || size(Values,2)==1
    count=0;
    col=0;
    row=1;
    while 1
        col=col+1;
        if col>row
            col=1;
            row=row+1;
        end
        if col==row
            Temp(row,col)=1;
        else
            count=count+1;
            if count>length(Values)
                break
            end
            Temp(row,col)=Values(count);
            Temp(col,row)=Values(count);
        end
    end
else
    Temp = Values;
    Temp(logical(eye(size(Temp,1))))=1.0;
end
N=size(Temp,1);

l=lower(varargin(1:2:end));
ndx = find(ismember(l,'electrodes'));
if ndx>0
    varargin{ndx*2} = 'on';
else
    varargin = {varargin{:},'electrodes','on'};
end
    
[handle,Zi,grid,Xi,Yi] = topoplot((sum(Temp)-1)/N,loc_file,varargin{:});
ch=get(gca,'children');
for c=1:length(ch)
    if length(get(ch(c),'xdata'))==N
        X=get(ch(c),'xdata');
        Y=get(ch(c),'ydata');
        Z=get(ch(c),'zdata');
        mx = max(Temp(~logical(eye(N))));
        mn = min(Temp(~logical(eye(N))));
        mn2 = -max(abs([mx mn]));
        mx2=-mn2;
        for row=2:N
            for col=1:row-1
                lw = (Temp(row,col)-mn2)/(mx2-mn2);
                cm = colormap;
                line([X(row) X(col)],[Y(row) Y(col)],'color',cm(floor(lw*63)+1,:),'linewidth',lw*3+.001)
            end
        end
    end
end

alpha(.5)


