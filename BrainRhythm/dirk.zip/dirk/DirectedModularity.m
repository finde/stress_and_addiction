% The following is the full code, as opposed to pseudo-code, implementing the described algorithm, written in MATLAB, version 7.0.4 (MathWorks, Natick, MA).
function [Adj,edgeBetCen]=DirectedModularity(A,W)
% function [Adj,edgeBetCen]=fEdge_directed_Dij_AppNotes(A,W) % % % Input:
% 
% Description: 
%
% A - Adjacency matrix, A (n x n), where n is the number of vertices. 
% W - Positive weight matrix, W (n x n) corresponding to the A matrix.
%
% Adj - Original adjacency matrix. 
% edgeBetCen - Edge betweenness values for all edges in the network.
%
% This algorithm performs a shortest path-based edge-betweenness centrality 
% calculation. The algorithm can be applied to any directed and positively
% weighted graph.
% 
% By Jeong-Ah Yoon, May 2006 % Chemical and Biological Engineering, Tufts University

n=size(A,1); 
Adj=A;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Step 1. % %	Dijkstra's algorithm
%	to calculate the shortest paths in a directed and weighted graph % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ddist=[]; Ssigma=[]; Ppred=[]; 
for s=1:n,
    % Initialization
    sigma=zeros(1,n); % number of shortest path from source vertex P = -1*ones(1,n); % predecessors on any shortest paths distD=(-1)*ones(1,n); % distance from source vertex
    P(s)=0; 
    sigma(s)=1;
    S=[];
    PQi=zeros(1,n); % Dijkstra?s queue
    % Step 1: PQ.insert(s,0);
    PQi(1,s)=1; distD(1,s)=0;
    while isempty(find(PQi~=0))~=1, % 'find(PQi~=0)' returns the indices of nonzero elements 
        % Step 2: PQ.del_min(); 
        [ud,ind] = min(distD(find(PQi~=0))); 
        u=find((ud==distD)& (PQi~=0));
        if size(u,2)~=1, 
            u=u(1,1);
        end
        PQi(1,u)=0; S = [S u];
        du=distD(u);
        for j=1:n, 
            if A(u,j) == 1,
                v=j; du_we=du+W(u,v);
                % obtain du from the referenced node
                if sigma(v) == 0, % check whether there are any shortest paths % sigma is the number of shortest paths
                    % Step 3: PQ.insert(v,du_we)
                    PQi(1,v)=1; 
                    distD(1,v)=du_we;
                else % relax the if condition 
                    if du_we < distD(v),
                        % Step 4: PQ.decrease_p(v,du_we)
                        distD(1,v)=du_we; 
                        sigma(v)=0;
                    else
                        if du_we > distD(v), 
                            continue; % do not increase the number of shortest paths
                        end
                    end
                end
                sigma(v)=sigma(v)+sigma(u); 
                P(v) = u;
            end % end of if statement 
        end % end of for loop
    end % end of while loop
    Ddist = [Ddist; distD]; % the length of shortest paths
    Ssigma=[Ssigma; sigma]; % numbers of shortest paths for all pairs of vertices 
    Ppred = [Ppred; P]; % predecessors of every node in the (directed and weighted) graph
end % end of Dijkstra's algorithm


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Step 2. % %	Edge betweenness centrality index calculation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization of Anew and edgeBC

Anew = zeros(n,n,n);
i=1; 
for k=1:n, % for each path
    for j=1:n, 
        if Ppred(i,j)<=0,
            Anew(i,i,k)=0;
        else
            Anew(j,Ppred(i,j),k)=1;
        end
    end
    i=i+1;
end
edgeBC = zeros(n,n,n);
for s=1:1:n, % for every source vertex (head node) % initialization of leaf node matrix
    T=[]; 
    for j=1:n, % for every vertex other than the source vertex
        % each node of Ddist(i,j) % find the maximum value element in each row vector of Ddist
        [vmax, ind] = max(Ddist(s,:));
        if vmax == 0, 
            break; % proceed with the next iteration of the for loop
        end
        % use find(edgeBC(ind,:)>0) to look for columns with index = 1
        col=find(Anew(ind,:,s)>0);
        if size(col,2) > 1, 
            col=col(1);
        end
        % if the outermost edge (leaf node) has been reached
        if length(find(Anew(:,ind,s)==0)) == n,
            T=[T ind]; % leaf nodes
            if Ssigma (s,ind)~=0 
                edgeBC(ind,col,s)=Ssigma(s,col)/Ssigma(s,ind);
            end
        else
            prv=find(edgeBC(:,ind,s)>0); % find all connecting edges 
            if Ssigma (s,ind)~=0
                edgeBC(ind,col,s)=(1+sum(edgeBC(prv,ind,s)))*Ssigma(s,col)/Ssigma(s,ind);
            end
        end
        % find the next maximum row element
        Ddist(s,ind)=0;
    end % end of for loop
end
% Sum all edgeBC matrices
edgeBetCen=sum(edgeBC,3); 
edgeBetCen=edgeBetCen';
