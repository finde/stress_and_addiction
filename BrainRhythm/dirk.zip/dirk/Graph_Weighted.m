function [E Edist] = Graph_Weighted(Graph, varargin)


% function [Eglob Eloc] = Graph_Weighted(Graph)
%   global and local efficiency from a weighted graph (Latora and
%   Marchiari, 2001)
% Note that the calculations are performed on the adjacency matrix d(ij)
% where d stands for distance, NOT connection strength. These matrices are 
% each others' inverse. Use options to inverse the matrix values.

inv=0; % default is non-"inversed" strength matrix.

for v=1:2:length(varargin)
    if strcmpi(varargin{v},'matrixtype'),
        if strcmpi(varargin{v+1},'distance'),
            inv=1;
        end
    end
end

if size(Graph,1)~=size(Graph,2)
    error('Matrix must be square.\n');
end

% initialize
N=size(Graph,1);
Edist=zeros(2,N);

% E global, calculate in "distance" space and put in "All"
All=zeros(N,N);
for A=1:N
    for B=1:N
        if A~=B
            Min = Inf;
            Done=zeros(1,N);
            Done(A)=1;
            All(A, B) = DoEachPath(Done, B, A, 0, Graph, Min, 1);
        else
            All(A,B)=Inf;
        end
    end
end

% harmonic mean = mean of 
Edist(1,:)=1./(sum(1./All)/(N-1));
E(1,1)=1./(sum(sum(1./All))/(N*(N-1)));

% E local: same as Graph_C used for binary graphs!
[x xx] = Graph_C(Graph);
Edist(2,:)=xx;
E(2,1)=x;

return


%---------------------------------------

function [NewMin] = DoEachPath(Done, B, CurPos, CurDist, Graph, Min, Steps)
% Graph in weights, not distances!

NewMin=Min;
N=size(Graph,1);

if Steps>N-1
    return
end


v=zeros(1,N);
v(1,CurPos)=1.0;

L=1./Graph; % distance matrix L (length) is inverse of strength matrix
L=L-diag(diag(L)); % zeros on diagonal: node is NOT connected to itself
nextv=v*L+CurDist;
for i=1:N
    if i==B
        if nextv(i)<NewMin,
            NewMin=nextv(i);
        end
    elseif ~Done(i) && nextv(i)<NewMin
        Done(i)=1;
        NewMin = DoEachPath(Done, B, i, nextv(i), Graph, NewMin, Steps+1);
    end
end

return




