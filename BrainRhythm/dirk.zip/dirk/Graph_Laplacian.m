function [GL] = Graph_Laplacian(Graph,normalize)

% creates the graph Laplacian from (weighted or unweighted) Graph

if nargin<2
    normalize=0;
end

if ~normalize
    GL = -Graph;
    GL(logical(eye(size(GL,1)))) = 0;
    GL(logical(eye(size(GL,1)))) = -sum(GL);
else
    % get degree
    GL = Graph;
    GL(logical(eye(size(GL,1)))) = 0;
    deg = sum(GL); % ignores the diagonal
    
    for row=1:size(Graph,1)
        for col=1:size(Graph,2)
            if row==col
                GL(row,col) = 1;
            else
                GL(row,col) = -(1./sqrt(deg(row)*deg(col)));
            end
        end
    end
end
