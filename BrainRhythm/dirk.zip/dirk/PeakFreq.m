function IAF = PeakFreq(Spectrum,Freqs,Freqrange,varargin)


% Adaptive peak frequency calculation
if nargin<3 || isempty(Freqrange)
    Freqrange = [8 12];
end
if length(Freqrange) ~= 2
    error('Freqrange parameter must have two values')
end
if size(Spectrum,1) ~= length(Freqs)
    error('Freqs must have same length as number of rows in Spectrum')
end

cMethod = 'weighted';
cSmooth = [1];
cOneOverF = 0;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'method')
        cMethod = varargin{v+1};
    end
    if strcmpi(varargin{v},'smooth')
        cSmooth = varargin{v+1};
    end
    if strcmpi(varargin{v},'oneoverf')
        cOneOverF = varargin{v+1};
    end
end

if ~isscalar(cSmooth)
    for col=1:size(Spectrum,2)
        Spectrum(:,col) = conv(Spectrum(:,col),cSmooth,'same');
    end
end

if length(cOneOverF)~=2
    error('oneoverf parameter must give lower and upper bound for detrending the spectrum')
end

% remove OneOverF character from the Spectrum
if cOneOverF
    ndx = (Freqs>=cOneOverF(1)) & (Freqs<=cOneOverF(2));
    for ch=1:size(Spectrum,2)
        Spectrum(ndx,ch) = RegressOut(1./Freqs(ndx),Spectrum(ndx,ch),nan,true);
    end
    % NOTE, this may lead to values below zero for lower frequency
    % values!!!
end


% 
Freqs = reshape(Freqs,prod(size(Freqs)),1);

% choose the method and apply
if strcmpi(cMethod,'simple')
    % simple method: Freq at maxmimum value in spectrum
    ndx = Freqs>=Freqrange(1) & Freqs<=Freqrange(2);
    [~,peak] = max(Spectrum(ndx,:));
    IAF = Freqs(peak+min(find(ndx))-1);
elseif strcmpi(cMethod,'weighted')
    ndx = Freqs>=Freqrange(1) & Freqs<=Freqrange(2);
    for col=1:size(Spectrum,2)
        IAF(col) = sum(Spectrum(ndx,col).*Freqs(ndx))/sum(Spectrum(ndx,col));
    end    
elseif strcmpi(cMethod,'adaptive')
    % CurrentIAF = mean(Freqrange);
    newrange = repmat(Freqrange',1,size(Spectrum,2));
    for count=1:10
        % weighted IAF
        for col=1:size(Spectrum,2)
            ndx = Freqs>=newrange(1,col) & Freqs<=newrange(2,col) & Freqs>=Freqrange(1) & Freqs<=Freqrange(2);
            IAF(col) = sum(Spectrum(ndx,col).*Freqs(ndx))/sum(Spectrum(ndx,col));
            newrange(:,col) = [IAF(col)-2.0 IAF(col)+2.0];
        end
    end
end
        
        