function [data header] = dlmread_cell(filename, del, hasheader, convert)
% dlmread_cell: reads rectangular data from file including text, by testing
% the first line for the content. Data are written to a cell matrix.
% 
%   filename : string with file name
%   del      : delimiter
%   hasheader: (1 or 0) read first line as header. Default 0.
%   multiple : (1 or 0) take multiple delimiters as 1. Default 0.

if nargin < 4
    convert=true;
end
if nargin < 3
    hasheader=false;
end

fid = fopen(filename,'r');
if fid<1
    error(sprintf('Could not open this file (%d).',fid));
end

lc=0;
if hasheader
    temp = fgetl(fid);
    if ~isempty(temp)
        header = textscan(temp,'%s','delimiter',del);
        header=header{1};
    else
        header={};
    end
end

while ~feof(fid)
    lc=lc+1;
    temp = fgetl(fid);
    if isempty(temp) % assume empty line at end of file
        break
    end
    
    try
        line = textscan(temp,'%s','delimiter',del);
    catch
        pause
    end
    line = line{1};
    if convert
        for col=1:length(line)
            if lc==1
                if isempty(str2num(line{col}))
                    typ(col)=1;
                else
                    typ(col)=2;
                end
            end
            if typ(col)==1 % string
                data{lc,col} = line{col};
            else % numberic
                data{lc,col} = str2num(line{col});
            end
        end
    else            
        data(lc,1:length(line)) = line'; % string only
    end
end

fclose(fid);

