function [selection] = OnePerFamily(Reg, Data)

% function [selection] = OnePerFamily(Reg,Data)
%   select one random subject per family. Reg holds only family numbers or
%   identifiers. When >1 numbers overlap, a random one is selected.
%
%   - when <Data> are specified, takes into accoutn whether the data are
%   available or not! NaNs are taken as missing

if nargin<2
    selection=ones(1,length(Reg));
else
    selection = ~isnan(Data)';
end

if length(Reg)<2
    return
end

if size(Reg,1)>1 && size(Reg,2)>1
    error('OnePerFamily only handles vectors');
end
if size(Reg,1)>size(Reg,2)
    Reg=Reg';
end

for row=1:length(Reg)
    if selection(row)
        subset = [row find(Reg(row+1:end)==Reg(row) & selection(row+1:end))+row];
        ndx = subset(1+floor(rand()*length(subset)));
        selection(subset)=0;
        selection(ndx)=1;
    end
end
selection = logical(selection);


