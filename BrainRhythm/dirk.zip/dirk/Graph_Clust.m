function [Graph OutK]=Graph_Clust(N, K, Clustsize, Reconnect, Type)

% function [Graph]=Graph_Clust(N, K, reconn)
% 
%   creates an ordered graph of the lattice type.
%   - N         : size of graph. 
%   - K         : either average degree. 
%   - Clustsize : [1,p] vector of cluster sizes.
%   - Reconnect : number of random reconnections.
%   - Type      : ('chain','leafnode'). Chain produces a big cluster with hub
%                 vertices that are highly interconnected. The remaining vertices are
%                 connected in a chain with low degree. LEAFNODE produces a similar
%                 cluster and connects the remaining vertices to that cluster. This may
%                 represent a more natural state of affairs.

if nargin<5
    Type = 'chain';
end
if nargin<4
    Reconnect = 0;
end
if nargin<3 || isempty(Clustsize)
    Clustsize = 1;
end
if nargin<2
    K = ceil(log(N));
end



% start with a lattice graph of K=2
Graph=zeros(N,N);

% CHAIN CLUSTERED GRAPH: one big cluster with the rest of the nodes linked
% in a chain
if strcmp(Type,'chain')
    for i=1:N-1
        Graph(i,i+1)=1.0;
        Graph(i+1,i)=1.0;
    end
    Graph(1,N)=1.0;
    Graph(N,1)=1.0;
    
    if length(Clustsize)==1
        % fil a full square in upper left corner
        for col=2:N
            for row=1:col-1
                Graph(row,col)=1.0;
                Graph(col,row)=1.0;
            end
            if sum(sum(Graph))>=N*K
                break
            end
        end
        OutK=[];
    else
        % create Clustsize clusters of size as defined in vector Clustsize
        start=0;
        for k=1:Clustsize
            Graph(start+1:start+Clustsize(k),start+1:start+Clustsize(k))=ones(K(k));
            prevstart = start;
            start=start+Clustsize(k);
            Graph(start,prevstart+1) = 1;
            Graph(prevstart+1,start) = 1;
        end
        Graph(logical(eye(N)))=0;
    end
    
    % then reduce to K degree by randomly removing connections
    while sum(sum(Graph)) > N*K;
        row = randi(N);
        col = randi(N);
        Graph(row,col) = 0;
        Graph(col,row) = 0;
    end
    
    OutK=mean(sum(Graph));
    
    
% LEAFNODES CLUSTERED GRAPH
elseif strcmp(type,'leafnode')
    if length(Clustsize)==1
        ClustSize = ceil(sqrt((N*(K-1)./2 + 1/8)*2)+.5);
        % fil a full square in upper left corner
        while sum(sum(Graph))<N*(K-1)-1
            col = randi(ClustSize);
            row = randi(ClustSize);
            if col~=row
                Graph(row,col)=1.0;
                Graph(col,row)=1.0;
            end
        end
    else
        % create Clustsize clusters of size as defined in vector Clustsize
        start=0;
        for k=1:Clustsize
            Graph(start+1:start+Clustsize(k),start+1:start+Clustsize(k))=ones(K(k));
            prevstart = start;
            start=start+Clustsize(k);
            Graph(start,prevstart+1) = 1;
            Graph(prevstart+1,start) = 1;
        end
        Graph(logical(eye(N)))=0;
    end
    
    
    % make leafnode connections for remaining nodes
    for col=ClustSize+1:N
        Graph(col,mod((col-1),ClustSize)+1) = 1.0;
        Graph(mod((col-1),ClustSize)+1,col) = 1.0;
    end
        
end
   


% reconnect

if Reconnect>0
    Graph=Graph_Rewire(Graph,Reconnect);
end

