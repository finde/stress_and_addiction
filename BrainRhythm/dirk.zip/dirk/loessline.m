function h = loessline(fargs)
% LOESSLINE Add loess fit line to scatter plot.
% 
%   H = LOESSLINE returns the handle to the line object(s) in H.
%       (See also LSLINE.)
%
%   Input: functionargs: pass the alpha and lambda parameters for the
%   loess function call (see LOESS)

%   Based on LSLINE: Copyright 1993-2010 The MathWorks, Inc.
% $Revision: 1.1.8.3 $  $Date: 2010/10/08 17:24:54 $

% Find any line objects that are descendents of the axes.
AxCh = get(gca,'Children');
lh = findobj(AxCh,'Type','line');
% Ignore certain continuous lines.
if ~isempty(lh)
    style = get(lh,'LineStyle');
    if ~iscell(style)
        style = cellstr(style);
    end
    ignore = strcmp('-',style) | strcmp('--',style) | strcmp('-.',style);
    lh(ignore) = [];
end

if nargin<1
    fargs = [.5, 1];
end

% Find hggroups that are immediate children of the axes, such as plots made
% using SCATTER.
hgh = findobj(AxCh,'flat','Type','hggroup');
% Ignore hggroups that don't expose both XData and YData.
if ~isempty(hgh)
    ignore = ~isprop(hgh,'XData') | ~isprop(hgh,'YData');
    hgh(ignore) = [];
end

hh = [lh;hgh];
numlines = length(hh);
if numlines == 0
    warning(message('stats:lsline:NoLinesFound'));
    hlslines = [];
else
    hold on;
    for k = 1:length(hh)
        if isprop(hh(k),'ZData')
            zdata = get(hh(k),'ZData');
            if ~isempty(zdata) && ~all(zdata(:)==0)
                warning(message('stats:lsline:ZIgnored'));
            end
        end
        % Extract data from the points we want to fit.
        xdat = get(hh(k),'XData'); xdat = xdat(:);
        ydat = get(hh(k),'YData'); ydat = ydat(:);
        ok = find(~(isnan(xdat) | isnan(ydat)));
        if isprop(hh(k),'Color')
            datacolor = get(hh(k),'Color');
        else
            datacolor = [.75 .75 .75]; % Light Gray
        end
        % Fit the points and plot the line.
        for ll=ok
            newx = linspace(min(xdat),max(xdat),100);
            newy = loess(xdat(ll,:),ydat(ll,:),newx,fargs(1),fargs(2));
            h = plot(newx,newy,'-');
            set(h,'color','w','linewidth',2.0);
            hlslines(k) = plot(newx,newy,'-');
            set(hlslines(k),'color',datacolor*.8,'linewidth',0.8);
        end
    end
    set(hlslines,'Tag','loessline');
end

if nargout == 1
    h = hlslines;
end
