function [ pred ] = predict_CV_RF(numtrees,X,Y,kfold,varargin)
% predicted values from cross-validated random forest

if nargin<4
    kfold=10;
end

ndx = floor(linspace(1,kfold+1,length(Y)+1));
ndx = ndx(1:end-1);
ndx = ndx(randperm(length(ndx)));

for k=1:kfold
    modtrain{k} = TreeBagger(numtrees,X(ndx~=k,:),Y(ndx~=k),varargin{:});
    tmp = modtrain{k}.predict(X(ndx==k,:));
    if isnumeric(tmp(1))
        pred(ndx==k) = tmp;
    else
        pred{ndx==k} = tmp;
    end
end

pred = pred-mean(pred)./std(pred).*std(Y)+mean(Y);


