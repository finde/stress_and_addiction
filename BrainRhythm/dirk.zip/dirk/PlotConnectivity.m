function PlotConnectivity(Conn,PlotEEG,Perc,Scale)

% Plots a 3D plot of the connectivity matrix with positions stroed in the
% EEGLAB EEG struct. The number of channels in the PlotEEG struct should
% match the dimensions of the (symmetric) connectivity matrix. Conn holds
% values [0,1]. Perc is the top percentage of connections that should be
% plotted.

if nargin<3
    Perc=95;
end
if nargin<4
    Scale=1;
end

%% plot the lines

Conn(logical(eye(size(Conn,1))))=0;

hold on
plot3(-[PlotEEG.chanlocs(:).Y],[PlotEEG.chanlocs(:).X],[PlotEEG.chanlocs(:).Z],'ok','markersize',4)

for ch1=1:size(Conn,1)-1
    for ch2=ch1+1:size(Conn)
        lo = percentile(Conn(:),Perc);
        hi = max(Conn(:));
        if Conn(ch1,ch2)>lo
            h = line(-[PlotEEG.chanlocs([ch1 ch2]).Y],[PlotEEG.chanlocs([ch1 ch2]).X],[PlotEEG.chanlocs([ch1 ch2]).Z]);
            lcol = 1-(Conn(ch1,ch2)-lo)/(hi-lo);
            set(h,'linewidth',((1-lcol)+.0001)*2,'color',[lcol/1.1 lcol/1.1 ifthen(lcol*2>1,1,lcol*2)])
        end
    end
end

%% plot nodes as spheres
[X Y Z] = sphere;
X=X*Scale;
Y=Y*Scale;
Z=Z*Scale;
deg = sum(Conn)./(size(Conn,1)-1);
for ch=1:size(Conn,1)
    if strcmp(lower(PlotEEG.chanlocs(ch).labels),'pz')
        scol='green';
    else
        scol='red';
    end
    try
        surf(X*deg(ch)-PlotEEG.chanlocs(ch).Y,Y*deg(ch)+PlotEEG.chanlocs(ch).X,Z*deg(ch)+PlotEEG.chanlocs(ch).Z,'FaceColor',scol,'EdgeColor','none')
    catch
    end
end
camlight left; lighting phong
view([-78 34])

xlabel('+Right -Left')
ylabel('+Front -Back')
zlabel('+Up -Down')

     
