function h = PlotPatchMatrix(M, Range)

CM = colormap;
SC = size(colormap,1);
if nargin<2 || isempty(Range)
    C = floor((M-min(M(:)))./(max(M(:))-min(M(:))).*(SC-.000001)+1);
else
    C = floor((M-Range(1))./(Range(2)-Range(1)).*(SC-.000001)+1);
end

h = nan(size(M,1),size(M,2));
for row=1:size(M,1)
    for col=1:size(M,2)
        if ~isnan(C(row,col)) && C(row,col)>0 && C(row,col)<=SC
            X = [row-.5 row-.5 row+.5 row+.5];
            Y = [col-.5 col+.5 col+.5 col-.5];
            h(row,col) = patch(X,Y,CM(C(row,col),:));
        end
    end
end

h = h(~isnan(h(:)));


