function C = Coherence(D,frq,srate,varargin)

% calculates coherence between a set of signals (columns in matrix D) and
% extracts only the coherence in freqeuncy bands frq, using sampling rate
% srate. frq holds the low and high freqeuncy band edges.

verbose=0;
if nargin>4
    if strcmp(varargin{1},'verbose')
        verbose=varargin{2};
    end
end

C=zeros(size(D,2));

count=0;
if verbose
    fprintf('    ');
end
for ch1=1:size(D,2)-1
    for ch2=ch1+1:size(D,2)
        count=count+1;
        [coh fs] = mscohere(D(:,ch1),D(:,ch2),1024,512,1024,srate);
        ndx = fs>frq(1) & fs<=frq(2);
        C(ch1,ch2) = mean(coh(ndx));
        if C(ch1,ch2)>1
            pause
        end
        if verbose
            fprintf('\b\b\b\b%4d',count);
        end
    end
end
if verbose
    fprintf('\n');
end

C=C+C'+eye(size(D,2));
