function h = textrel(X,Y,varargin)

% text relative to axes ranges (0 to 1)
x = X*range(xlim)+min(xlim);
y = Y*range(ylim)+min(ylim);
h = text(x,y,varargin{:});

