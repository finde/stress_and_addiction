function [cm] = MakeColormap(varargin)
% example: MakeColormap('grey','yellow') makes a colormap from grey to
% yellow.
%    {'grey','gray'}
%    'yellow'
%    'red'
%    'green'
%    'blue'

if length(varargin)<2
    error('MakeColormap: Need at least two color specifications.');
end

colors = zeros(length(varargin),3);
for v=1:length(varargin)
    if isstr(varargin{v})
        switch varargin{v}
            case {'grey','gray'}
                colors(v,1:3) = [.5 .5 .5];
            case 'yellow'
                colors(v,1:3) = [1 1 0];
            case 'red'
                colors(v,1:3) = [1 0 0];
            case 'green'
                colors(v,1:3) = [0 1 0];
            case 'blue'
                colors(v,1:3) = [0 0 1];
            case 'white'
                colors(v,1:3) = [1 1 1];
            case 'black'
                colors(v,1:3) = [0 0 0];
            case {'darkgrey','darkgray'}
                colors(v,1:3) = [.25 .25 .25];
            case {'lightgrey','lightgray'}
                colors(v,1:3) = [.75 .75 .75];
        end
    elseif isnumeric(varargin{v})
        if sum(size(varargin{v})==[1 3])~=2
            error('MakeColormap: Specify colors as (1,3) matrix.')
        end
        colors(v,1:3)=varargin{v};
    else
        error('MakeColormap: Specify colors as (1,3) matrix or using string labels.')
    end
end

% init
cm=zeros(size(colormap));
rows = linspace(1,size(cm,1),length(varargin));

for r=1:length(rows)-1
    ndx = ceil(rows(r)):floor(rows(r+1));
    cm(ndx,1)=linspace(colors(r,1),colors(r+1,1),length(ndx));
    cm(ndx,2)=linspace(colors(r,2),colors(r+1,2),length(ndx));
    cm(ndx,3)=linspace(colors(r,3),colors(r+1,3),length(ndx));
end
