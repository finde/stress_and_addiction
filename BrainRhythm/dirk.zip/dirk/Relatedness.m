function Rel = Relatedness(Data, method)

% method is 'distance' for cartesian distance or 'corr' for correlation

if nargin<2
    method='corr';
end

if strcmp(method,'corr')
    m=1;
else
    m=2;
end

N=size(Data,1);

if m==1
    Rel = corr(Data(~isnan(mean_NaN(Data(:,:),2)),:)','rows','pairwise');
else
    % get difference of zscore
    Rel=zeros(N);
    for r=1:N
        for c=1:N
            if r==c
                Rel(r,c) = 0;
            else
                Rel(r,c) = Data(r,1) - Data(c,1);
            end
        end
    end
end
            
            
            