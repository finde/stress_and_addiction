function y = var_NaN(x,dim,missing)
%   var_NaN: calculates standard deviation along dimension dim, excluding
%   NaN values (or missings, if specified)

if isinteger(x) 
    error('First argument must be single or double.');
end

if nargin < 2
    if isequal(x,[]), y = NaN(class(x)); 
        return
    end
    dim = find(size(x) ~= 1, 1);
    if isempty(dim),
        dim = 1; 
    end
end

if nargin<3
    missing=NaN;
end

switch dim
    case 1,
        sm=zeros(1,size(x,2),size(x,3));
        smsq=zeros(1,size(x,2),size(x,3));
        cnt=zeros(1,size(x,2),size(x,3));
    case 2,
        sm=zeros(size(x,1),1,size(x,3));
        smsq=zeros(size(x,1),1,size(x,3));
        cnt=zeros(size(x,1),1,size(x,3));
    case 3,
        sm=zeros(size(x,1),size(x,2),1);
        smsq=zeros(size(x,1),size(x,2),1);
        cnt=zeros(size(x,1),size(x,2),1);
end

try
    for d1=1:size(x,1)
        for d2=1:size(x,2)
            for d3=1:size(x,3)
                v=x(d1,d2,d3);
                if isnan(missing)
                    hit = isnan(v);
                else
                    hit=(v==missing);
                end
                if ~hit,
                    switch dim
                        case 1,
                            sm(1,d2,d3)=sm(1,d2,d3)+v;
                            smsq(1,d2,d3)=smsq(1,d2,d3)+v*v;
                            cnt(1,d2,d3)=cnt(1,d2,d3)+1;
                        case 2,
                            sm(d1,1,d3)=sm(d1,1,d3)+v;
                            smsq(d1,1,d3)=smsq(d1,1,d3)+v*v;
                            cnt(d1,1,d3)=cnt(d1,1,d3)+1;
                        case 3,
                            sm(d1,d2,1)=sm(d1,d2,1)+v;
                            smsq(d1,d2,1)=smsq(d1,d2,1)+v*v;
                            cnt(d1,d2,1)=cnt(d1,d2,1)+1;
                    end
                end
            end
        end
    end
catch
    disp('error');
end

y=(smsq-((sm.^2)./cnt))./(cnt-1);
