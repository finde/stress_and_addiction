function p = plotPatch(x, y, r, col, alpha, shape)

% plotPtach plots objects within the current graphics object with patch.
% This allows setting the alpha and make the objects transparent.
% - x,y: middle point(s) of the objects
% - r: radius or half-width of the objects
% - col (1,3) vector of color
% - alpha (0-1) is the alpha factor transparency
% - shape ('o','s') for circles or square objects

    if nargin<6
        shape='o';
    end

    % aspect is width / height
    fPos = get(gcf, 'Position');
    
    % need width, height in data values
    xl = xlim();
    yl = ylim();
    w = r*(xl(2)-xl(1))/fPos(3)/1.5;
    h = r*(yl(2)-yl(1))/fPos(4);

    switch(shape)
            
        case 'o'
            theta = 0:pi/5:2*pi;
            mx = sin(theta)*w;
            my = cos(theta)*h;
            num = 0;
            for k = 1:max(size(x))
                for f = 1:size(y,2)
                    if ~isnan(x(k)) && ~isnan(y(k,f))
                        num = num+1;
                        p(num) = patch(x(k)+mx, y(k,f)+my, col, 'FaceColor', col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
                    end
                end
            end

        case 's'
            mx = [-w w w -w];
            my = [-h -h h h];
            num = 0;
            for k = 1:max(size(x))
                for f = 1:size(y,2)
                    if ~isnan(x(k)) && ~isnan(y(k,f))
                        num = num+1;
                        p(num) = patch(x(k)+mx, y(k,f)+my, col, 'FaceColor', col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
                    end
                end
            end
            
        case 'd'
            mx = [0 -w 0 w];
            my = [h 0 -h 0];
            num = 0;
            for k = 1:max(size(x))
                for f = 1:size(y,2)
                    if ~isnan(x(k)) && ~isnan(y(k,f))
                        num = num+1;
                        p(num) = patch(x(k)+mx, y(k,f)+my, col, 'FaceColor', col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
                    end
                end
            end
    end
            
end