function [out] = filter_fft(data, fs, hplp, varargin)
% function [out] = filter_fft(data, fs, hplp, varargin)
%
% filter using (sharper) fft filter
%   Data: rows of data
%   fs: sample frequency (Hz)
%   [hp, lp]: numbers for the high-pass and low-pass cutoff freqs (hp<lp!).
%             Use 0 for no filter at that end. hp and lp are inclusive! If
%             hp==lp then the closest frequency bin is selected!
%
%   varargin:
%     'baseline': ('on' | 'off'): baseline correction (def='off')
%     'windowtype': ('none'|'hanning'|xxx'hamming') window to be applied to
%                   beginning and end of data to reduce edge effects
%                   (def=none)
%     'windowsize': number of samples of data at beginning and end to be
%                   windowed (def = 10)
%     xxx'windowsec': as above but in number of seconds
%     'filtertype': ('bandpass'|'bandstop') use passband or stopband
%                   filter. def='bandpass'

if size(hplp,2)~=2
    error('Size of hplp must be (1,2)')
end

filtertype='pass';
baseline=0;
windowtype = 'none';
windowsize = 10;
for v=1:2:length(varargin)
    switch varargin{v}
        case 'baseline'
            baseline=varargin{v+1};
        case 'filtertype'
            filtertype=varargin{v+1};
        case 'windowtype'
            windowtype = varargin{v+1};
        case 'windowsize'
            windowsize = varargin{v+1};
    end
end

if ~iscell(data) && size(data,3)>1
    temp = data;
    data = cell(1,size(temp,3));
    for n = 1:size(temp,3)
        data{n} = temp(:,:,n);
    end
elseif ~iscell(data)
    data = {data};
end

win=[];

out = cell(size(data));
for n = 1:numel(data)
    temp=data{n};
    if size(temp,2)==1,
        temp=temp';
    end
    nyqvist=fs./2;
    N=size(temp,2);
    f=linspace(0,nyqvist,N./2+1);
    if mod(length(temp),2)==0
        f=[f f(end-1:-1:2)];
    else
        f=[f f(end:-1:2)];
    end

    if hplp(2)==0
        include=find(f>=hplp(1));
    elseif hplp(1)==0
        include=find(f<=hplp(2));
    elseif hplp(1)==hplp(2) 
        [x include]=min(abs(f-hplp(1)));
    else
        include = find(f>=hplp(1)&f<=hplp(2));
    end
    inc=zeros(1,length(temp));
    inc(include)=1;

    if strcmpi(filtertype,'bandstop')|| strcmpi(filtertype,'stop')|| strcmpi(filtertype,'stopband')
        inc=1-inc;
    end

    % remove baseline
    if baseline
        temp=temp-repmat(mean(temp,2),1,size(temp,2));
    end
    
    % apply window to beginning and end of data
    switch windowtype
        case 'hanning'
            hanwin = hanning(2.*windowsize)'; 
            win = [hanwin(1:end/2) ones(1,size(temp,2)-length(hanwin)) hanwin(end/2+1:end)];
            win = repmat(win,size(temp,1),1);
            temp = temp.*win;
    end

    % walk thru data
    out{n}=zeros(size(temp));
    for row=1:size(temp,1)
        d=temp(row,:);
        F=fft(d);
        F=F.*inc;
        out{n}(row,:)=ifft(F);
    end
end

if numel(out) == 1; out = out{1}; end
