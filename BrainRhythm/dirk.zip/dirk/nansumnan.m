function res = nansumnan(X,dim)

% does a nansum along dimension dim, but returns nan if all data are
% missing (in stead of 0)

if nargin<2
    dim=1;
end
res = nansum(X,dim);
res(sum(isnan(X),dim)==size(X,dim))=nan;

