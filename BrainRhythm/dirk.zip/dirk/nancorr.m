function [coef, pval] = nancorr(X,Y)

if nargin<2
    [coef, pval] = corr(X,'rows','pairwise');
else
    [coef, pval] = corr(X,Y,'rows','pairwise');
end

    
    