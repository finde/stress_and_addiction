function G=Graph_Line(N)

G = eye(N)./2;
for row=1:N-1
    G(row,row+1) = 1;
end
G=G+G';