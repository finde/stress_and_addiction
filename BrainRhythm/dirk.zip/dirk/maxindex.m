function idx = maxindex(x)

[~,idx] = max(x);
