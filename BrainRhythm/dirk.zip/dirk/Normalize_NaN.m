function [out] = Normalize(input, byrowcol)

% normalizes the data to zero mean and unit variance
% [out] = Normalize(input, byrowcol)
%   input     : the data
%   byrowcol  : 'row' 'col' = how data are organized (default is col)

if nargin<2,
    byrowcol='col';
end

if strcmpi(byrowcol,'row')
    input=input';
end

if size(input,1)==1
    input=input';
end

out = (input-repmat(mean_NaN(input,1),size(input,1),1))./repmat(var_NaN(input,1).^.5,size(input,1),1);

if strcmpi(byrowcol,'row')
    out=out';
end



