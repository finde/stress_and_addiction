function [R] = familysampledcorr(widedata, missing, type)

% widedata is a 3D matrix with 2 levels in the 3rd dimension. (:,:,1) and
% (:,:,2) are each a matrix with observations of all subjects organized
% in wide format, i.e., each row a family, and family members in columns.
% Returns the correlation between the vectorized widedata1 and widedata2.

if nargin<3
    type=1;
else
    if strcmpi(type,'pearson') || strcmpi(type,'pmcc')
        type=1;
    elseif strcmpi(type,'spearman') || strcmpi(type,'rcc')
        type=2;
    elseif strcmpi(type,'kendall') || strcmpi(type,'tau')
        type=3;
    end
    % if type is a number then already set to 1, 2, 3 (hopefully);
end

if nargin<2,
    missing=NaN;
end

if ~isnan(missing)
    widedata(find(widedata(:)==missing))=NaN;
end

if size(widedata,3)==1
    if mod(size(widedata,2),2)~=0
        error('wrong data size');
    end
    % assume only two dimensions, x and y glued to each other
    datax=widedata(:,1:end/2);
    datay=widedata(:,end/2+1:end);
else
    % x and y along third dimension
    datax=widedata(:,:,1);
    datay=widedata(:,:,2);
end

   
% valid in 1D, corr will be computed 1D also
valid=~isnan(datax)&~isnan(datay);

switch type
    case 1, R=corr(datax(valid),datay(valid));
    case 2, R=corr(datax(valid),datay(valid),'type','spearman');
    case 3, R=corr(datax(valid),datay(valid),'type','kendall');
end



