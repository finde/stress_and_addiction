function [Rmz Rdz Rph Scores] = QD_TwinCorr(data,famcol,sibcol,zygcol,datcol,varargin)

% function [Rmz Rdz] = QD_TwinCorr(data,famcol,sibcol,zygcol,datcol,...)
%
%   Calculates twin correlations from a long data format in a Quick-and-dirty
%   fashion. Can also be used for multiple data columns to obtain MZ and DZ
%   CTCT correlations.
%   output:
%   - Rmz, Rdz: Twin correlation matrices
%   - Rph     : Phenotypic correlation matrix
%   - Scores  : 1,2 cell array of data matrices used to calculate Rmz and Rdz 
%
%   varargin:
%   - mzval: value of mz vs non-mz (dz or os). default [1 2]
%   - missing: missing value (default -999. NaN are always treated as
%     missing!)
%   - plot: (0/1) plots MZ and DZ scatterplots of the first variable.
%   - symm: (0/1) make output matices symmetric (for multivariate
%     analyses). Uses fisher transform in averaging.

missing = -999; % missing *or* NaN are valid missing values
mzval = [1,2];
doplot=0;
cDoForceSymm = 0;

for v=1:2:length(varargin)
    switch lower(varargin{v})
        case 'missing'
            missing = varargin{v+1};
        case 'mzval'
            mzval = varargin{v+1};
        case 'plot'
            doplot = varargin{v+1};
        case {'sym','symm','symmetric'}
            cDoForceSymm = varargin{v+1};
        otherwise
            error('Unknown option')
    end
end
if ischar(doplot)
    if strcmp(doplot,'on')
        doplot=1;
    end
end

pos = get(0,'screensize');
dx=300;
dy=500;
if doplot
    figure('pos',[pos(3)/2-dx/2 pos(4)/2-dy/2 dx dy])
end

%--------------------------------------------
ndx = data(:,sibcol)<3&(data(:,zygcol)==mzval(1)|data(:,zygcol)==mzval(end));
Restr = Restructure(data(ndx,[famcol sibcol datcol]),'missing',missing);
if ~isnan(missing)
    Restr(find(Restr(:)==missing))=NaN;
    Restr(find(abs(Restr(:))==Inf))=NaN;
end
Rmz = corr(Restr(:,[2:end]),'rows','pairwise');
Scores{1} = Restr;

%---------------------------------------------
if doplot
    subplot(2,1,1);
    plot(Restr(:,2),Restr(:,length(datcol)+2),'ok');
    lsline;
    title(sprintf('R=%.2f',Rmz(length(datcol)+1,1)));
end

%----------------------------------------------
Temp = data(:,[famcol sibcol zygcol datcol]); % from now on fixed column numbers! 1, 2, 3, 4:end
Fam = unique(Temp(:,1));
list=[];
addlist = [];
for f=Fam'
    ndx = find(Temp(:,1)==f);
    if length(ndx)>1
        p = nchoosek(ndx,2);
        for a=1:size(p,1)
            if sum(Temp(p(a,1:2),2))>3 || (Temp(p(a,1),3)~=mzval(1) && Temp(p(a,1),3)~=mzval(end))
                addlist = [Temp(p(a,1),1) Temp(p(a,1),4:end) Temp(p(a,2),4:end)];
            end
        end
    end
    list = [list;addlist];
end

list(find(list(:)==missing))=NaN;
list(find(abs(list(:))==Inf))=NaN;
Rdz = corr(list(:,2:end),'rows','pairwise');
Scores{2} = list;

%--------------------------------------------
if doplot % (only first variable)
    subplot(2,1,2);
    plot(list(:,2),list(:,length(datcol)+2),'ok');
    lsline;
    title(sprintf('R=%.2f',Rdz(length(datcol)+1,1)));
end

%--------------------------------------------
if nargout>2
    % calculate the phenotypic correlation matrix
    Nmz=size(Scores{1},1);
    Ndz=size(Scores{2},1);
    Nvar=(size(Scores{1},2)-1)/2;
    Mask = ~logical(eye(Nvar));
    Rph = fisherinv((fisher(Mask.*Rmz(1:end/2,1:end/2))*Nmz + fisher(Mask.*Rdz(1:end/2,1:end/2))*Ndz)./(Nmz+Ndz));
    Rph(~Mask) = 1;
end


Rmz = Rmz(end/2+1:end,1:end/2);
Rdz = Rdz(end/2+1:end,1:end/2);

if cDoForceSymm
    Rmz = fisherinv((fisher(Rmz)+fisher(Rmz'))./2);
    Rdz = fisherinv((fisher(Rdz)+fisher(Rdz'))./2);
end


