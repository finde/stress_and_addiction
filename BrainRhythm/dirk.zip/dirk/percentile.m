function [result] = percentile(data, P)
% percentile(data, P): returns the Pth percentile of data. Data in columns.

% re-orient vector into column
if size(data,1)==1
    data=data';
end

% columnwise sort
y = sort(data);
perc = 100*((1:size(y,1)-.5)./size(y,1));

N = size(y,1);
for p=1:length(P)
    if P(p)<=perc(1)
        result(p,:)=y(1,:);
    elseif P(p)>=perc(end)
        result(p,:)=y(end,:);
    else
        dist = abs(perc-P(p));
        [val ndx]=min(dist);
        % loop thru data columns
        for col=1:size(y,2)
            if val==0
                result(p,col)=y(ndx,col);
            else
                [vals ndxs]=minima(dist,2);
                result(p,col)=(y(ndxs(2),col)*vals(1)+y(ndxs(1),col)*vals(2))/sum(vals);
            end
        end
    end
end

return

%%
function [vals ndxs] = minima(data,number)
% gets <number> smallest numbers from data

vals=zeros(1,number);
ndxs=zeros(1,number);
mask=ones(1,numel(data));
ndxlist=1:numel(data);
for i=1:number
    [vals(i) ndx] = min(data(logical(mask)));
    temp=ndxlist(logical(mask));
    ndxs(i)=temp(ndx);
    mask(ndxs(i))=0;
end

return
