function [connect pcrit]= Threshold(Graph, varargin)

% takes a weghted connectivity matrix and produces a binary graph
% ignores the diagonal (all will be set to unity)
% 'K': set average number of connections per node. Default=log(N) rounded
% up
% 'p': use fixed cutoff value 'p'

N=size(Graph,1);
K=ceil(log(N));
p=0;
type=0; % K type thresholding

if size(Graph,1)~=size(Graph,2)
    error('Graph must be square');
end

for i=1:length(varargin)
    if strcmpi(varargin{i},'K')
        K = varargin{i+1};
    elseif strcmpi(varargin{i},'p')
        p = varargin{i+1};
        pcrit = p;
        type = 1;
    end
end

% get all connection strengths and sort
all=sdiag(Graph);


if type==1
    connect = zeros(1, length(all));
    connect(find(all>=p)) = 1;
    connect = sdiag(connect, 'rowcol', [N N], 'complete', 1);
else
    nconn = round(N*K/2);
    [sortall ndx]= sort(all);
    connect = zeros(1,length(all));
    connect(ndx((end-nconn+1):end))=1;
    pcrit = sortall(end-nconn+1);
    connect = sdiag(connect, 'rowcol', [N N], 'complete', 1);
end

    
    
    


