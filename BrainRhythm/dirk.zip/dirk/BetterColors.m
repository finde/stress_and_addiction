function BetterColors

ch = get(gca,'ch');
ch = ch(ismember(get(ch,'type'),'line'));

% get colormap and extract the colors
CM = get(gcf,'colormap');
colors = CM(round(linspace(1,size(CM,1),length(ch))),:);

% interleave colors and apply
if mod(length(ch),2)==0
    colors = reshape([colors(1:end/2,:) colors(end/2+1:end,:)]',3,size(colors,1))';
else
    colors = [reshape([colors(1:floor(end/2),:) colors(floor(end/2)+1:end-1,:)]',3,size(colors,1)-1)'; colors(end,:)];
end


for c=1:length(ch)
    set(ch(c),'color',colors(c,:));
end


