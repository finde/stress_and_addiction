function [cut, badchans] = ManualReview_dB(EEG, dB_lo, dB_hi, maxsecs, z_cutoff)
% take a EEGLAB data struct (EEG) and perform an "manual" artifact
% rejection based on the detection of excessive high and low frequnecy
% power, offset against average values. First reject channels that have too
% many faulty epochs. Then seek a dB threshold that optimizes the data
% available. 
% - EEG: EEGLAB data struct
% - maxsecs: maximum number of seconds with artifacts
% - dB_lo: dB cutoff for the lower frequencies
% - dB_hi: dB cutoff for the higher frequencies
% 
% Returns: 
% - the periods where to cut
% - bad channel list

if nargin<5
    z_cutoff = icdf('norm',1-(.05/2/EEG.nbchan),0,1);
end
if nargin<4
    maxsecs = 60;
end

if ndims(EEG.data)<3
    % create epoched data for rejection
    N = floor(size(EEG.data,2)./EEG.srate);
    Epochdata = epoch(EEG.data(:,1:N*EEG.srate),[1:N],[0 1],'srate',EEG.srate);
else
    Epochdata = EEG.data;
end
Epochlen = size(Epochdata,2);

% calculate spectra for each 1 s epoch. Use (faster) fft.
specdata=[];
[specdata, ~, Erej1] = spectrumthresh_ex(Epochdata, specdata, 1:EEG.nbchan, EEG.srate,...
    -80, dB_hi, 24, 45, 'fft');
[specdata, ~, Erej2] = spectrumthresh_ex(Epochdata, specdata, 1:EEG.nbchan, EEG.srate,...
    -80, dB_lo, 1, 3, 'fft');

% determine bad channels using maxsecs and maximum z-score based on number
% of channels.
S = sum((Erej1 | Erej2),2);
badmask = S>maxsecs | abs(zscore(S))>z_cutoff;
badchans = zeros(1,EEG.nbchan);
if sum(badmask)>0
    badchans = find(badmask);
    Epochdata = Epochdata(~badmask,:,:);
end

if isempty(Epochdata)
    cut = [];
    return
end

% determine bad stretches based on spectral analysis of the epochs
[specdata, Irej2, Erej2, freqs ] = spectrumthresh_ex(Epochdata, [], 1:size(Epochdata,1), EEG.srate,...
    -80, dB_lo, 1, 3, 'fft');
[specdata, Irej1, Erej1, freqs ] = spectrumthresh_ex(Epochdata, specdata, 1:size(Epochdata,1), EEG.srate,...
    -80, dB_hi, 24, 45, 'fft');

% determine the set of epochs that are to be removed. Do postprocessing for
% continuous data
cutndx = union(Irej1,Irej2);
if ndims(EEG.data)<2 % postprocessing for continuous data
    cutndx = union(union(cutndx,cutndx+1),cutndx-1); % always add extra second to the data to be deleted. This works to get rid of unclear boundaries
    cutndx = setdiff(cutndx,[0 size(Epochdata,3)]);
    df = diff(cutndx);
    cutndx = union(cutndx,cutndx(find(df==2))+1);
end

% determine the epochs to keep in steadof deleted
%keepndx = setdiff(1:size(Epochdata,3),cutndx);
%df = diff(keepndx);

% determine cut periods
cut = [((cutndx-1)*Epochlen+1)' (cutndx*Epochlen)'];
for c=size(cut,1):-1:2
    if cut(c,1)==cut(c-1,2)+1
        cut(c-1,2)=cut(c,2);
        if c==size(cut,1)
            cut = cut(1:c-1,:);
        else
            cut = cut([1:c-1 c+1:end],:);
        end
    end
end
    