function C = AEC(Data)

if size(Data,1)<size(Data,2)
    warning('Are the data oriented correctly (columns)?');
end

C = corr(abs(hilbert(Data)));

