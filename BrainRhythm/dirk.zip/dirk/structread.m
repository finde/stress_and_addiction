function S = structread(Filename, fmt, missingstr, header)

% Reads a file into a struct. Requires that the file is a rectangular file
% (i.e. the same number of words per line). fmt determins the data format
% to be read and should be in TEXTSCAN format (%d, %f, etc.).

if nargin < 4
    cReadHeader = true;
else
    cReadHeader = false;
end

if nargin < 3
    missingstr = 'nan';
end

fid = fopen(Filename,'r');
if fid<1
    error('Cannot open file %s',Filename)
end

if cReadHeader
    tmp = textscan(fgetl(fid),'%s');
    header = tmp{1};
end

body = textscan(fid, fmt, 'multipledelimsasone', 1, 'collectoutput', 0, 'treatasempty', missingstr); % will read as long as possible
if length(body) ~= length(header)
    error('header and data must have same number of columns')
end




    


