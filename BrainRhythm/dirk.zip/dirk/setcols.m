function [color] = setcols(N,K)

if nargin<2
    K=32;
end
    
CM = colormap;
color = CM(1+floor((size(CM,1)-1)/K*N),:);


