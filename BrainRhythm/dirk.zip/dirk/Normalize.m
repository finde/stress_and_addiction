function [out] = Normalize(input, varargin)

% normalizes the data to zero mean and unit variance
% [out] = Normalize(input, byrowcol)
%   input     : the data
%
%   varargin:


Missing = NaN;
for v=1:2:length(varargin)
    switch lower(varargin{v})
        case 'missing'
            Missing = varargin{v+1};
    end
end

if ~isnan(Missing)
    input(input(:)==Missing)=NaN;
end
        
if size(input,1)==1
    input=input';
end

% initialize
out = input;
out(:)=Missing;

% for each column:
for third=1:size(input,3)
    for col=1:size(input,2)
        ndx = ~isnan(input(:,col));
        out(ndx,col,third) = (input(ndx,col,third)-mean(input(ndx,col,third)))./std(input(ndx,col,third),[],1);
    end
end



