function [Index] = IndexByName(AnEEG, Name)
% looks into an EEGLAB EEG data structure, looks up the index of a channel
% with name 'Name', returns 0 if not found. If name is a cell array of
% strings a vector of indices is returned.
if iscell(Name)
    Index=zeros(1,length(Name));
    for j=1:length(Name)
        for i=1:length(AnEEG.chanlocs)
            if strcmpi(Name{j}, AnEEG.chanlocs(i).labels)
                Index(j) = i;
                break
            end
        end
    end
elseif ischar(Name)
    Index=0;
    for i=1:length(AnEEG.chanlocs)
        if strncmpi(Name, AnEEG.chanlocs(i).labels, length(Name)) == 1
            Index = i;
            return 
        end
    end
else
    error('Name must be a string or a list of strings (of cell {} type).');
    Index=[];
end

