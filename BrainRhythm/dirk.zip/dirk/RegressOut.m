function Yout = RegressOut(X,Y,missing,reenter)
% Yout = RegressOut(X,Y, missing,reenter)
% regresses out the effects of all columns X on each column in Y. Puts back the
% mean predicted value of Y, so that Y stays scaled (set reenter=0 to
% avoid this).

if nargin<4
    reenter=0;
end
if reenter~=0 && reenter~=1
    error('RegressOut: reenter and hetergen take values 0 or 1')
end
if nargin<3,
    missing=NaN;
end

% initialize
Yout = Y;

% convert all missing to NaN
Y(Y(:)==missing)=NaN;

for col=1:size(Y,2)
    stats = regstats(Y(:,col),X,'linear','r');
    % re-enter overall mean of data
    Yout(:,col) = stats.r;
    if reenter
        Yout(:,col) = Yout(:,col) + nanmean(Y(:,col));
    end
end
