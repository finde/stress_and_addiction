function [EEGOut] = InsertDummyEvents(EEG, EpochLen, Rate, Event);
% function [EEGOut] = InsertDummyEvents(EEG, EpochLen, Rate, EventType);
% Inserts events at every EpochLen seconds. Uses Rate (default 250 Hz) to
% calculate the correct sample to insert events at.
% EventType is the event type field value for all events inserted

EEGOut = EEG;

if nargin<4
    Event = 'dummy';
end
if nargin < 3
    Rate = 250;
end
if nargin < 2
    EpochLen = 16;
end
if nargin < 3
    Rate = 250;
end

[nchans len] = size(EEG.data);

epochs = floor(len / (EpochLen*Rate));

%disp(sprintf('reshaping (%d by %d) to (%d by %d by %d)', nchans, epochs*EpochLen, nchans, EpochLen, epochs));
EEGOut.data = EEGOut.data(1:nchans, 1:epochs*EpochLen*Rate);
EEGOut.pnts = epochs*EpochLen*Rate;

ne=length(EEG.event);
nu=length(EEG.urevent);
disp(sprintf('Appending %d events.', epochs));
for e=1:epochs
    EEGOut.urevent(nu+e).type=Event;
    EEGOut.urevent(nu+e).latency=1+(e-1)*(EpochLen*Rate);
    EEGOut.event(ne+e).type=EEGOut.urevent(nu+e).type;
    EEGOut.event(ne+e).latency=EEGOut.urevent(nu+e).latency;
    EEGOut.event(ne+e).duration=1;
    EEGOut.event(ne+e).urevent = nu+e;
end
    