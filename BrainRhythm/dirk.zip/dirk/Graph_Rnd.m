function Random=Graph_Rnd(Connect, varargin)

% Randomizes a (n x n)  graph 'Connect', or uses Connect [n k] to create a
% Connect: - (n x n) stymmetric matrix with connectivity values that will be
% randomized 
%           - [n k] where n is the number of nodes and k the average
%           - (1 x n) vector holding the degree distribution
%
% varargin:
%   'type':  {none,fixed,p-type,weighted}. randomization with various fixations of
%   the degree distribution. 
%     - 'None' results in full randomisation and only the avergae degree
%     fixed. (default)
%     - 'fixed' keeps the degree distribution exactly as it was. For small 
%     networks this may result in no ranodmization at all.
%     - 'p-type' is similar fixed, but only on average the degree
%     distribution will be equal.
%     - 'weighted': assumes a weighted graph as input and reshuffles the
%     existing values.

%%

% shortcut procedure for random networks with N nodes and K degree
if size(Connect,1)==1 && size(Connect,2)==2
    N=Connect(1);
    K=Connect(2);
    NConn=N*K;
    Random = zeros(N,N);
    while NConn>0
        R=1;
        C=1;
        while R==C || Random(R,C)==1
            C=floor(1+rand()*N);
            R=floor(1+rand()*N);
        end
        Random(R,C)=1;
        Random(C,R)=1;
        NConn=NConn-2;
    end
    
    return
end


%% ---------------------------------------------
if size(Connect,1)>2 && size(Connect,2)==1
   Connect=Connect';
end
if (size(Connect,1)==1 && size(Connect,2)>2)
    % assume Connect holds a degree distribution
    N=size(Connect,2);
    DD=Connect; % degree distribution
    DD2=(DD'*DD).*(1-eye(N));
    DD2=DD2./sum(sum(DD2));
    NK=sum(Connect); % total number of connections (one-sided)

    cutoff=[-Inf cumsum(DD2(:))'];
    cutoff_lo=cutoff(1:end-1);
    cutoff_hi=cutoff(2:end);

    Random=zeros(N,N);
    % randomization keeping marginal probabilities for a connection
    for i=2:2:NK
        col=1;
        row=1;
        while row==col || Random(row,col)==1
            rnd=rand*cutoff(end);
            f=find(rnd>=cutoff_lo&rnd<cutoff_hi);
            row=1+floor((f-1)./N);
            col=f-(row-1)*N;
        end
        Random(row,col)=1;
        Random(col,row)=1;
    end
    
    return
end


%%
% start other randomisation type (weighted, p-type randomization, etc.)
if size(Connect,1)~=size(Connect,2)
    error('Input matrix must be square.')
end

nboot=50;
typenum=0; %
NK=-1;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'nboot')
        nboot=varargin{v+1}        
    elseif strcmpi(varargin{v},'K')
        NK = varargin{v+1};
    elseif strcmpi(varargin{v},'type')
        if strcmpi(varargin{v+1},'p-type')
            typenum=1;
        elseif strcmpi(varargin{v+1},'fixed')
            typenum=2;
        elseif strcmpi(varargin{v+1},'weighted')
            typenum=3;
        elseif strcmpi(varargin{v+1},'none')
            typenum=0;
        else
            error('No such randomisation type.')
        end
    end
end

N=size(Connect,1);
Temp=Connect.*(1-eye(N));
DD=sum(Temp); % degree distribution
DD2=(DD'*DD).*(1-eye(N));
DD2=DD2.^4; % correction... entirely emperical!!!!!!!
DD2=DD2./sum(sum(DD2));
if NK==-1
    NK=sum(sum(Temp)); % total number of connections (one-sided)
else
    NK=NK*N;
end

if typenum==1
    cutoff=[-Inf cumsum(DD2(:))'];
    cutoff_lo=cutoff(1:end-1);
    cutoff_hi=cutoff(2:end);
end  
    
Random=zeros(N,N);
if typenum==1
    % randomization keeping marginal probabilities for a connection
    for i=2:2:NK
        col=1;
        row=1;
        while row==col || Random(row,col)==1
            rnd=rand*cutoff(end);
            f=find(rnd>=cutoff_lo&rnd<cutoff_hi);
            row=1+floor((f-1)./N);
            col=f-(row-1)*N;
        end
        Random(row,col)=1;
        Random(col,row)=1;
    end
elseif typenum==0
    % normal randomization
    for i=2:2:NK
        col=1;
        row=1;
        while row==col || Random(row,col)==1
            rnd=floor(rand*N*N);
            row=1+floor(rnd./N);
            col=1+rnd-(row-1)*N;
        end
        Random(row,col)=1;
        Random(col,row)=1;
    end
elseif typenum==2
    error('Not yet implemented')
elseif typenum==3
    % simply shuffle the existing connections
    list = sdiag(Connect);
    list = list(randperm(length(list)));
    Random = sdiag(list,'rowcol',[N,N]);
    Random = Random+Random'+eye(N);
end
