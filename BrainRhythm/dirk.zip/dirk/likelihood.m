function LL = likelihood(Obs,Exp,N,p)

% calculate the log-likelihood from the observed and expected covariance
% matrices. The observed matrix is based on N observations, the exptected
% matrix on p parameters.
D2 = det(Obs); if D2<0, D2=0; end
D1 = det(Exp); if D1<D2, D1=D2; end
LL = (N-1)*(log(D1)-log(D2)+(trace(Obs*inv(Exp))-p));