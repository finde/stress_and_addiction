function [out]=RandomWalk(len,varargin)
% performs a random walk starting at 0
% len: length of random walk output vector
% varargin:
%   'Normalize': 
%     makes the signal unit variance and zero mean (default: no
%     normalization)
%   '1/f': makes the signal 1/f in stead of 1/squared(f)

if nargin<1
    len=1000;
end
norm=0;
expnt=2;
for i=1:length(varargin)
    if strcmpi(varargin{i},'normalize')
        norm=1;
    elseif strcmpi(varargin{i},'1/f')
        expnt=1;
    end
end

if expnt==2
    out = cumsum(rand(1,len)-.5);
else
    out(1)=0.0;
    for i=2:len
        out(i) = .707*out(i-1) + .707*(randn);
    end
end

if norm
    out=(out-mean(out))./std(out);
end

return
%%
norm=0;
if length(varargin)>0
    for v=1:2:length(varargin)-1
        if strcmpi(varargin{v},'normalize')
            if strcmpi(varargin{v+1}, 'on'), norm=1; end
            if strcmpi(varargin{v+1}, 'off'), norm=0; end
        end
    end
end


out(1)=0;
for i=2:len
    out(i)=out(i-1)+rand-.5;
end

if norm==1
    out=(out-mean(out))/std(out);
end