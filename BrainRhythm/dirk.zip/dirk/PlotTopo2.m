function [axes_handle] = PlotTopo2(Data,Chanlocs,Maplimits,PlotFrame,Font,FontSize)
%



if nargin < 9
    Font = 'Helvetica';
end
if nargin < 10
    FontSize = 10;
end


% get NRows and NCols from PlotFrame
NRows = PlotFrame{1};
NCols = PlotFrame{2};
FrameSet = PlotFrame{3};

% now plot
subplot(NRows,NCols,FrameSet); 
set(gca,'fontsize',FontSize,'fontname',Font)
topoplot(Data,Chanlocs,'maplimits',Maplimits,'conv','on','electrodes','on');
colorbar;
axes_handle = gca;

