function idx = findmin(X)

[~,idx] = min(X);
