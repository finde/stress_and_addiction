function [signal] = SineVec(Freq, N, varargin)

% [win] = SineVec(Freq, N, varargin)
%
%   produces a complex valued vector of a cosine wave with i*sine wave
%   N is the length of the data vector.
%   
%  varargin:
%    - 'cycles': replace N with number of cycles of Freq Hz sine waves
%    - 'rate'  : sampling rate

Rate=250;
WT='none';
Cycles=3;
Real = 0;
DoCycles=0;

for v=1:2:length(varargin)
    if strcmpi(varargin{v},'cycles')
        Cycles=varargin{v+1};
        N = round(Cycles.*Rate./Freq);
        DoCycles=1;
    elseif strcmpi(varargin{v},'rate') || strcmpi(varargin{v},'srate')
        Rate=varargin{v+1}; % overrides N
        if DoCycles
            N = round(Cycles.*Rate./Freq);
        end
    else
        error('Unknown option')
    end
end

winr = cos([0:N-1].*(2*pi).*Freq./Rate);
wini = sin([0:N-1].*(2*pi).*Freq./Rate);

signal = winr + wini.*1i;


