function [res] = sdiag(input, varargin)
% Extracts subdiagonal data from top to bottom, column by column.
% *or* makes a subdiagonal matrix from data (WHEN rowcol is specified)
%   input: - data matrix (to create vector from matrix
%          - data vector (to create square matrix from vector)
%   varargin = key-value type options:
%     'complete': 1, 0 = completes the upper half with ones on the diagonal
%                 and symmetrical values above diagonal (makes a
%                 correlation matrix, default 'no')
%     'dir': 0=row by row, 1=col by col


type = 0; % matrix to vector
direction = 0; % row-by-row
compl = 0;
diagonal = false;
docell = iscell(input);

for i=1:2:length(varargin)
    if strcmpi(varargin{i},'complete')
        if isnumeric(varargin{i+1})
            compl = varargin{i+1};
        else
            if isnumeric(varargin{i+1}) || islogical(varargin{i+1})
                compl = varargin{i+1};
            else
                compl = strcmpi(varargin{i+1},'on') || strcmpi(varargin{i+1},'yes');
            end
        end
    end
    if strncmpi(varargin{i},'dir',3)
        direction = varargin{i+1};
    end
    if strncmpi(varargin{i},'diag',4)
        diagonal = varargin{i+1};
    end

end

if size(input,1)==1 || size(input,2)==1
    type=1;
end

if size(input,3)>1
    error('input must be one or two dimensional.')
end

if type==0 % from matrix to vector
    NR = size(input,1);
    NC = size(input,2);
    N=min(size(input));
    if docell, res={}; else res=zeros(1,N*(N-1)/2); end
    if direction == 0
        count=0;
        for R=(2-diagonal):N
            for C=1:(R-1+diagonal)
                count=count+1;
                if docell
                    res{count} = input{R,C};
                else
                    res(count)=input(R,C);
                end
            end
        end
    else
        count=0;
        for C=1:(N-1+diagonal)
            for R=(C+1-diagonal):N
                count=count+1;
                if docell
                    res{count}=input{R,C};
                else
                    res(count)=input(R,C);
                end
            end
        end
    end
else % from vector to matrix
    % define size of result
    if ~diagonal
        N=sqrt((length(input)+1/8)*2)+.5;
    else
        N=sqrt((length(input)+1/8)*2)+.5-1;
    end
    if N~=floor(N)
        error('Wrong number of elements in array to create a square matrix.')
    end
    
    res=zeros(N,N);
    % loop and fill
    if direction==0
        count=0;
        for R=(2-diagonal):N
            for C=1:(R-1+diagonal)
                count=count+1;
                if docell
                    res{R,C}=input{count};
                else
                    res(R,C)=input(count);
                end
            end
        end
    else
        count=0;
        for C=1:(N-1+diagonal)
            for R=(C+1-diagonal):N
                count=count+1;
                if docell
                    res{R,C}=input{count};
                else
                    res(R,C)=input(count);
                end
            end
        end
    end    
    if ~docell && compl
        if ~diagonal
            res=res+res';
            res(logical(eye(N)))=1;
        else
            res=res+res';
            res(logical(eye(N)))=res(logical(eye(N)))./2;
        end
    end
end

if islogical(input)
    res = logical(res);
end


            