function V = mat2vec(M)

V=M(:);
