function [Observed Expected Lambda] = Genome_QQ(P,varargin)

% calculate the expetd p-values based on the (unsorted) p-values from a
% genome wide genetic study (or any other study really).
%
% Input: 
%
%   - P: list of observed p-values
%   - varargin:
%     - 'plot': [0/1] create a q-q plot
%     - 'gc'  : [0/1] or vector of quantiles (e.g., [.1 .2 .3 .4 .5]: do a
%               correction for inflation by calculating Lambda and applying
%               genomic control at all passed percentile values. If 1, then
%               the median p-value is used for lambda calculation.
%
% Output:
%   - Observed
%   - Expected
%   - Lambda

doplot = 0;
dogc = 0;
for v=1:2:length(varargin)
    if strcmp(lower(varargin{v}),'plot')
        doplot=varargin{v+1};
    elseif strcmp(lower(varargin{v}),'gc')
        dogc=varargin{v+1};
    end
end

chi2obs = icdf('chisquare',1-prctile(P,50),1);
chi2exp = icdf('chisquare',1-.5,1);
MedianLambda = chi2obs/chi2exp;

if 1==dogc
    dogc=.5;
end
if dogc
    for c=1:length(dogc)
        chi2obs = icdf('chisquare',1-prctile(P,100*dogc(c)),1);
        chi2exp = icdf('chisquare',1-dogc(c),1);
        Lambda(c) = chi2obs/chi2exp;
    end
    Lambda=mean(Lambda);
else
    Lambda = MedianLambda;
end

% change data orientation when necessary and calculated the (sorted)
% observed and expected -log10(p-values)
if size(P,1)>1,
    P=P';
end
Observed = -log10(sort(P,'descend'));
Expected = -log10([length(Observed):-1:1]./length(Observed));

if doplot
    plot(Expected,Observed,'o','color','k','markersize',3,'markerfacecolor','k');
    hold on;
    xlim([0,max([6 Observed Expected])]);
    ylim([0,max([6 Observed Expected])]);
    set(refline(1),'color','k');
    set(gca,'xtick',[0:9],'ytick',[0:9])
    plot(prctile(Expected,10:10:90),prctile(Observed,10:10:90),'or','linewidth',.1,'markerfacecolor','r','markersize',3);
    % set(text(max(xlim)*.9,max(ylim)*.1,sprintf('{\\lambda}_{median}=%.3f',MedianLambda)),'hor','right','fontsize',12);
end

if dogc
    % do correction (Genomic Control) ONLY if Lambda > 1! Take first lambda
    % score ONLY!
    if Lambda>1
        Observed = -log10(1-cdf('chisquare',icdf('chisquare',1-sort(P,'descend'),1)./Lambda,1));
    end
    if doplot
        hold on
        plot(Expected,Observed,'rd','markersize',3,'markerfacecolor','w')
    end
end

    
