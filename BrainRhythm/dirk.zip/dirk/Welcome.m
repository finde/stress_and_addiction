pathdef;
disp('Path set. Hallo Dirk.')
