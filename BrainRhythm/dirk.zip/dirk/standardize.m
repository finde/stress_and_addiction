function [corr]=standardize(cov)

SDs=sqrt(diag(cov));

corr = cov./(SDs*SDs');
