function [Out] = Graph_ScaleFree(N,K)

%Out = Graph_Lattice(N,K,0);
Out = Graph_Rnd([N,K]);

Out(logical(eye(N)))=.5;

for i=1:4
    for R=1:N
        for C=1:N
            if R~=C && Out(R,C)
                Out(R,C)=0;
                Out(C,R)=0;
                dist=cumsum(sum(Out));
                ndx=R;
                while ndx==R || Out(R,ndx)==1
                    rnd=rand*dist(end);
                    f=find(find(dist<=rnd));
                    if isempty(f)
                        ndx=1;
                    else
                        ndx=1+max(f);
                    end
                    %fprintf('%d %d %d\n',ndx,R,Out(R,ndx));
                end
                Out(R,ndx)=1;
                Out(ndx,R)=1;
            end
        end
    end
end
[a order]=sort(sum(Out));
Out=Out(order,order);
Out(logical(eye(N)))=0;
            
            
    
    
