function [index slope] = zerocross(data, varargin)

try
    cMat = 0;
    cPrec = 0;
    for v=1:2:size(varargin,2)
        switch varargin{v}
            case 'matrix',  cMat = varargin{v+1}>0; 
            case 'precise', cPrec = varargin{v+1}>0;
        end
    end
catch
    error('zerocross: Error parsing arguments.');
end
                    
if size(data,1)==1
    data=data';
end

index=[];
slope=[];

for c=1:size(data,2)
    a=data(1:end-1,c)';
    b=data(2:end,c)';
    ndx=union(intersect(find(a<0),find(b>0)),intersect(find(a>0),find(b<0)));
    if ~isempty(ndx)
        slp=b(ndx)-a(ndx);

        % do precise location when opted for
        if cPrec
            tot=abs(a(ndx))+abs(b(ndx));
            ndx = ndx + abs(a(ndx))./tot;
        else
            % leave it
        end

        % write data to output
        if cMat
            index(1:length(ndx),c) = ndx;
            slope(1:length(ndx),c) = slp;
        else
            index{c} = ndx;
            slope{c} = slp;
        end
    end
end