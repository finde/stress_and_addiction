function PlotConnectivity(Conn,PlotEEG,Perc,ScaleDot,ScaleLine,maplimits,CM)

% Plots a 3D plot of the connectivity matrix 
% - PlotEEG: EEGLAB struct with positions stored in the '.chanlocs'. The
%   number of channels in the PlotEEG struct should match the dimensions of
%   the (symmetric) connectivity matrix.
% - Conn holds connectivity matrix with values [0,1]. 
% - Perc is the percentage of connections that should NOT be
%   plotted, that is '95' will drop 95% of the connections and plot only the
%   strongest 5%!!!
% - ScaleDot scales the dot by a factor (def = 1)
% - ScaleLinet scales the line by a factor (def = 1)
% - maplimits: def=[0 1], alternatively use [0 max(sdiag(Conn))] where
%   sdiag are the subdiagonal values of matrix Conn.

if nargin<7 || isempty(CM)
    CM = colormap('jet');
end
if nargin<6 || isempty(maplimits)
    lo = -max(abs(Conn(:)));
    hi = max(abs(Conn(:)));
else
    lo = maplimits(1);
    hi = maplimits(2);
end
if nargin<5 || isempty(ScaleLine)
    ScaleLine=1;
end
if nargin<4 || isempty(ScaleDot)
    ScaleDot=1;
end
if nargin<3 || isempty(Perc)
    Perc=95;
end

cPlotBinary = false;
if length(unique(Conn(:)))==2
    warning('Percentage ignored');
    cPlotBinary = true;
end

%% plot the lines
% Conn(logical(eye(size(Conn,1))))=0;

hold on
% plot3(-[PlotEEG.chanlocs(:).Y],[PlotEEG.chanlocs(:).X],[PlotEEG.chanlocs(:).Z],'ok','markersize',4)
for ch1=1:size(Conn,1)-1,
    for ch2=ch1+1:size(Conn)
        if isempty(Perc) || Perc==0 || cPlotBinary
            if cPlotBinary && ~Conn(ch1,ch2)
                plotit=false;
            else
                plotit = true;
            end
        else
            plotit = Conn(ch1,ch2)>prctile(sdiag(Conn),Perc);
        end
        if plotit
            c = Conn(ch1,ch2);
            if c>hi, c=hi; end
            if c<lo, c=lo; end
            h = line(-[PlotEEG.chanlocs([ch1 ch2]).Y],[PlotEEG.chanlocs([ch1 ch2]).X],[PlotEEG.chanlocs([ch1 ch2]).Z]);
            lcol = (c-lo)/(hi-lo);
            col = CM(floor(lcol.*.9999.*size(CM,1)+1),:);
            set(h,'linewidth',ScaleLine*abs(c)+.001,'color',col)
        end
    end
end
%% plot nodes as spheres
[X Y Z] = sphere;
X=X*ScaleDot*.15;
Y=Y*ScaleDot*.15;
Z=Z*ScaleDot*.15;
deg = sum(Conn)./(size(Conn,1)-1);
deg = (deg-maplimits(1))./diff(maplimits);
for ch=1:size(Conn,1)
    if ch==24
        scol='green';
    else
        scol='red';
    end
    try
        surf(X*deg(ch)-PlotEEG.chanlocs(ch).Y,Y*deg(ch)+PlotEEG.chanlocs(ch).X,Z*deg(ch)+PlotEEG.chanlocs(ch).Z,'FaceColor',scol,'EdgeColor','none')
    catch
    end
end
camlight headlight; lighting phong
view([-78 34])

xlabel('+Right -Left')
ylabel('+Front -Back')
zlabel('+Up -Down')

     
