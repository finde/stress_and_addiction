function [Filt Shift] = Wiener1D(Data)
% Wiener adaptive filter for (1D) EEG data. Assumes that the evoked
% potentials/1D data are in columns. The columns are the subjects

Filt = zeros(size(Data));
Shift = zeros(1,size(Data,2));
% Stretch not yet implemented

Filt = Data;
for rep=1:3 % fixed number of iterations for now
    M = nanmean(Filt,2);
    for col=1:size(Data,2)
        x = xcorr(M,Data(:,col),5,'unbiased');
    end
end
        
    

