function ShapeFigure(fighndl,varargin)

% move and stretch figures with subplots (axes) or an array of axes
%
% fighndl: either a figure handle or an array of axes
% 
% varargin:
%   'shift'  : [dx dy] moves left (negative dx) right (positive dx) up
%              (positive dy) or down (negative dy)
%   'stretch': [fx fy] "stretch" from center: resize while moving away from
%              midpoint (1.0 is no stretch)
%   'resize' : [fx fy] stretch each subfigure/axes (1.0 is no resizing)

stretch = [1 1];
resize = [1 1];
shift = [0 0];
for v=1:2:length(varargin)
    eval(sprintf('%s=%s;',varargin{v},mat2str(varargin{v+1})));
end

if strcmp(get(fighndl,'type'),'figure')
    ch = get(fighndl,'children');
else
    ch = fighndl; % assume type 
    if ~strcmp(get(ch(1),'type'),'axes') && ~strcmp(get(ch(1),'type'),'colorbar')
        error('fighndl must be either point to a figure object or a list of axes')
    end
end

for c=1:length(ch);
    try
        pos = get(ch(c),'position');
    catch
        continue
    end
    % first expand, then resize, then shift
    if length(pos)==4
        pos(1:2)=(pos(1:2)-.5).*stretch+.5-.5.*pos(3:4).*(resize-1);
        pos(3:4)=pos(3:4).*stretch.*resize;
    end
    % now shift
    if length(pos)>=2
        pos(1:2)=pos(1:2)+shift;
        set(ch(c),'position',pos)
    end
end



