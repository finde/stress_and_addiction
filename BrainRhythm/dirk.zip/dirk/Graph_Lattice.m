function [Graph]=Graph_Lattice(N, K, reconn)

% function [Graph]=Graph_Lattice(N, K, reconn)
%  creates an ordered graph of the lattice type.
%  N=size of graph. K=average degree. reconn is number of random
%  reconnections.

if nargin<3
    reconn=0;
end

NConn=N*K;

Graph=zeros(N,N);
R=1;
StartC=2;
C=StartC;
count=0;
while count<NConn
    Graph(R,mod((C-1),N)+1)=1;
    Graph(mod((C-1),N)+1,R)=1;
    count=count+2;
    R=R+1;
    C=C+1;
    if R>N
        R=1;
        StartC=StartC+1;
        C=StartC;
    end
end

Mask=zeros(N,N);
while reconn>0
    R1=1;
    C1=1;
    R2=1;
    C2=1;
    while C1==R1 || C2==R2 || (C1==C2&&R1==R2) || Mask(R1,C1)==1 || Graph(R1,C1)==0 || Graph(R2,C2)==1
        R1=1+floor(rand*N);
        C1=1+floor(rand*N);
        R2=1+floor(rand*N);
        C2=1+floor(rand*N);
    end
    Graph(R1,C1)=0;
    Graph(C1,R1)=0;
    Graph(R2,C2)=1;
    Graph(C2,R2)=1;
    Mask(R1,C1)=1;
    Mask(C1,R1)=1;
    Mask(R2,C2)=1;
    Mask(C2,R2)=1;
    reconn=reconn-1;
end        
    
