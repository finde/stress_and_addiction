function MovePos(hndl, deltapos)

% function MovePos(hndl,deltapos)
%   moves the object with position or xdata/ydata properties

for x=1:length(hndl)
    h=hndl(x);
    try
        pos = get(h,'position');
        pos(1:length(deltapos)) = pos(1:length(deltapos))+deltapos;
        set(h,'position',pos);
    catch
        % try 'XData' and 'YData';
        X=get(h,'xdata');
        Y=get(h,'ydata');
        X=X+deltapos(1);
        Y=Y+deltapos(2);
        set(h,'xdata',X);
        set(h,'ydata',Y);
    end
end

    
    