function res = localmin(D)
% find local minima in vector D

if isvector(D) && size(D,1)==1
    D=D';
end

res=zeros(size(D,1),size(D,2));

for col=1:size(D,2)
    res(:,col) = [D(1,col)<D(2,col) ; D(2:end-1,col)<D(1:end-2,col) & D(2:end-1,col)<D(3:end,col) ; D(end,col)<D(end-1,col)];
end



