function Sig = SimulateAlphaModulation(Len, Exponent, Freq, Rate)

% Simulate a alpha modulation signal by taking a ~10 Hz random signal and
% applying a one-over-f envelope

%Sig = OneOverF_Alpha(Len,Exponent,Rate);
%Sig = filter_fir(Sig',Rate,9.0,11.0,3.0)';
Sig = real(SineVec(Freq,Len,'rate',Rate));
Mask = OneOverF_Alpha(Len,Exponent,Rate);
Mask = (Mask-min(Mask))./max(Mask);
Sig = Sig.*Mask';
