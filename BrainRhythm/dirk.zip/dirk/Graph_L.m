function [L, Ldist, Ldistmat] = Graph_L(Graph, varargin)

% Calculate Watts & Strogatz Graph parameter C (with extensions).
%   Graph = Square (1,0) valued graph connectivity matrix (may be weighted).
%   'penalty': value for penalty if two nodes are not connected. (def=Inf)
%   'Harmonic': use harmonic mean (1/mean(1/L) in stead of mean(L)) (def='on') 
%
% L=average L
% Ldist=L of individual nodes

if size(Graph,1)~=size(Graph,2)
    error('Graph_L: Graph must be square');
end
if max(max(Graph))>1.0 || min(min(Graph))<0.0
    warning('Graph_L: designed for 0, 1 graphs only (unweighted).');
end

N=size(Graph,1);
Penalty = Inf;
Harmonic = 1;

for i=1:length(varargin)
    if strcmpi(varargin{i},'penalty')
        Penalty = varargin{i+1}; % should be numberic (0 to +Inf)
    elseif strcmpi(varargin{i},'harmonic')
        if isnumeric(varargin{i+1})
            Harmonic = varargin{i+1};
        else
            Harmonic = strcmpi(varargin{i+1},'on') | strcmpi(varargin{i+1},'yes');
        end
    end
end

Graph(logical(eye(N)))=1;

L=zeros(N,N);
for i=1:N
    f=false(1,N);
    f(i)=true;
    for step=1:N
        oldf = f;
        f = logical(f*Graph);
        L(i, f & ~oldf) = step;
        if sum(f)==N
            break
        end
    end
    L(i, L(i,:)==0) = Penalty; % apply penalty to unconnected nodes
    if ~Harmonic
        L(i,i)=0; % but diagonal stays 0 for nonharmonic averaging;
    else
        L(i,i)=Inf;
    end
end

Ldistmat = L;

if Harmonic
    warning off
    Ldist=(N-1)./sum(1./L,2); % each node has (N-1) possible connections
    L=1./mean(1./Ldist);
    warning on
else
    Ldist=sum(L,2)./(N-1); 
    L=mean(Ldist);
end




