function plotellipse(q,plotoptions)

% plots an ellipse
% N Baroni
% March 99
% function plotellipse([xc, yc, a, b, alpha], plotoptions)
%
% (xc,yc) define ellipse centre
% a & b are the major and minor axes
% alpha is the angle of rotation of the ellipse
% plotoptions is a matlab line colour and line type string, eg 'r--'

xc = q(1);
yc = q(2);
a = q(3);
b = q(4);
alpha = q(5);

t = 0:pi/200:2*pi;

xu = a*cos(t);
yv = b*sin(t);

xx = xu*cos(-alpha) - yv*sin(-alpha);
yy = xu*sin(-alpha) + yv*cos(-alpha);

x = xc + xx;
y = yc + yy;

if isempty(plotoptions)
    plot(x,y);
elseif iscell(plotoptions)
    plot(x,y,plotoptions{:});
else    
    plot(x,y,plotoptions);
end
    