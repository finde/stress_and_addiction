function Globals_DFA(cAge,cICALevel)
% age={5,7,16,18,2550}
% cICALevel={1,2,3} for LoEOG, MidEOG, HiEOG

global cFreqs cFreqNames cFitNames cAnalType cCritR cNFreqs cCycles cLeadList cNLeads
global cNEpochs cRate cCode cTime PathIn PathOut %#ok<*NUSED>
global FileList cFreqNamesLong

FileList = Globals_List(cAge);

switch (cICALevel)
    case 1
        cCritR = .4;
        cAnalType = 'LoEOG';
    case 2
        cCritR = .55;
        cAnalType = 'MidEOG';
    case 3
        cCritR = .7;
        cAnalType = 'HiEOG';
    case 4
        cCritR = 1.1;
        cAnalType = 'NoEOG';
end

if cAge==7 || cAge==18
    cCode=2;
else
    cCode=1;
end

% machine dependent 
PathOut = pwd;
% machine dependent 
if ismac
    if exist('/Volumes/RaidTB')
        root='/Volumes/RaidTB';
    else
        root='/Volumes/FireTB';
    end
    fprintf('1 TB external firewire disk on a mac. Using directories on "%s".\n',root);
    if cAge < 10 % Caro
        PathIn = [root '/Alle data/Caroline -- BackEEG/Eeglab/ICAFilt/'];
        PathOut= pwd;
    elseif cAge < 20% Toos
        PathIn = [root '/Alle data/Toos -- BackEEG/Eeglab/ICAFilt/'];
        PathOut= pwd;
    else % Danielle
        PathIn = [root '/Alle data/Danielle -- BackEEG/Eeglab/ICAFilt/'];
        PathOut= pwd;
    end
else 
    fprintf('Working on Charlie or Buster. Mounting M: \n');
    if cAge<10
        PathIn = 'M:\Alle data\Caroline -- BackEEG\Eeglab\ICAFilt\'; %#ok<*NASGU>
        PathOut= pwd;
    elseif cAge < 20
        PathIn = 'M:\Alle data\Toos -- BackEEG\Eeglab\ICAFilt\';
        PathOut= pwd;
    else % Danielle
        PathIn = 'M:\Alle data\Danielle -- BackEEG\Eeglab\ICAFilt\';
        PathOut= pwd;
    end
end

% some constants
if cAge<20
    cNEpochs = 3;
    cLeadList = {'Fp1','Fp2','F3','F4','F7','F8','C3','C4','P3','P4','O1','O2','T5','T6'};
else
    cNEpochs = 1;
    cLeadList = {'Fp1','Fp2',...
                 'F7','F3','F1','Fz','F2','F4','F8',...
                 'T7','C3','Cz','C4','T8',...
                 'P7','P3','Pz','P4','P8',...
                 'O1','Oz','O2'};
end
cNLeads = length(cLeadList);
cRate = 250;

% fit parameters
cFitNames = {'linear','robust','weighted'}; % fit numbers 0, 1, and 2 in Scaling_DFA call

% frequency parameters
cFreqNames = {'th','thr','al','alr','be','ber','raw'};
cFreqNamesLong = {'Theta','ThetaRel','Alpha','AlphaRel','Beta','BetaRel','Raw'};
switch cAge
    case 5, cFreqs = [ ...
         3.0  5.4;
         2.8  5.4;
         5.8 13.0;
         6.4 10.9;
        15.0 25.0;
        13.4 23.4;
         0.5 38.0  ];
    case 7, cFreqs = [ ...
         3.0  5.4
         2.8  5.4
         5.8 13.0
         6.6 11.1
        15.0 25.0
        13.6 23.6
         0.5 38.0  ];
    case 16, cFreqs = [ ...
         3.0  5.4
         2.8  5.4
         5.8 13.0
         7.4 11.9
        15.0 25.0
        14.4 24.4
         0.5 38.0
        ];
    case 18, cFreqs = [ ...
         3.0  5.4
         2.8  5.2
         5.8 13.0
         7.6 12.1
        15.0 25.0
        14.6 24.6
         0.5 38.0  ];
    case 25, cFreqs = [ ...
         3.0  5.4
         2.8  5.0
         5.8 13.0
         7.8 12.3
        15.0 25.0
        14.8 24.8
         0.5 38.0  ];
    case 50, cFreqs = [ ...
         3.0  5.4
         2.8  5.2
         5.8 13.0
         7.4 11.9
        15.0 25.0
        14.4 24.4
         0.5 38.0  ];
end
cNFreqs = size(cFreqs,1);

% DFA parameters
cCycles = 2.5;
cTime = [1.5 20]; % in seconds

