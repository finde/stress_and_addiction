function Graph_PlotTree(G)

% Plot a tree graph
N=size(G,1);
if N~=size(G,2)
    error('Need symmetrical matrix for a graph')
end

G(logical(eye(N))) = 0;

K = sum(G);
done = false(1,length(K));
AllPos = zeros(length(K),2); % X and Y positions
[~,idx] = sort(K,'descend');

% Start with first in the middle
AllPos(idx(1),:) = [0,0];
done(idx(1)) = true;

do = G(idx(1),:);
next = false(1,length(K));

count=0;
for v=find(do)
    count=count+1;
    AllPos(idx(v),1) = cos(count*2*pi/sum(do));
    AllPos(idx(v),2) = sin(count*2*pi/sum(do));
    done(idx(v))=true;
end

for v=find(do)
    do2 = G(v,:) & ~done;
    
    count2=0;
    for v2=find(do2)
        count2=count2+1;
        if done(idx(v2))
            continue
        end
        AllPos(idx(v2),1) = cos(count2*2*pi/sum(do2))+2*AllPos(idx(v),1);
        AllPos(idx(v2),2) = sin(count2*2*pi/sum(do2))+2*AllPos(idx(v),2);
        done(idx(v2))=true;
    end
    for v2=find(do2)
        do3 = G(v2,:);
        count3=0;
        for v3=find(do3)
            count3=count3+1;
            if done(idx(v3))
                continue
            end
            AllPos(idx(v3),1) = cos(count3*2*pi/sum(do3))+2*AllPos(idx(v2),1);
            AllPos(idx(v3),2) = sin(count3*2*pi/sum(do3))+2*AllPos(idx(v2),2);
            done(idx(v3))=true;
        end
    end
end

gplot(G,AllPos,'ok-')
    
    
