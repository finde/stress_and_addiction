function R = nandetrend(X, varargin)

R = nan(size(X));
if size(X,1)==1 || size(X,2)==1
    ndx = ~isnan(X);
    R(ndx) = detrend(X(ndx), varargin{:});
else
    for col = 1:size(X,2);
        ndx = ~isnan(X(:,col));
        R(ndx,col) = detrend(X(ndx,col), varargin{:});
    end
end
    