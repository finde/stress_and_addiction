function [Out Header] = MergById(Data, varargin)
%function [Out] = MergById(Data, varargin)
% Merges two datasets into a single one by the use of 1 or more ID columns.
% May merge with "and", and "or" operators.
% - Data: cell array with two cells. Data{1} holds first dataset, data{2}
% holds second. *** Only numeric input *** is valid for now.
% - varargin:
%    o 'IdColumns': Columns that uniquely identify (together)
%      persons/subjects/items in each file. (Note. There are some exceptions
%      possible to the uniqueness.) Format: Cell array with two elements 
%      consisting of a (1,2) matrix. If only one cell then both datasets are
%      assumed to have the same ID Columns. Default: {[1 2], [1 2]}
%    o 'Include'  : Column numbers to be included in the output dataset. cell
%      array with two vectors. IdColumns will be automatically included 
%      (once). default: {[],[]} includes all columns.
%    o 'MergeType': 'and' includes only complete matches in both files.
%      'or' in either file; 'left' all from the first dataset; 'right' all
%      from the right dataset. default 'or';
%    o 'missing'  : missing values will be set to this value (default: NaN);
%    o 'header'   : 1x2 cell array of cell arrays of strings represent the
%      input headers of equal length to the number of data input columns.
%      Returns the reformatted header.

IdColumns={[1 2],[1 2]};
Include={[],[]};
MergeType='or';
Missing=NaN;
Aggregate = {[],[]};

if ~iscell(Data) || length(Data)~=2
    error('Data must be a {1,2} cell array holding two datasets (matrices).')
end
if iscell(Data{1}) || iscell(Data{2})
    error('Data cannot be a cell array')
end
   
doheader=0;
HeaderIn = {};
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'IdColumns')
        IdColumns = varargin{v+1};
    elseif strcmpi(varargin{v},'Include')
        Include = varargin{v+1};
    elseif strcmpi(varargin{v},'MergeType')
        MergeType = varargin{v+1};
    elseif strcmpi(varargin{v},'Missing')
        Missing = varargin{v+1};
    elseif strcmpi(varargin{v},'Aggregate')
        Aggregate = varargin{v+1};
    elseif strcmpi(varargin{v},'Header')
        HeaderIn = varargin{v+1};
        doheader=1;
        if length(HeaderIn)~=2
            error('header info must be a 1x2 cell array of strings (each in a cell array)')
        end
        for st=1:2
            if size(HeaderIn{st},2)<size(HeaderIn{st},1),
                HeaderIn{st}=HeaderIn{st}';
            end
        end
    else
        error(sprintf('Unknown option: %s',varargin{v}));
    end
end

if nargout<2
    doheader=0;
end



        
% fill IdCols with the IdColumns to look for
if ~iscell(IdColumns) || length(IdColumns)==1
    IdCols={IdColumns,IdColumns};
else
    IdCols=IdColumns;
end
if doheader
    Header = HeaderIn{1}([IdCols{1} Aggregate{1}]);
end

% check Aggregate
if ~iscell(Aggregate) || length(Aggregate)~=2
    error('Aggregate option must be a 1,2 cell array')
end
if length(Aggregate{1})~=length(Aggregate{2})
    error('Aggregate column number for dataset 1 must equal that of dataset 2')
end

% fill Inc with columns to include
if ~iscell(Include) || length(Include)==1
    Inc={Include,Include};
else
    Inc=Include;
end
for i=1:2
    if isempty(Inc{i})
        Inc{i}=setdiff([1:size(Data{i},2)],IdCols{i});
    else
        % let explicit statements about include allow to include extra
        % IdCOlumns
    end
    % remove the aggregate columns
    Inc{i} = setdiff(Inc{i},Aggregate{i});
end
if doheader
    Header = [Header HeaderIn{1}(Inc{1}) HeaderIn{2}(Inc{2})];
end




% begin merging: find Ids
for i=1:2
    Id{i}=Data{i}(:,IdCols{i});
    % determine min and max value of each Id column (across both files)
    if i==1
        try
        for c=1:size(Id{i},2)
            mn(c)=min(Id{i}(:,c));
            mx(c)=max(Id{i}(:,c));
        end
        catch E
            throw(E)
        end
    else % take minimum of both datasets
        for c=1:size(Id{i},2)
            mn(c)=min([Id{i}(:,c); mn(c)]);
            mx(c)=max([Id{i}(:,c); mx(c)]);
        end
    end
end
% now realign Id values to [0, max-min+1] for each column
for i=1:2
    for c=1:size(Id{i},2)
        Id{i}(:,c)=Id{i}(:,c)-mn(c); % make all ids start with 0
        if c==1
            Unique{i}=Id{i}(:,c);
        else
            % so if id1=1..100, id2=1..10, and id3=1..2, then factor for
            % id1=1, id2=10, id3=10*2=20.
            factor=1;
            for c2=1:c-1
                factor=factor*(mx(c2)-mn(c2)+1); 
            end
            Unique{i}=Unique{i}+Id{i}(:,c)*factor;
        end
    end
end

if size(Id{1},2)~=size(Id{2},2)
    error('Both datasets must have the same number of Id comlumns.');
end

switch lower(MergeType)
    case 'left'
        MergeId=Unique{1};
    case 'right'
        MergeId=Unique{2};
    case {'and','both'}
        MergeId=intersect(Unique{1},Unique{2});
    case {'or','either'}
        MergeId=union(Unique{1},Unique{2});
    otherwise
        error
end

Out=ones(length(MergeId),size(IdCols{1},2)+length(Inc{1})+length(Inc{2})+length(Aggregate{1}))*Missing;
for i=1:length(MergeId)
    start = length(IdCols{1})+length(Aggregate{1});
    for d=1:2
        % move starting position (column number) in output matrix
        if d>1
            start=start+length(Inc{d-1});
        end
        % ignore IDs that are missing values.
        if isnan(Missing)
            if isnan(MergeId(i))
                continue
            end
        else
            if MergeId(i)==Missing
                continue
            end
        end
        % find data line in dataset d
        f=find(Unique{d}==MergeId(i));
        if ~isempty(f),
            if length(f)>1
                warning('multiple instance found of id:');
                fprintf('Id: '); fprintf('%d ',Data{d}(f(1),IdCols{d})); fprintf('\n')
            end
            Out(i, 1:length(IdCols{d}))=Data{d}(f(1),IdCols{d}); % always add id
            if d==1
                AggData1 = Data{d}(f(1),Aggregate{d});
                Out(i, 1+length(IdCols{1}):length(IdCols{1})+length(Aggregate{1})) = AggData1;
            else
                AggData1 = Out(i, 1+length(IdCols{1}):length(IdCols{1})+length(Aggregate{1}));
                AggData2 = Data{d}(f(1),Aggregate{d});
                Out(i, 1+length(IdCols{1}):length(IdCols{1})+length(Aggregate{1})) = mean_NaN(cat(3,AggData1,AggData2),3,Missing);
            end             
            Out(i, start+1:start+length(Inc{d}))=Data{d}(f(1),Inc{d});
        end
    end
end
         

            

        