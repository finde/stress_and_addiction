function yf = sgolay_diw(x,y,n,F,d)
% Savitzky-Golay filtering 
% function yf = sgolay_diw(x,y,n,F,d)
%  Data: (x,y) 
%  interpolating order n (Must be < n-1)
%  Frame length: F (Must be < length(x) and odd)
%  d: differentiation order >=0 

d = round(d); % force integer 
if nargin < 5
    d=0; % no differentiation
end % if 

N = length(x); % 

xr = max(x)-min(x); 
x=(x-mean(x))/xr; % sort of normalise x 
xc = xr^d; % correction factor for scaling x 

if fix(F/2) == F/2
  error('F must be odd.')
end % if 

if n >(F-1)
  error('Interpolating order < window width')
end % if 

F2 = (F-1)/2; % should be integer 
yf = y; % dummy start 

for i=F2+1:N-F2
   idx = i-F2:i+F2; 
   xloc = x(idx);
   yloc = y(idx); 
   p = polyfit(x(idx),y(idx),n); 
   if d > 0 
       for k=1:d % differentiate d times 
           p = polyder(p); % differentiate once 
       end % for 
   end % if 
   yf(i) = polyval(p,x(i))/xc; % centre point 
end % for 

end
