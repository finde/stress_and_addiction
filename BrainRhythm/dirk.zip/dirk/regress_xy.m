function [b,bint,r,rint,stats] = regress_xy(X,Y,alpha)
% seee help regress for more info. Regress_xy only flips x and y parameters
% but additionally adds the "ones" that are needed for the intercept to the
% x variable.

if size(X,1)==1
    X=X';
end
if size(Y,1)==1
    Y=Y';
end

X=[ones(size(X,1),1) X];
if nargin<3
    [b,bint,r,rint,stats]=regress(Y,X);
else
    [b,bint,r,rint,stats]=regress(Y,X,alpha);
end
    


