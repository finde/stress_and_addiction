function hh = scatterd(varargin)
% extends scatter by accepting a matrix as single input

hh = scatter(varargin{1}(:,1),varargin{1}(:,2:end),varargin{2:end});
