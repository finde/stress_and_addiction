function Icompressed = Image_PCACompression(I,N)

G = double(rgb2gray(I));
M = mean(G);      
Mnew = repmat(M,size(I,1),1); 
DataAdjust = G - Mnew; 
C = cov(DataAdjust);   
[V, D] = eig(C); 
[~,idx] = sort(diag(D),'descend');
%V = V(:,idx);
%D = D(idx,idx);
FinalData = V' * DataAdjust';   
% End of PCA code 
  
% Start of Inverse PCA code,
OriginalData_trans = inv(V') * FinalData;                         
OriginalData = transpose(OriginalData_trans) + Mnew;           
figure, 
image(OriginalData)
colormap(gray)
% End of Inverse PCA code 
  
% Image compression 
Reduced_V = V;
Reduced_V(:,N+1:end);
CompressedData_trans = inv(Reduced_V') * FinalData;                         
CompressedData = CompressedData_trans';

figure,                                                                
set(gcf,'numbertitle','off','name','Compressed Image'),  
imshow(CompressedData) 