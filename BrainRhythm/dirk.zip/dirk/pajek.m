function pajek(adj_mat,filename,list)

% script from http://web.media.mit.edu/~nathan/matlab/pajek.m 

    kdist=sum(adj_mat);
    sizes=1+(kdist.^(1/1.5));
    n=size(adj_mat,1);

    fid = fopen(filename,'w');
    fprintf(fid, '*Vertices %d\n',n);
    
    for i=1:n
%       affil = 'sloan'; % char(subjects(sub_sort(i)).my_affil);
       if strncmp('MLF',list{i},3) || strncmp('MRF',list{i},3) || strncmp('MZF',list{i},3)
            color = 'Blue';
            if strncmp('MLF',list{i},3)
    			token = 1;
                shape = 'triangle';
            elseif strncmp('MRF',list{i},3)
    			token = 2;
                shape = 'box';
            else
    			token = 3;
                shape = 'circle';
            end
       elseif strncmp('MLC',list{i},3) || strncmp('MRC',list{i},3) || strncmp('MZC',list{i},3)
            color = 'Red';
            if strncmp('MLC',list{i},3)
    			token = 4;
                shape = 'triangle';
            elseif strncmp('MRC',list{i},3)
    			token = 5;
                shape = 'box';
            else
    			token = 6;
                shape = 'circle';
            end
       elseif strncmp('MLT',list{i},3) || strncmp('MRT',list{i},3) || strncmp('MZT',list{i},3)
            color = 'Pink';
            if strncmp('MLT',list{i},3)
    			token = 7;
                shape = 'triangle';
            elseif strncmp('MRT',list{i},3)
    			token = 8;
                shape = 'box';
            else
    			token = 9;
                shape = 'circle';
            end
       elseif strncmp('MLP',list{i},3) || strncmp('MRP',list{i},3) || strncmp('MZP',list{i},3)
            color = 'Green';
            if strncmp('MLP',list{i},3)
    			token = 10;
                shape = 'triangle';
            elseif strncmp('MRP',list{i},3)
    			token = 11;
                shape = 'box';
            else
    			token = 12;
                shape = 'circle';
            end
       elseif strncmp('MLO',list{i},3) || strncmp('MRO',list{i},3) || strncmp('MZO',list{i},3)
            color = 'Green';
            if strncmp('MLO',list{i},3)
    			token = 13;
                shape = 'triangle';
            elseif strncmp('MRO',list{i},3)
    			token = 14;
                shape = 'box';
            else
    			token = 15;
                shape = 'circle';
            end
       end
       
       fprintf(fid,'%d "%s" %s x_fact %.1f y_fact %.1f ic %s\n',i, list{i}, shape, sizes(i),sizes(i),color);
 
 %        fprintf(fid,'%d *%s*\n',i, char(survey_txt(find(==(subjects(i)))+offset, 13)));
 %       fprintf(fid2,'%d\n', token);
 %       fprintf(fid2,'%d\n',sat_support(i));
        
  %      i=i+1;
    end
    
    fprintf(fid, '*Arcs\n');
    %fprintf(fid, '*Edges\n');
    
    for i=1:n
        for j=1:n
            if adj_mat(i,j)>0.05 % arbitrary threshold
                fprintf(fid, '%d   %d   %d\n',i,j,adj_mat(i,j));
            end
        end
    end    
    
    fclose(fid);
  % fclose(fid2);
    
    
    
