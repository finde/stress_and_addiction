function RotateAxes(hndl, center, rotangle)

% function MovePos(hndl,deltapos)
%   moves the object with position or xdata/ydata properties

if nargin < 3
    error('hndl, center, and angle are required ([] for center rotates around (0,0)')
end

if isempty(center)
    center=[0 0];
end

for x=1:length(hndl)
    h = hndl(x);
    ch = get(hndl(x),'children');
    for c=1:length(ch)
        RotateAxes(ch(c), center, rotangle); % recursive call to rotate patches etc
    end
    
    % now rotate object at top level
    try
        % try 'XData' and 'YData';
        X = get(h,'xdata')';
        Y = get(h,'ydata')';
        dX = X - center(1);
        dY = Y - center(2);
        ang = angle(dX+dY*1i) + rotangle/360*2*pi; % rotate immediately
        amp = abs(dX+dY*1i);
        set(h,'xdata',cos(ang).*amp+center(1));
        set(h,'ydata',sin(ang).*amp+center(2));
    catch
        % probably no xdata found, continue
    end
end
