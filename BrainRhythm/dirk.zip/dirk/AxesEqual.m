function AxesEqual(h)

% makes the axes REALLY equal!

if nargin<1
    h=gca;
end

mn=Inf;
mx=-Inf;

ch=get(h,'ch');
for c=1:length(ch)
    try
        xdata = get(ch(c),'xdata');
        ydata = get(ch(c),'ydata');

        mn1=min(min(xdata),min(ydata));
        mx1=max(max(xdata),max(ydata));
    
        if mn1<mn, mn=mn1; end
        if mx1>mx, mx=mx1; end
    catch
        % no xdata and ydata in this
    end
end

if ~isinf(mx) % somewhere there was some xdata and ydata in this graph
    f=10^floor(log10(mn));
    mn = floor(mn./f).*f;
    f=10^floor(log10(mx));
    mx = ceil(mx./f).*f;

    set(h,'xlim',[mn,mx]);
    set(h,'ylim',[mn,mx]);
end % else do nothing