function Neg2LL = FIML(p)

% data x in columns

% reorganize p from vector to (standardized) matrix

S = [p(1) p(2); p(2) p(3)];

global data

N=size(data,1);
k=size(data,2);
c = k*log(2*pi);
iS = inv(S);
dS = det(S);

% Neg2LL=0;
LL = zeros(1,size(data,1));
for s=1:size(data,1)
    LL(s) = data(s,:)*iS*data(s,:)';
end
Neg2LL = sum(LL)+N*log(dS)+N*c;

