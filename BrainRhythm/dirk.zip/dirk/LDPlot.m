function [ax_handles line_handles_left line_handles_right] = LDPlot(R,varargin)

% plot a correlationmatrix in LD plot style. Plots subdiagonal as an image,
% then rotates this to a lower triangle, and optionally plots the diagonal
% as a line figure on top.
%
% varargin:
% - 'diag': (0/1) plots diagonal values in the LD image. Default=0. NOT
%           IMPLEMENTED YET
% - 'xlim': [lo hi] NOT IMPLEMENTED
% - 'xtick': (1xn) array: were to put separation lines in the LD plot
% - 'xticklabel': labels associated with the tick lines
% - 'plotld': (0/1) plot the (lower) LD image
% - 'plotline': (0/1) plot the (upper) line plot based on diagonal values
% - 'plotcolorbar': (0/1) plot the colorbar
% - 'subplot': [nrows ncols number]: values for subplot.
% - 'oversampling': [x] oversampling of the image (higher gives smoother
%                   image. Default 24.



cDoDiag=0;
cXLim = [];
cXTick = [];
cXTickLabel = {};
cDefineticklabel = 1;
cPlotLD=1;
cPlotLine=1;
cOverSampling = 24;
cPlotColorbar=0;
%one row, one column subplot scheme assumed. Add a row when pltting the
%heritability lineplot
cDefineSubplot = 0;
cSubplot = [1 1 1]; %(1 row, 1 column, number 1 plot)

for v=1:2:length(varargin)
    if strncmp(lower(varargin{v}),'diag',4)
        cDoDiag = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'xlim')
        cXLim = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'xtick')
        cXTick = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'xticklabel')
        cXTickLabel = varargin{v+1};
        cDefineticklabel = 0;
    elseif strcmp(lower(varargin{v}),'plotld')
        cPlotLD = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'plotline')
        cPlotLine = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'plotcolorbar')
        cPlotColorbar = varargin{v+1};
    elseif strcmp(lower(varargin{v}),'subplot')
        cSubplot = varargin{v+1};
        cDefineSubplot = 1;
    elseif strncmp(lower(varargin{v}),'over',4)
        cOverSampling = varargin{v+1};
    end
end
if length(cXTick)>0 && length(cXTickLabel)==0 && cDefineticklabel
    for t=1:length(cXTick)
        cXTickLabel{t}=num2str(cXTick(t));
    end
end

%create a whole figure, not just subplot. This allows the alignment of top
%and bottom graph

N=size(R,1);
D=diag(R);                % may be used for plotting
R=R+.000000001;           % avoid transparency for empty pixels
if cDoDiag
    R(logical(eye(N)))=D; % removes these from the plot
else
    R(logical(eye(N)))=0; % removes these from the plot
end

% create the bottom LD image
I = imrotate(kron(R,ones(cOverSampling)),45)*size(colormap,1);
I(round(end/2:end),:)=0;

% plotting parameters
col = mod(cSubplot(3)-1,cSubplot(2)); %0, 1, ...
row = floor((cSubplot(3)-1)/cSubplot(2)); %0, 1, ...


% do the plotting. First bottom image.
if cPlotLD 
    if cPlotLine
        % plot both: double the nrows
        subplot(cSubplot(1)*2,cSubplot(2),(row*2+1)*cSubplot(2)+col+1)
    else
        if cDefineSubplot
            subplot(cSubplot(1),cSubplot(2),cSubplot(3))
        end
    end
    image(I); % axis now defined as ???
    set(gca,'ydir','normal')
    set(get(gca,'ch'),'alphadata',logical(I)) % set 0 to transparent
    box off
    axis off
    hold on
    ylim(ylim/2+.25)
    yl=ylim;
    savegca=gca;

    if cPlotColorbar
        % add the colorbar
        h = colorbar;
        set(h,'ytick',[0:.2:1]*64+.5,'yticklabel',[0:.2:1])
    end

    % add "xticks"
    cXTick=cXTick-1;
    for t=1:length(cXTick)
        xtopl = (cXTick(t)+.05)*cOverSampling*sqrt(2);
        ytopl = max(yl);
        xtopr = (cXTick(t)+.05)*cOverSampling*sqrt(2);
        ytopr = max(yl);
        xbottoml = (cXTick(t)-.45)/2*cOverSampling*sqrt(2);
        ybottoml = (1-(cXTick(t)+.5)/N)*(max(yl)-min(yl));
        xbottomr = (N+cXTick(t)+.5)/2*cOverSampling*sqrt(2);
        ybottomr = ((cXTick(t)-.5)/N)*(max(yl)-min(yl));
        line_handles_left(t) = line([xtopl xbottoml],[ytopl ybottoml]);
        line_handles_right(t) = line([xtopr xbottomr],[ytopr ybottomr]);
        set(line_handles_left(t),'color','k','linewidth',1.0,'clipping','off')
        set(line_handles_right(t),'color','k','linewidth',1.0,'clipping','off')
        if ~isempty(cXTickLabel)
            thl = text(xbottoml,ybottoml,cXTickLabel{t});
            thr = text(xbottomr,ybottomr,cXTickLabel{t});
            set(thl,'vertical','top','hor','right')
            set(thr,'vertical','top','hor','left')
        end
    end
end

% add diagonal as line plot
if cPlotLine
    if cPlotLD 
        subplot(cSubplot(1)*2,cSubplot(2),(row*2+0)*cSubplot(2)+col+1)
    elseif cDefineSubplot
        subplot(cSubplot(1),cSubplot(2),cSubplot(3))
    end
    datax = 1:N;
    plot(datax,D,'.k-')
    xlim([.5 N+.5])
    set(gca,'xtick',datax,'xticklabel','')
    box off
end

% align the two figures, i.e. without the colorbar (IF both were requested)
if cPlotLD && cPlotLine
    pos_lo=get(savegca,'pos');
    pos_up=get(gca,'pos');
    pos_cb=get(gca,'outerpos');
    pos_up(3)=pos_lo(3);
    pos_up(2)=pos_lo(2)+pos_lo(4)+.04;
    set(gca,'pos',pos_up)
end


% return axes objects
if cPlotLD && cPlotLine
    ax_handles = [gca,savegca];
elseif cPlotLD
    ax_handles = gca;
elseif cPlotLine
    warning('Line plot but no LD plot!')
    ax_handles = savegca;
end






