function dPTE=PTE(data,delay)

% function dPTE=my_PTE_def_corrected(data,delay)
%
% Written by and (c): Matteo Demuru
% Adjusted By Dirk Smit d.j.smit@amc.nl
%
% THIS VERSION IS CORRECTED WITH DEFINITION OF Y AND YD... AS T AND T' FROM
% PAPER BY MURIEL

if nargin<2
    error('need to pass data and specify delay.')
end


%data is time x channel filtered signals. i.e. organized in colums

N=size(data,2); %number of channels
L=size(data,1); %signal length
complex_data=hilbert(data);
phase_data=angle(complex_data);
phase_data=phase_data+pi;  % put it in range [0 2*pi]

% define bins on first channel
w=3.49*std(phase_data(:,1))*L^(-1/3); %BIN size as Scott
bins_w = -w/2:w:2*pi+w/2;
% bins_w=(min(phase_data(:,1))-w/2):w:((max(phase_data(:,1)))+w/2); %BINS
dPTE=zeros(N,N);

for i=1:N
   for j=1:N
      if i~=j
          Pypr_y=zeros(length(bins_w),length(bins_w)); %y and x are past states. 
          Py_x=zeros(length(bins_w),length(bins_w));
          Pypr_y_x=zeros(length(bins_w),length(bins_w),length(bins_w));          
          Py=histc(phase_data(1:end-delay,j),bins_w)/(L-delay);
          Hy=-dot(Py(1:end-1),log2(Py(1:end-1)));         
          rn_ypr=round((phase_data(1+delay:end,j)/w))+1; %WORKS FINE!!!
          rn_y=round((phase_data(1:end-delay,j)/w))+1;
          rn_x=round((phase_data(1:end-delay,i)/w))+1;          
          for kk=1:(L-delay)
              Pypr_y(rn_y(kk),rn_ypr(kk))=Pypr_y(rn_y(kk),rn_ypr(kk))+1;
              Py_x(rn_x(kk),rn_y(kk))=Py_x(rn_x(kk),rn_y(kk))+1;
              Pypr_y_x(rn_ypr(kk),rn_y(kk),rn_x(kk))=Pypr_y_x(rn_ypr(kk),rn_y(kk),rn_x(kk))+1;
          end
          Pypr_y=Pypr_y/(L-delay);
          Py_x=Py_x/(L-delay);
          Pypr_y_x=Pypr_y_x/(L-delay);          
          Hypr_y=-nansum(nansum(Pypr_y(1:end-1,1:end-1).*log2(Pypr_y(1:end-1,1:end-1))));
          Hy_x=-nansum(nansum(Py_x(1:end-1,1:end-1).*log2(Py_x(1:end-1,1:end-1))));
          Hypr_y_x=-nansum(nansum(nansum(Pypr_y_x(1:end-1,1:end-1,1:end-1).*log2(Pypr_y_x(1:end-1,1:end-1,1:end-1)))));                    
          dPTE(i,j)=Hypr_y+Hy_x-Hy-Hypr_y_x;
      end
   end    
end
for i=1:N
   for j=1:N
       if i~=j
       dPTE(i,j)=dPTE(i,j)/(dPTE(i,j)+dPTE(j,i));
       dPTE(j,i)=1-dPTE(i,j);
       end
   end
end


