function [M] = familysampledmaxloess(widedata,fitx)

% widedata is a 3D matrix with 2 levels in the 3rd dimension. (:,:,1) and
% (:,:,2) are each a matrix with observations of all subjects organized
% in wide format, i.e., each row a family, and family members in columns.
% Returns the index of maximum values of loess fit to resampled data.


if nargin<2
    error('Need all parameters');
end

if size(widedata,3)==1
    if mod(size(widedata,2),2)~=0 % data too small
        error('wrong data size');
    end
    % assume only two dimensions, x and y glued to each other by the bootci
    % function (MATLAB feature)
    datax=widedata(:,1:end/2);
    datay=widedata(:,end/2+1:end);
else
    % x and y along third dimension
    datax=widedata(:,:,1);
    datay=widedata(:,:,2);
end

% valid as logical
valid=~isnan(datax)&~isnan(datay);

% select data (both x and y) as 1D, loeass fit with specified parameters
reg = polyfit(log(datax(valid)),datay(valid),2);
fity = polyval(reg,log(fitx));

% get the point of maximum
[dummy temp] = max(fity);
M = fitx(temp); % no need to recalculate from log(fitx)



