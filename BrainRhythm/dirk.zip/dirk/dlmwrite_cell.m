function [] = dlmwrite_cell(name, data, del, fmt, header)
%function [] = dlmwrite_ex(name, data, del, fmt, header);
% 
% writes data matrix to a file like dlmwrite, but also writes a header
% line. Overwrites files without warning! Usage:
% name: file name (string)
% data: data matrix (numerical)
% delimmiter: e.g., ',' or '\t'
% fmt: fprintf-style code, e.g. %d or %8.4f (for real data only)
% header:  (cell {} type list of strings)

if nargin<5,
    header={};
end

fid = fopen(name, 'w');
if fid <= 0
    error(sprintf('Could not open file "%s"\n', name));
end

if isempty(fmt)
    fmt='%.3f';
end

if ~isempty(header)
    fprintf(fid, header{1});
    for c=2:length(header)
        fprintf(fid, [del header{c}]);
    end
    fprintf(fid, '\n');
end

% check format string
if length(fmt)>1
    if size(data,2)~=length(fmt)
        error('Length of format string must match the number of columns, or use only the format for double')
    end
end

% loop based on format string.
if length(fmt)==1
    for r=1:size(data,1)
        if isnumeric(data{r,1})
            fprintf(fid, fmt, data{r,1});
        else
            fprintf(fid, '%s', data{r,1});
        end
        for c=2:size(data,2)
            if isnumeric(data{r,c})
                fprintf(fid, [del fmt], data{r,c});
            else
                fprintf(fid, [del '%s'], data{r,c});
            end
        end
        fprintf(fid, '\n');
    end
else % use format array.
    if iscell(data)
        for r=1:size(data,1)
            fprintf(fid, fmt{1}, data{r,1});
            for c=2:size(data,2)
                fprintf(fid, [del fmt{c}], data{r,c});
            end
            fprintf(fid, '\n');
        end
    else
        for r=1:size(data,1)
            fprintf(fid, fmt{1}, data(r,1));
            for c=2:size(data,2)
                fprintf(fid, [del fmt{c}], data(r,c));
            end
            fprintf(fid, '\n');
        end
    end
end

fclose(fid);

