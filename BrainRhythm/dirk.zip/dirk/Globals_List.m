function [List Dir]= Globals_List(Age, Root)
% returns the file list associated with this age group in the EEG
% experiments of Caroline van Baal (ages 5, 7), Toos van Beijsterveldt
% (ages 16 and 18), and Danielle Posthuma (ages 25 and 50, or 2550 for the
% whole group). REQUIRES THE FILES RegExt in the /Alle data/ directory
% Creates a random-selection list (One per family)
% 

if nargin<2
    Root = '/Volumes/FourTB/Overdrachtelijk/Alle data';
end

clear List

List=struct;

% read data
if Age==2550
    [RegExt1] = dlmread_ex(sprintf('%s/RegExt25.txt',Root),'\t',1);
    [RegExt2] = dlmread_ex(sprintf('%s/RegExt50.txt',Root),'\t',1);
    RegExt = sortrows([RegExt1;RegExt2],[1 2]);
else
    [RegExt] = dlmread_ex(sprintf('%s/RegExt%02d.txt',Root,Age),'\t',1);
end

% create file list
if Age<100 || Age==2550
    for pp=1:size(RegExt,1)
        List(pp).Fam = RegExt(pp,1);
        List(pp).Sib = RegExt(pp,2);
        List(pp).Reg = RegExt(pp,3);
        List(pp).Ext = RegExt(pp,4);
        List(pp).Wave = RegExt(pp,5);
        List(pp).Subject = RegExt(pp,6);
        List(pp).Unique = RegExt(pp,7);
        List(pp).Zygosity = RegExt(pp,8);
        List(pp).Sex = RegExt(pp,9);
        List(pp).Age = RegExt(pp,10);
    end
else % WUSTL data
    zygdone = false(1,size(RegExt,1));
    for pp=1:size(RegExt,1)
        List(pp).Fam = RegExt(pp,1);
        List(pp).Sib = RegExt(pp,2);
        List(pp).Reg = RegExt(pp,1);
        List(pp).Ext = RegExt(pp,2);
        List(pp).Wave= Age-100;
        List(pp).Subject = RegExt(pp,3);
        List(pp).Unique = RegExt(pp,3)*100+Age-100;
        if ~zygdone(pp)
            List(pp).Zygosity = RegExt(pp,4);
        end
        List(pp).Sex = RegExt(pp,5);
        List(pp).Age = RegExt(pp,8);
        
        % work on zygosity (convert from 1,2 to 1:5)
        ext = RegExt(pp,2);
        if ext==1 && ~zygdone(pp)
            ndxtw2 = find(RegExt(:,1)==RegExt(pp,1) & RegExt(:,2)==2);  % idx of twin 2
            ndxsibs = find(RegExt(:,1)==RegExt(pp,1) & RegExt(:,2)>=2); % all sibs, inlcudes twin 2
            if ~isempty(ndxtw2)
                zyg = RegExt(pp,4);                   % zygosity MZ v DZ
                sex1 = RegExt(pp,5);                  % sex of tw1 (#Y chr, 0=F)
                sex2 = RegExt(ndxtw2,5);              % sex of tw2 (#Y chr, 0=F)
                if zyg==1 && sex1==1 && sex2==1
                    List(pp).Zygosity = 1; %MZM
                elseif zyg==1 && sex1==0 && sex2==0
                    List(pp).Zygosity = 2; %MZF
                elseif zyg==2 && sex1==1 && sex2==1
                    List(pp).Zygosity = 3; %DZM
                elseif zyg==2 && sex1==0 && sex2==0
                    List(pp).Zygosity = 4; %DZF
                else
                    List(pp).Zygosity = 5; %OS
                end
            end
            % copy to the others
            try 
                for i=1:length(ndxsibs)
                    List(ndxsibs(i)).Zygosity = List(pp).Zygosity;
                end
            catch
            end
            zygdone(ndxsibs)=true;
        end
    end
end

% create list of filename codes    
if Age<10 % Caro
    for pp=1:length(List)
        if List(pp).Sib==1, code='a'; else code='b'; end
        if Age==5, occ=1; else occ=2; end
        List(pp).Filename = sprintf('%03d%c%1d', List(pp).Fam, code, occ);
    end
elseif Age == 17 %OZ
    for pp=1:length(List)
        List(pp).Filename = sprintf('%03d%1d', List(pp).Fam, List(pp).Sib);
    end
elseif Age < 20 % Toos
    for pp=1:length(List)
        if List(pp).Sib==1, code='a'; else code='b'; end
        if Age==16, occ=1; else occ=2; end
        List(pp).Filename = sprintf('%03d%c%1d', List(pp).Fam, code, occ);
    end
elseif Age<100 || Age == 2550 % Danielle
    for pp=1:length(List)
        List(pp).Filename = sprintf('%03d%02d',List(pp).Fam,List(pp).Sib);
    end
else % WUSTL
    for pp=1:length(List)
        List(pp).Filename = sprintf('%d',RegExt(pp,3));
    end
end

if nargout>1
    switch Age
        case {5,7}
            temp = 'Caroline -- BackEEG';
        case {16,18}
            temp = 'Toos -- BackEEG';
        case {17}
            temp = 'OZ -- BackEEG';
        case {25,50,2550}
            temp = 'Danielle -- BackEEG';
        otherwise
            temp = 'Andrey -- BackEEG';
    end
    Dir = sprintf('%s/%s',Root,temp);
end
            


    