%% a function
function out = randomize(in,N)

out=in;
for i=1:N
    rnd=zeros(1,3);
    while rnd(1)==rnd(2) || rnd(1)==rnd(3) || rnd(3)==rnd(2) || ...
            out(rnd(1),rnd(2))==0.0 || out(rnd(1),rnd(3))==1.0
        for j=1:3;
            rnd(j)=1+floor(rand*size(in,1));
        end
    end
    out(rnd(1),rnd(2))=0.0;
    out(rnd(2),rnd(1))=0.0;
    out(rnd(1),rnd(3))=1.0;
    out(rnd(3),rnd(1))=1.0;
end

return