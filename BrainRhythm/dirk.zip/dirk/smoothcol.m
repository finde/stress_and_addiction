function [c] = smoothcol(varargin)
%SMOOTHCOL  Smooth data along columns
%   Calls smooth for each column. Discards the ww output variable

if nargin < 1
    error(message('curvefit:smooth:needMoreArgs'));
end

X=varargin{1};
args = varargin(2:end);
for col=1:size(X,2)
    c(:,col) = smooth(X(:,col),args{:});
end