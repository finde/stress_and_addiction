
function out = Graph_Rewire(in, reconn)
% function out = Graph_Rewire(in, reconn)
% reconnects "reconn" connections in connectivity matrix "in"

out=in;
for i=1:reconn
    % reconnection goes in triangles: from 1 to 2 gets reconnected to 1 to
    % 3. 
    rnd=zeros(1,3);
    while rnd(1)==rnd(2) || rnd(1)==rnd(3) || rnd(3)==rnd(2) || ...
            out(rnd(1),rnd(2))==0.0 || out(rnd(1),rnd(3))==1.0
        rnd=1+floor(rand(1,3)*size(in,1));
    end
    out(rnd(1),rnd(2))=0.0;
    out(rnd(2),rnd(1))=0.0;
    out(rnd(1),rnd(3))=1.0;
    out(rnd(3),rnd(1))=1.0;
end

