function h = plotlongitudinal(X,Y,ID,prop)

if nargin<4
    prop = .2;
end

Y = Y(sortindex(ID));
X = X(sortindex(ID));
ID = ID(sortindex(ID));

cm = colormap;
%{
weights = grpstats(Y,ID,'mean');
weights = abs(nanzscore(weights));
weights = (weights-min(weights))/range(weights);
weights(weights<0) = 0;
weights(weights>1) = 1;
weights(isnan(weights)) = 0;
%}

% allow plotting multiple lines
hold on
 
try
u = unique(ID);
rnd = rand(1,length(u)+1)<prop;
for uc=1:length(u)
    if ~isnan(u(uc)) 
        ndx = ID==u(uc);
        % plot(X(ndx),Y(ndx),'color',cm(1+round(weights(uc)*size(cm,1)),:),varargin{:});
        plot(X(ndx),Y(ndx),'o');
        if sum(ndx)>1 && rnd(uc) 
            patchline(X(ndx),Y(ndx),'linestyle','-','edgecolor','k','edgealpha',.3);
        end
    end
end
catch E
    pause
end