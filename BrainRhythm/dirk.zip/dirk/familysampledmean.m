function [M] = familysampledmean(widedata, missing)

% widedata is a 3D matrix with 2 levels in the 3rd dimension. (:,:,1) and
% (:,:,2) are each a matrix with observations of all subjects organized
% in wide format, i.e., each row a family, and family members in columns.
% widedata1 holds the dependent variable
% widedata2 holds the group variable: two levels only!!!!
% Returns the mean difference between the two groups in widedata2.

if nargin<2,
    missing=NaN;
end

if ~isnan(missing)
    widedata(find(widedata(:)==missing))=NaN;
end

if size(widedata,3)==1
    if mod(size(widedata,2),2)~=0
        error('wrong data size');
    end
    % assume only two dimensions, x and y glued to each other
    datax=widedata(:,1:end/2);
    datay=widedata(:,end/2+1:end);
else
    % x and y along third dimension
    datax=widedata(:,:,1);
    datay=widedata(:,:,2);
end

   
% valid in 1D, corr will be computed 1D also
datay=datay(:);
datax=datax(:);
valid=find(~isnan(datax)&~isnan(datay));

u=unique(datay(valid));
for uc=1:length(u)
    f=find(datay(valid)==u(uc));
    M(uc) = mean(datax(valid(f)));
end
M=M(:,2)-M(:,1);



