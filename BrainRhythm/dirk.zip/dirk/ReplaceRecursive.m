function ReplaceRecursive(obj,key,value,verbose)

% go thru all children and replace all "key" properties with value.

if nargin<4
    verbose=logical(0);
end

try
    set(obj,key,value);
catch
    if verbose
        warning(sprintf('no "%s" property in object "%s"',key,get(obj,'name')));
    end
end

try
    ch = get(obj,'children');
    for c=1:length(ch)
        ReplaceRecursive(ch(c),key,value)
    end
catch
    if verbose
        warning(sprintf('no "children" property in object "%s"',get(obj,'name')));
    end
end