function P=fcnRegP(X,Y)

reg=regstats(Y,X,'linear','tstat'); 
P=reg.tstat.pval; 
end