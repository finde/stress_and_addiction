function SqueezeObjects(hndl,p)

% proportional squeezing objects in handle list hndl nearer together. p
% holds the proportion (valus <1). Note that values of p>1 results in an
% expansion. p=[dx dy] squeeze parameter for x and y directions.

maxX = -Inf;
minX = Inf;
maxY = -Inf;
minY = Inf;

for x=1:length(hndl)
    h=hndl(x);
    try
        pos = get(h,'position');
        if pos(1)<minX, minX=pos(1); end
        if pos(2)<minY, minY=pos(2); end
        if pos(1)>maxX, maxX=pos(1); end
        if pos(2)>maxY, maxY=pos(2); end
        if length(pos)==4
            if pos(1)+pos(3)>maxX, maxX=pos(1)+pos(3); end
            if pos(1)+pos(4)>maxY, maxY=pos(2)+pos(4); end
        end
    catch
        % try 'XData' and 'YData';
        X=get(h,'xdata');
        Y=get(h,'ydata');
        if min(X)<minX, minX=min(X); end
        if min(Y)<minY, minY=min(Y); end
        if max(X)>maxX, maxX=max(X); end
        if max(Y)<maxY, maxY=max(Y); end
    end
end

midX = mean([maxX,minX]);
midY = mean([maxY,minY]);

for x=1:length(hndl)
    h=hndl(x);
    try
        pos = get(h,'position');
        pos(1)=(pos(1)-midX)*p(1)+midX;
        pos(2)=(pos(2)-midY)*p(2)+midY;
        if length(pos)==4
            pos(3:4)=pos(3:4).*p;
        end
        set(h,'position',pos);
    catch
        % try 'XData' and 'YData';
        X=get(h,'xdata');
        Y=get(h,'ydata');
        X=(X-midX)*p(1)+midX;
        Y=(Y-midY)*p(2)+midY;
        set(h,'xdata',X);
        set(h,'ydata',Y);
    end
end

