function [Res StartCols NData Header] = Restructure(Data, varargin)
%
% function [Res StartCols NData Header] = Restructure(Data, varargin)
% 
% Restructures data like cases-to-var in SPSS, for example, to restructure
% a dataset with one subject per line (data) to one family per line with
% multiple siblings next to each other.
% 
% Data will be restructured using a identifier and index variable. Each 
% unique value of the identifier variable in 'data' will result in a line
% in 'Res'. The value of index determines the position on the line.
%
% 'Id'      : column number for Id (e.g., Family number; def=1)
% 'Index'   : column number for Index (e.g., Sibling number; def=2)
% 'Missing' : Empty cells (with are very probable) will get value 'Missing'
%             (def=NaN)
% 'Ignore'  : Do not output data from these columns in restructured data
% 'Include' : Only restructure data from these columns. Has the opposite
%             effect of 'Ignore'.
% 'Fix'     : Take value of first occurence of these columns and create
%             only one columns in output data. Useful for data that do not
%             vary between subjects(e.g., siblings)
% 'Aggragate' : {'none','mean'}. Take mean value of observations that fall
%             into indentical cells. default='none'
% 'header'  : {cell array of strings} header info for unstrcutured data
%             will be retruned into a correct enumerated header for the new
%             restructured file and outputted in Header.
% 'reorder' : 0/1 final data will be reordered with datacolumns not in
%             format (v1 w1  v2 w2  v3 w3) but (v1 v2 v3  w1 w2 w3) where v
%             and w stand for the different variables (columns) in the
%             input data and 1 2 3 for the numbers in th eindex columns.

if nargin<1
    help Restructure
    return
end

if isempty(Data) || size(Data,2)<=1
    error('No or insufficient data.');
end

Id = 1;
Index = 2;
Missing=NaN;
Ignore=[];
Fix=[];
Agg=0;
Aggregate='None';
UseInclude=0;
Include=[];
HeaderIn={};
Reorder=0;
for v=1:2:length(varargin)
    if strcmpi(varargin{v},'index')
        Index=varargin{v+1};
    elseif strcmpi(varargin{v},'id')
        Id=varargin{v+1};
    elseif strcmpi(varargin{v},'missing')
        Missing=varargin{v+1};
    elseif strcmpi(varargin{v},'ignore')
        Ignore=varargin{v+1};
    elseif strcmpi(varargin{v},'include')
        UseInclude=1;
        Include=varargin{v+1};
    elseif strcmpi(varargin{v},'fix')
        Fix=varargin{v+1};
    elseif strcmpi(varargin{v},'aggregate')
        Aggregate=varargin{v+1};
    elseif strcmpi(varargin{v},'header')
        HeaderIn=varargin{v+1};
    elseif strcmpi(varargin{v},'reorder')
        Reorder=varargin{v+1};
    end    
end



% check input
if size(Fix,1)>size(Fix,2)
    Fix=Fix';
end
if size(Include,1)>size(Include,2)
    Include=Include';
end
if size(Ignore,1)>size(Ignore,2)
    Ignore=Ignore';
end
if ~iscell(HeaderIn)
    error('Header of input data must be a cell array of strings.')
end
if ~isempty(HeaderIn) && length(HeaderIn)~=size(Data,2)
    error('Header of input data must have same number elements as columns in input data.')
end

% do preprocessing
if strcmpi(Aggregate,'mean')
    Agg=1;
end

% determine columns to handle
if ~UseInclude % will use all data except thos marked by 'ignore'
    rest=setdiff(1:size(Data,2),[Id Index]);
    rest=setdiff(rest,Ignore);
    rest=setdiff(rest,Fix);
else % will only restructure the data indicated by 'include'
    rest=Include;
end
NRest=length(rest);
NFix=length(Fix)+1; % add one for AllId column

% determine Ids and Indexes
Temp=Data(:,Id);
AllId=sort(unique(Temp(find(Temp~=Missing))));
Temp=Data(:,Index);
AllIndex=sort(unique(Temp(find(Temp~=Missing))));

% initialize
Res=ones(length(AllId),NFix+NRest*length(AllIndex))*Missing;
Res(:,1)=AllId;
if Agg>0
    Cnt = zeros(size(Res)); % use count to keep track of number of identical observations
end

% loop and fill in
for i=1:size(Data,1)
    row=find(Data(i,Id)==AllId);
    col=find(Data(i,Index)==AllIndex);
    if Agg>0 % keep mean value
        source = Data(i,rest);
        target = Res(row,NFix+1+(col-1)*NRest:NFix+col*NRest);
        count  = Cnt(row,NFix+1+(col-1)*NRest:NFix+col*NRest);
        Res(row,NFix+1+(col-1)*NRest:NFix+col*NRest) = ...
            target.*count./(count+1) + source./(count+1);
        Cnt(row,NFix+1+(col-1)*NRest:NFix+col*NRest) = Cnt(row,NFix+1+(col-1)*NRest:NFix+col*NRest) + 1;
    else
        Res(row,NFix+1+(col-1)*NRest:NFix+col*NRest) = Data(i,rest);
    end
    if ~isempty(Fix)
        Res(row,2:1+length(Fix)) = nanmean([Res(row,2:1+length(Fix)); Data(i,Fix)]);
    end
end

% starting comlumns: each index starts here
StartCols=[NFix+1:NRest:size(Res,2)];

NData=NRest;
Header=[];
if ~isempty(HeaderIn)
    Header={HeaderIn{[Id Fix]}};
    for h1=1:numel(AllIndex)
        for h2=1:NRest
            Header=[Header {sprintf('%s_%d',HeaderIn{rest(h2)},AllIndex(h1))}];
        end
    end
end

% reorder if flagged from v1 v2 v3 w1 w2 w3  to  v1 w1 v2 w2 v3 w3
if Reorder
    CopyRes=Res;
    CopyHeader=Header;
    CopyStart=StartCols;
    StartCols=NFix+1:length(AllIndex):size(Res,2); % new starting columns change meaning!!! indicate not index values, but different variables.
    for h1=1:length(AllIndex)
        for h2=1:NRest
            Res(:,StartCols(h2)+(h1-1)) = CopyRes(:,CopyStart(h1)+(h2-1));
            Header{StartCols(h2)+(h1-1)} = CopyHeader{CopyStart(h1)+(h2-1)};
        end
    end
end



