function [Out Skip] = Aggregate(Data, IdColumns, varargin)
% Aggregate: [out] = Aggregate(Data,IdColumns,varargin)
% 
% combine multiple data points by averaging into one. For each unique
% combination of values in Data(:,IdColumns) average all the available data
% in the other columns in Data.
% - Data: matrix with observations in rows and variables in columns
% - IdColumns: (1,k) vector with column numbers holding the identifiers
% - varargin:
%   - 'Missing': (int/double) missing value (default NaN)
%   - 'Random' : (int) randomly select an observations in stead of average over
%      observations. Uses the value of the parameter as seed! If no
%      initialization of the RNG is needed, pass -1. If simple means
%      aggragation is wanted, pass 0.

Missing = NaN;
RndSeed=0;
SelectCols=[];
for v=1:2:length(varargin)
    if strcmpi(lower(varargin{v}),'missing')
        Missing = varargin{v+1};
    elseif strcmpi(lower(varargin{v}),'random')
        RndSeed = varargin{v+1};
    elseif strcmpi(lower(varargin{v}),'selectcol')
        SelectCols = varargin{v+1};
    else
        error(sprintf('Unknown option: %s',varargin{v}));
    end
end

% inialize
Out = Data;
Skip = zeros(1,size(Data,1));
DataCols = setdiff(1:size(Data,2),IdColumns);
Data(Data(:)==Missing) = NaN;

% two types exist: take average of all available scores, or do random
% selection based on seed

% seed the random number generator
if RndSeed>0
    rng(RndSeed);
end

for row=1:size(Data,1)-1
    if Skip(row)
        continue
    end

    match = Data(row+1:end,IdColumns)==repmat(Data(row,IdColumns),size(Data,1)-row,1);
    ndx = find(sum(match,2)==length(IdColumns))+row;
    Skip(ndx) = 1; % these have been done
    ndx = [row ndx'];

    % now select from the list in ndx. If one is FULLY missing on the
    % data columns, then 
    if ~isempty(SelectCols)
        valid = ~(sum(isnan(Data(ndx,SelectCols)),2)==length(SelectCols));
    else
        valid = ones(length(ndx),1);
    end
    if sum(valid)>0
        ndx2 = find(valid);
        if RndSeed~=0
            try
                % chhose one
                Out(row,DataCols) = Data(ndx(ndx2(randi(sum(valid)))),DataCols);
            catch 
                error('Error in assignment. Unknown error.')
            end
        else
            try
                % average with nanmean
                Out(row,DataCols) = nanmean(Data(ndx(ndx2),DataCols),1);
            catch 
                error('Error in assignment. Unknown error.')
            end
        end
    end
end

% Only output not skipped data. Should be all data.
Out = Out(~Skip,:);
% reconvert NaN to missing value
if ~isnan(Missing)
    Out(isnan(Out(:)))=Missing;
end

    
            
            
            