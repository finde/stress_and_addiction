function handle = polyline(N)

if nargin<1
    N = 2;
end

count=0;
ch = get(gca,'ch');
ndx = find(strcmp(get(ch,'type'),'line'));
if size(ndx,1)>1
    ndx=ndx';
end
for c = ndx % only if the child is a line
    count=count+1;
    
    X = get(ch(c),'xdata');
    Y = get(ch(c),'ydata');
    
    valid = ~isnan(X) & ~isnan(Y);
    X = X(valid);
    Y = Y(valid);
    
    pp = polyfit(X,Y,N);
    yhat = polyval(pp,X);
    
    [X,sortndx] = sort(X);
    yhat = yhat(sortndx);
    
    handle(count) = line(sort(X),yhat);
    set(handle(count),'marker','none')
    set(handle(count),'color',get(ch(c),'color'))
    set(handle(count),'linestyle','-')
end
