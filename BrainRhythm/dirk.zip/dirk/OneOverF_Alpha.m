function [out] = OneOverF_Alpha(len,alpha,srate,freq)
% OneOverF_Alpha(len,alpha,freq)
%
% creates a one-over-f signal of length len (def=1024) at rate Hz sampling
% frequency (def=250). alpha (def=1.0) is the exponent: the slope of the line
% in the log-log plot of power against frequency (power-law exponent)

if nargin<4
    freq=0;
end
if nargin<3
    srate=128;
end
if nargin<2
    alpha=1.0;
end
if nargin<1
    len=1024;
end

if mod(len(1),2)~=0
    error('len must be even.')
end

if length(len)==1
    len=[len 1];
end

for row=1:len(2)
    % create a random spectrum
    Pow=(rand(1,len(1)./2)*2).^2;
    Pow=(Pow./mean(Pow));
    f=linspace(0,srate/2,len(1)./2+1);
    f=f(2:end);

    lp=log(Pow);
    lf=log(f);
    lp=-alpha.*lf;
    lp=lp+min(lp);
    Pow=exp(lp);

    Amp=sqrt(Pow);
    angles=rand(1,len(1)./2)*2*pi;
    Fcos=cos(angles).*Amp;
    Fsin=sin(angles).*Amp;
    FullF=[0 Fcos+Fsin.*1i Fcos(end-1:-1:1)-Fsin(end-1:-1:1).*1i];
    FullF(end/2+1)=abs(FullF(end/2+1));

    signal=ifft(FullF);
    signal=(signal-mean(signal))./std(signal);

    out(row,:)=signal;
end
out=out';

if freq>0
    out = real(SineVec(freq,length(out),'rate',srate)').*(out-min(out));
end