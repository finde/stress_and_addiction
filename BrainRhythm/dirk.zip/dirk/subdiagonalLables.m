function Labels = subdiagonalLables(prefix, N, byrow)

if nargin<3
    byrow=true;
end

count=0;
if byrow
    for row=2:N
        for col=1:row-1
            count=count+1;
            Labels{count} = sprintf([prefix '%d%d'],row,col);
        end
    end
else    
    for col=1:N-1
        for row=col+1:N
            count=count+1;
            Labels{count} = sprintf([prefix '%d%d'],row,col);
        end
    end
end
    
    