function h = loglsline
% LOGLSLINE Add least-squares fit line to scatter plot.
%   LOGLSLINE detects lineseries and fits the linear fit, but when the axis
%   scale is set to 'log' it fits it to the log10 of the data.
% 
%   H = LOGLSLINE returns the handle to the line object(s) in H.
%   
%   Copyright 1993-2010 The MathWorks, Inc.
%   Additions made by Dirk Smit


% Find any line objects that are descendents of the axes.
AxCh = get(gca,'Children');
lh = findobj(AxCh,'Type','line');
% Ignore certain continuous lines.
if ~isempty(lh)
    style = get(lh,'LineStyle');
    if ~iscell(style)
        style = cellstr(style);
    end
    ignore = strcmp('-',style) | strcmp('--',style) | strcmp('-.',style);
    lh(ignore) = [];
end

% Find hggroups that are immediate children of the axes, such as plots made
% using SCATTER.
if matlab.graphics.internal.isGraphicsVersion1
    hgh = findobj(AxCh,'flat','Type','hggroup');
else
    hgh = findobj(AxCh,'flat','Type','scatter');
end

% get axis scaling (log or linear)
doXLog=false;
doYLog=false;
if strcmp(get(gca,'xscale'),'log')
    doXLog = true;
end
if strcmp(get(gca,'yscale'),'log')
    doYLog = true;
end

% save nextplot
NextPlot = get(gca,'nextplot');
hold on

% Ignore hggroups that don't expose both XData and YData.
if ~isempty(hgh)
    ignore = ~isprop(hgh,'XData') | ~isprop(hgh,'YData');
    hgh(ignore) = [];
end

hh = [lh;hgh];
numlines = length(hh);
if numlines == 0
    warning(message('stats:lsline:NoLinesFound'));
    hlslines = [];
else
    for k = 1:length(hh)
        if isprop(hh(k),'ZData')
            zdata = get(hh(k),'ZData');
            if ~isempty(zdata) && ~all(zdata(:)==0)
                warning(message('stats:lsline:ZIgnored'));
            end
        end
        % Extract data from the points we want to fit.
        xdat = get(hh(k),'XData'); xdat = xdat(:);
        ydat = get(hh(k),'YData'); ydat = ydat(:);
        % do logarithm when axis was in log scale
        if doXLog, xdat=log10(xdat); end
        if doYLog, ydat=log10(ydat); end
        
        % determine 
        ok = ~(isnan(xdat) | isnan(ydat) | isinf(xdat) | isinf(ydat)) ;
        if isprop(hh(k),'Color')
            datacolor = get(hh(k),'Color');
        else
            datacolor = [.75 .75 .75]; % Light Gray
        end
        % Fit the points and plot the line.
        beta = polyfit(xdat(ok,:),ydat(ok,:),1);
        yhat = polyval(beta,xdat(ok));
        
        if doXLog, xplot = 10.^xdat(ok); else xplot = xdat(ok); end
        if doYLog, yplot = 10.^yhat; else yplot = yhat; end

        hlslines(k) = plot(xplot,yplot,'-');
        set(hlslines(k),'Color',datacolor);
    end
    set(hlslines,'Tag','lsline');
end

set(gca,'nextplot',NextPlot);

if nargout == 1
    h = hlslines;
end
