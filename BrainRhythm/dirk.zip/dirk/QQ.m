function QQ(P,perc)
% Plots the Q_Q plot of P-values expected under the null and observed
% (passed in P)

if nargin<2
    perc=1;
end

Obs = -log10(sort(P));
Exp = -log10((1:size(P,1))./size(P,1));


plot(Exp,Obs,'ok','linewidth',.1,'markerfacecolor','k','markersize',3);
hold on
set(refline(1),'color',[.5 .5 .5])
 
    

