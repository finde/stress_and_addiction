function h = text_ex(x,y,str)
% same as text, but specify location in relative units within the current
% axes (values of x and y between 1 and 0).

xmin = min(xlim);
ymin = min(ylim);
xrange = diff(xlim);
yrange = diff(ylim);

h = text(xmin+x*xrange,ymin+y*yrange,str);


