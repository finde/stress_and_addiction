function plotqq(P, plotstr, plotcolor)

% plot p-value based qq plot.

if nargin<3
    plotcolor = [];
end
if nargin<2
    plotstr = '.';
end

ncols = size(P,2);
if ncols>1
    hold on
    CM = colormap;
    idx = round(linspace(1,size(CM,1),ncols));
    for col=1:ncols
        plotcolor{col} = CM(idx(col),:);
    end
else
    plotcolor{1} = [0 0 0];
end

for col=1:ncols
    p = sort(P(:,col));
    plot(-log10((1:length(p))/length(p)),sort(-log10(p),'descend'),plotstr,'markerfacecolor',plotcolor{col});
end

xl = xlim;
yl = ylim;
xlim([0 max([yl(2) xl(2)])]);
ylim(xlim);
set(refline(1,0),'color',[.5 .5 .5]);
set(refline(1,-log10(.05)),'linestyle','--','color','k');
xlim([0 max([yl(2) xl(2)])]);
ylim(xlim);


