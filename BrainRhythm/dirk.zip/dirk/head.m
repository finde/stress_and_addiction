function head(X,N)

if nargin<2
    N=10;
end

X(1:min(size(X,1),N),:)

